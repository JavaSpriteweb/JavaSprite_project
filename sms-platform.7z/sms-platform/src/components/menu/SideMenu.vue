<template>
  <a-layout-sider :theme="theme.mode" :class="['side-menu', 'beauty-scroll', isMobile ? null : 'shadow']" width="170px" :collapsible="collapsible" v-model="collapsed" :trigger="null">
    <div :class="['logo', theme.mode]">
      <router-link to="/application/list">
        <svg-icon icon-class="logo"></svg-icon>
<!--        <h1>{{systemName}}</h1>-->
      </router-link>
    </div>
    <i-menu :theme="theme.mode" :collapsed="collapsed" :options="menuData" @select="onSelect" class="menu"/>
  </a-layout-sider>
</template>

<script>
import IMenu from './menu'
import {mapState} from 'vuex'
export default {
  name: 'SideMenu',
  components: {IMenu},
  props: {
    collapsible: {
      type: Boolean,
      required: false,
      default: false
    },
    collapsed: {
      type: Boolean,
      required: false,
      default: false
    },
    menuData: {
      type: Array,
      required: true
    }
  },
  computed: {
    ...mapState('setting', ['isMobile', 'systemName', 'theme'])
  },
  methods: {
    onSelect (obj) {
      this.$emit('menuSelect', obj)
    }
  }
}
</script>

<style lang="less" scoped>
@import "index";
</style>
