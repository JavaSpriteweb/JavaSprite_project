<template>
  <a-button :disabled="isSend" @click="sendCheckSms" :loading="sendLoading">
    {{btnText}}
  </a-button>
</template>

<script>
import { sendCheckSms, checkSmsCode } from '@/services/application'

export default {
  name: "index",
  props: {
    phone: {
      type: String,
      default: ''
    }
  },
  data() {
    return{
      isSend: false,
      sendLoading: false,
      timeNumber: 60,
      timer: null,
      timestamp: ''
    }
  },
  computed: {
    btnText() {
      return this.isSend ? this.timeNumber + 's' : '获取验证码'
    }
  },
  methods: {
    // 获取验证码
    sendCheckSms() {
      this.timestamp = new Date().getTime()
      this.sendLoading = true
      sendCheckSms({ accNbr: this.phone, smsCodeSerialNbr: this.timestamp }).then((data) => {
        this.sendLoading = false
        const { errorCode, errorMsg }  = data
        if (errorCode === '0') {
          this.timer = setInterval(() => {
            if (this.timeNumber <= 1) {
              this.clearTime()
            } else {
              this.isSend = true
              this.timeNumber --
            }
          }, 1000)
          this.$message.success('已发送验证码')
          this.isSend = true
        } else {
          this.$message.error(errorMsg)
        }
      }).catch(() => {
        this.sendLoading = false
      })
    },
    // 校验验证码
    checkPwdCode(smsCheckCode){
      return new Promise((resolve, reject) => {
        checkSmsCode({ smsCheckCode, accNbr: this.phone, smsCodeSerialNbr: this.timestamp }).then((data) => {
          const { errorCode, errorMsg }  = data
          if (errorCode === '0') {
            this.clearTime()
            resolve(true)
          } else {
            this.$message.error(errorMsg)
            reject(false)
          }
        }).catch(() => {
          reject(false)
        })
      })
    },
    clearTime() {
      this.timeNumber = 60
      clearInterval(this.timer)
      this.isSend = false
    },
  }
}
</script>

<style scoped>

</style>
