const TEMPLATE_TYPE = [
  [1, '验证码类'],
  [2, '推广类'],
  [3, '通知类']
];

const TYPE_OPTIONS = [
  {label: '验证码类', value: 1},
  {label: '推广类', value: 2},
  {label: '通知类', value: 3}
];

const APP_STATUS_OPTIONS = [
  {label: '正常', value: 0},
  {label: '暂停', value: 1},
  {label: '未审核', value: 2},
  {label: '审核不通过', value: 3},
];

const APP_STATUS = [
  [0, '正常'],
  [1, '暂停'],
  [2, '未审核'],
  [3, '审核不通过']
];

const TEMPLATE_STATUS = [
  [0, '初始化'],
  [1, '待审核'],
  [2, '审核通过-激活'],
  [3, '审核通过-去激活'],
  [4, '审核不通过'],
  [5, '已激活']
];
const SIGN_STATUS = [
  [0, '待审核'],
  [1, '处理完毕'],
  [2, '已审核未处理'],
  [3, '审核不通过'],
  [4, '待激活'],
  [5, '激活待审核中'],
  [6, '已删除'],
]

const SIGN_STATUS_OPTIONS = [
  { label: '待审核', value: 0 },
  { label: '处理完毕', value: 1 },
  { label: '已审核未处理', value: 2 },
  { label: '审核不通过', value: 3 },
  { label: '待激活', value: 4 },
  { label: '激活待审核中', value: 5 },
  { label: '已删除', value: 6 }
]

const SIGN_SOURCE = [
  [1, '企事业单位的全称或简称'],
  [2, '工信部备案网站的全称或简称'],
  [3, 'APP应用的全称或简称'],
  [4, '公众号或小程序的全称或简称'],
  [5, '电商平台店铺名的全称或简称'],
  [6, '商标名的全称或简称'],
]

const SIGN_SOURCE_OPTIONS = [
  { label: '企事业单位的全称或简称', value: 1 },
  { label: '工信部备案网站的全称或简称', value: 2 },
  { label: 'APP应用的全称或简称', value: 3 },
  { label: '公众号或小程序的全称或简称', value: 4 },
  { label: '电商平台店铺名的全称或简称', value: 5 },
  { label: '商标名的全称或简称', value: 6 }
]

const VAR_PROPS = [
  ['PHONE', '电话号码'],
  ['CHARDIGIT', '其他号码（如验证码、订单号、密码等）'],
  ['DATETIME', '时间'],
  ['MONEY', '金额'],
  ['TEXT', '其他（如名称、账号、地址等）'],
]

const VAR_PROPS_OPTIONS = [
  { label: '电话号码', value: 'PHONE' },
  { label: '其他号码（如验证码、订单号、密码等）', value: 'CHARDIGIT' },
  { label: '时间', value: 'DATETIME' },
  { label: '金额', value: 'MONEY' },
  { label: '其他（如名称、账号、地址等）', value: 'TEXT' }
]

const TASK_STATUS_OPTIONS = [
  { label: '待执行', value: 0 },
  { label: '已撤销', value: 1 },
  { label: '提交处理中', value: 2 },
  { label: '提交处理成功', value: 3 },
  { label: '已删除', value: 4 },
]

const TASK_STATUS = [
  [0, '待执行'],
  [1, '已撤销'],
  [2, '提交处理中'],
  [3, '提交处理成功'],
  [4, '已删除']
]

const SEND_RESULT_STATUS = [
  [0, '失败'],
  [1, '成功'],
  [2, '发送中'],
  [3, '未发送'],
  [4, '不需要发送'],
  [5, '短信关联任务已撤销'],
]

const SEND_RESULT_OPTIONS = [
  { label: '失败', value: 0 },
  { label: '成功', value: 1 },
  { label: '发送中', value: 2 },
  { label: '未发送', value: 3 },
  { label: '不需要发送', value: 4 },
  { label: '短信关联任务已撤销', value: 5 },
]

// 修改不可点击：1，2，6
// 处理按钮不可点击：1，2，3，6

export { TEMPLATE_TYPE, TYPE_OPTIONS, TEMPLATE_STATUS, SIGN_STATUS, SIGN_STATUS_OPTIONS, SIGN_SOURCE, SIGN_SOURCE_OPTIONS,
  VAR_PROPS, VAR_PROPS_OPTIONS, TASK_STATUS_OPTIONS, TASK_STATUS, SEND_RESULT_STATUS, SEND_RESULT_OPTIONS, APP_STATUS_OPTIONS,
  APP_STATUS}
