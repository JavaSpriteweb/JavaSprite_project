import Vue from 'vue'
import App from './App.vue'
import { initRouter } from './router'
import './theme/index.less'
import Antd from 'ant-design-vue'
import Viser from 'viser-vue'
import '@/mock'
import store from './store'
import 'animate.css/source/animate.css'
import Plugins from '@/plugins'
import Bus from '@/utils/bus'
import { initI18n } from '@/utils/i18n'
import bootstrap from '@/bootstrap'
import 'moment/locale/zh-cn'
import './icons'; // icon
import _ from 'lodash'
import Mixin from './mixins'

const router = initRouter(store.state.setting.asyncRoutes)
const i18n = initI18n('CN', 'US')

Vue.use(Antd)
import { Input } from 'ant-design-vue'
if (!!window.ActiveXObject || 'ActiveXObject' in window) {
  Input.methods.handleReset = function () {
    this.stateValue = ''
    this.$emit('change.value', '')
  }
}
Vue.config.productionTip = false
Vue.use(Viser)
Vue.use(Plugins)
Vue.mixin(Mixin)

Vue.prototype.$_ = _
Vue.prototype.$bus = Bus

bootstrap({ router, store, i18n, message: Vue.prototype.$message })

new Vue({
  router,
  store,
  i18n,
  render: h => h(App),
}).$mount('#app')
