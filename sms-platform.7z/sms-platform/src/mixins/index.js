let mixin={
  data(){
    return{
      myPagination: {
        total: 0,
        current: 1,
        pageSize: 10,
        pageSizeOptions: ['10', '20', '30', '50', '100'],
        showSizeChanger: true,
        showQuickJumper: true,
        showTotal: (total) => {
          if (total && typeof total !== 'undefined') {
            return '共' + total + '条'
          }
        },
        onChange: (current, pageSize) => {
          if (typeof current !== 'undefined' && typeof pageSize !== 'undefined') {
            this.handlePageChange(current, pageSize)
          }
        },
        onShowSizeChange: (current, pageSize) => {
          if (typeof current !== 'undefined' && typeof pageSize !== 'undefined') {
            this.handlePageChange(1, pageSize)
          }
        },
        itemRender: (current, type, originalElement) => {
          if (type === 'prev') {
            return '上一页' + ' '
          } else if (type === 'next') {
            return ' ' + '下一页'
          }
          return originalElement
        }
      },

    }
  },
  computed: {
    permissions() {
      return this.$store.getters['account/permissions']
    },
    tablePagination() {
      return this.myPagination?.total > 0 ? this.myPagination : false
    }
  },
  methods: {
    // 权限功能点
    hasPermission(code) {
      if (this.permissions?.length > 0) {
        return this.permissions.some((ele) => ele.functionCode === code)
      } else {
        return false
      }
    },
    handlePageChange (current, pageSize) {
      this.myPagination.current = current
      this.myPagination.pageSize = pageSize
      this.handleTableChange({current, pageSize})
    },
    _isNull (str) {
      if (str !== null && typeof str !== 'undefined' && str !== '' && str !== 'null') {
        if (typeof str === 'string') {
          if (str.trim() !== '') {
            return false
          } else {
            return true
          }
        } else {
          return false
        }
      } else {
        return true
      }
    }
  }
};
export default mixin
