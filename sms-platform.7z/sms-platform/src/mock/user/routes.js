import Mock from 'mockjs'

Mock.mock(`${process.env.VUE_APP_API_BASE_URL}/routes`, 'get', () => {
  let result = {}
  result.errorCode = '0'
  result.data = [{
    router: 'root',
    children: [
      {
        router: 'application',
        children: ['appList', 'createApp', 'appDetail']
      },
      {
        router: 'sign',
        children: ['signList', 'createSign', 'signDetail', 'signAudit']
      },
      {
        router: 'template',
        children: ['templateList', 'createTemplate', 'templateDetail']
      },
      {
        router: 'templateAudit',
        children: ['templateAuditList']
      },
      {
        router: 'task',
        children: ['taskList', 'createTask']
      },
      {
        router: 'smsDetail',
        children: ['smsDetailList']
      },
      {
        router: 'account',
        children: ['accountList', 'createAccount', 'accountDetail']
      },
    ]
  }]
  return result
})
