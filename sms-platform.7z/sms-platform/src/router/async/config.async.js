import routerMap from './router.map'
import {parseRoutes} from '@/utils/routerUtil'

// 异步路由配置
const routesConfig = [
  {
    menuCode: 'root',
    path: '/'
  },
  {
    menuCode: 'login',
    path: '/login'
  },
  {
    menuCode: 'autologin',
    path: '/autologin'
  },
  {
    menuCode: 'exp404',
    path: '/404'
  }
]

const options = {
  mode: 'history',
  routes: parseRoutes(routesConfig, routerMap)
}

export default options
