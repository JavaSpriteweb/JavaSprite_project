// 视图组件
const view = {
  tabs: () => import('@/layouts/tabs'),
  blank: () => import('@/layouts/BlankView'),
  page: () => import('@/layouts/PageView')
}

// 路由组件注册
const routerMap = {
  login: {
    authority: '*',
    path: '/login',
    component: () => import('@/views/login')
  },
  autologin: {
    authority: '*',
    path: '/autologin',
    component: () => import('@/views/login')
  },
  exp404: {
    name: 'exp404',
    path: '*',
    component: () => import('@/views/exception/404')
  },
  root: {
    path: '/',
    name: '首页',
    redirect: '/application/list',
    component: view.tabs
  },
  application: {
    name: '短信应用',
    component: view.page,
    redirect: '/application/list',
  },
  appList: {
    path: 'list',
    name: '应用列表',
    invisible: true,
    component: () => import('@/views/application/index'),
  },
  createApp: {
    path: 'create',
    name: '创建应用',
    invisible: true,
    component: () => import('@/views/application/AppForm'),
  },
  appDetail: {
    path: 'detail',
    name: '应用详情',
    invisible: true,
    component: () => import('@/views/application/AppForm'),
  },
  appAudit: {
    path: 'detail',
    name: '应用审核',
    invisible: true,
    component: () => import('@/views/application/AppAudit'),
  },
  template: {
    name: '短信模板',
    component: view.page,
    redirect: '/template/list',
  },
  templateList: {
    path: 'list',
    name: '模板列表',
    component: () => import('@/views/template/index'),
    invisible: true
  },
  createTemplate: {
    path: 'create',
    name: '创建模板',
    component: () => import('@/views/template/TemplateTab'),
    invisible: true
  },
  templateDetail: {
    path: 'detail',
    name: '模板详情',
    component: () => import('@/views/template/TemplateTab'),
    invisible: true
  },
  sign: {
    name: '短信签名',
    component: view.page,
    redirect: '/sign/list',
  },
  signList: {
    path: 'list',
    name: '签名列表',
    component: () => import('@/views/sign/index'),
    invisible: true
  },
  createSign: {
    path: 'create',
    name: '创建签名',
    component: () => import('@/views/sign/SignForm'),
    invisible: true
  },
  signDetail: {
    path: 'detail',
    name: '签名详情',
    component: () => import('@/views/sign/SignForm'),
    invisible: true
  },
  signAudit: {
    path: 'audit',
    name: '签名审核',
    component: () => import('@/views/sign/SignAudit'),
    invisible: true
  },
  task: {
    name: '群发助手',
    component: view.page,
    redirect: '/task/list',
  },
  taskList: {
    path: 'list',
    name: '群发列表',
    component: () => import('@/views/task/index'),
    invisible: true
  },
  createTask: {
    path: 'create',
    name: '创建群发任务',
    component: () => import('@/views/task/TaskForm'),
    invisible: true
  },
  account: {
    name: '用户管理',
    component: view.page,
    redirect: '/account/list',
  },
  accountList: {
    path: 'list',
    name: '用户列表',
    component: () => import('@/views/account/index'),
    invisible: true
  },
  createAccount: {
    path: 'create',
    name: '新增用户',
    component: () => import('@/views/account/AccountForm'),
    invisible: true
  },
  accountDetail: {
    path: 'detail',
    name: '用户详情',
    component: () => import('@/views/account/AccountForm'),
    invisible: true
  },
  templateAudit: {
    name: '模板审核',
    component: view.page,
    redirect: '/templateAudit/list',
  },
  templateAuditList: {
    path: 'list',
    name: '模板审核列表',
    component: () => import('@/views/templateAudit/index'),
    invisible: true
  },
  smsDetail: {
    name: '发送详情',
    component: view.page,
    redirect: '/smsDetail/list',
  },
  smsDetailList: {
    path: 'list',
    name: '发送详情列表',
    component: () => import('@/views/task/SendDetail'),
    invisible: true
  },
  smsOperateLog: {
    name: '日志管理',
    component: view.page,
    redirect: '/smsOperateLog/list',
  },
  smsOperateLogList: {
    path: 'list',
    name: '日志列表',
    component: () => import('@/views/smsOperateLog/index'),
    invisible: true
  },
  statistics: {
    name: '统计分析',
    component: view.page,
    redirect: '/statistics/list',
  },
  statisticsList: {
    path: 'list',
    name: '统计图表',
    component: () => import('@/views/statistics/index'),
    invisible: true
  },
  thresholdValue: {
    name: '阈值提醒',
    component: view.page,
    redirect: '/thresholdValue/list',
  },
  thresholdValueList: {
    path: 'list',
    name: '阈值提醒列表',
    component: () => import('@/views/thresholdValue/index'),
    invisible: true
  }
}
export default routerMap

