import TabsView from '@/layouts/tabs/TabsView'
import PageView from '@/layouts/PageView'

// 开启异步路由时无需该文件

// 路由配置
const options = {
  routes: [
    {
      path: '/autologin',
      name: '自动登录',
      component: () => import('@/views/login')
    },
    {
      path: '/login',
      name: '登录页',
      component: () => import('@/views/login')
    },
    {
      path: '/404',
      name: '404',
      component: () => import('@/views/exception/404'),
    },
    {
      path: '/',
      name: '首页',
      component: TabsView,
      redirect: '/application/list',
      children: [
        {
          path: 'application',
          redirect: '/application/list',
          name: '短信应用',
          meta: {
            title: '短信应用',
            page: {
              cacheAble: false
            }
          },
          component: PageView,
          children: [
            {
              path: 'list',
              name: '应用列表',
              meta: { invisible: true, title: '应用列表' },
              component: () => import('@/views/application/index'),
            },
            {
              path: 'create',
              name: '新建应用',
              meta: { invisible: true, title: '新建应用' },
              component: () => import('@/views/application/AppForm'),
            },
            {
              path: 'detail',
              name: '应用详情',
              meta: { invisible: true, name: '应用详情' },
              component: () => import('@/views/application/AppForm'),
            },
            {
              path: 'audit',
              component: () => import('@/views/application/AppAudit'),
              name: '应用审核',
              meta: { invisible: true }
            }
          ]
        },
        {
          path: 'sign',
          name: '短信签名',
          redirect: '/sign/list',
          component: PageView,
          meta: {
            page: {
              cacheAble: false
            }
          },
          children: [
            {
              path: 'list',
              component: () => import('@/views/sign/index'),
              name: '签名列表',
              meta: { invisible: true }
            },
            {
              path: 'create',
              name: '新建签名',
              meta: {
                invisible: true
              },
              component: () => import('@/views/sign/SignForm'),
            },
            {
              path: 'detail',
              component: () => import('@/views/sign/SignForm'),
              name: '签名详情',
              meta: { invisible: true }
            },
            {
              path: 'audit',
              component: () => import('@/views/sign/SignAudit'),
              name: '签名审核',
              meta: { invisible: true }
            }
          ]
        },
        {
          path: 'template',
          name: '短信模板',
          redirect: '/template/list',
          component: PageView,
          meta: {
            name: '短信模板',
            page: {
              cacheAble: false
            }
          },
          children: [
            {
              path: 'list',
              component: () => import('@/views/template/index'),
              name: '模板列表',
              meta: { invisible: true, name: '模板列表' }
            },
            {
              path: 'create',
              name: '新建模板',
              meta: {
                invisible: true,
                name: '新建模板'
              },
              component: () => import('@/views/template/TemplateTab'),
            },
            {
              path: 'detail',
              component: () => import('@/views/template/TemplateTab'),
              name: '模板详情',
              meta: { invisible: true,  name: '模板详情' }
            }
          ]
        },
        {
          path: 'templateAudit',
          name: '模板审核',
          redirect: '/templateAudit/list',
          component: PageView,
          meta: {
            page: {
              cacheAble: false
            }
          },
          children: [
            {
              path: 'list',
              component: () => import('@/views/templateAudit/index'),
              name: '审核列表',
              meta: { invisible: true }
            }
          ]
        },
        {
          path: 'task',
          name: '群发助手',
          redirect: '/task/list',
          component: PageView,
          meta: {
            page: {
              cacheAble: false
            }
          },
          children: [
            {
              path: 'list',
              component: () => import('@/views/task/index'),
              name: '群发列表',
              meta: { invisible: true }
            },
            {
              path: 'create',
              component: () => import('@/views/task/TaskForm'),
              name: '创建群发任务',
              meta: { invisible: true }
            }
          ]
        },
        {
          path: 'smsDetail',
          name: '短信详情',
          redirect: '/smsDetail/list',
          component: PageView,
          meta: {
            page: {
              cacheAble: false
            }
          },
          children: [
            {
              path: 'list',
              component: () => import('@/views/task/SendDetail'),
              name: '短信列表',
              meta: { invisible: true }
            }
          ]
        },
        {
          path: 'account',
          name: '用户管理',
          redirect: '/account/list',
          component: PageView,
          meta: {
            page: {
              cacheAble: false
            }
          },
          children: [
            {
              path: 'list',
              component: () => import('@/views/account/index'),
              name: '用户列表',
              meta: { invisible: true }
            },
            {
              path: 'create',
              name: '新建用户',
              meta: {
                invisible: true
              },
              component: () => import('@/views/account/AccountForm'),
            },
            {
              path: 'detail',
              component: () => import('@/views/account/AccountForm'),
              name: '用户详情',
              meta: { invisible: true }
            }
          ]
        },
        {
          path: 'smsOperateLog',
          name: '日志管理',
          redirect: '/smsOperateLog/list',
          component: PageView,
          meta: {
            page: {
              cacheAble: false
            }
          },
          children: [
            {
              path: 'list',
              component: () => import('@/views/smsOperateLog/index'),
              name: '日志列表',
              meta: { invisible: true }
            }
          ]
        },
        {
          path: 'statistics',
          name: '统计分析',
          redirect: '/statistics/list',
          component: PageView,
          meta: {
            page: {
              cacheAble: false
            }
          },
          children: [
            {
              path: 'list',
              component: () => import('@/views/statistics/index'),
              name: '统计图表',
              meta: { invisible: true }
            }
          ]
        },
        {
          path: 'thresholdValue',
          name: '阈值提醒',
          redirect: '/thresholdValue/list',
          component: PageView,
          meta: {
            page: {
              cacheAble: false
            }
          },
          children: [
            {
              path: 'list',
              component: () => import('@/views/thresholdValue/index'),
              name: '阈值提醒列表',
              meta: { invisible: true }
            }
          ]
        }
      ]
    }
  ]
}

export default options
