import { request, METHOD } from '@/utils/request'

const prefix = '/api/smsPlatform';

/**
 * 查询用户列表
 */
export function getAccounts(params) {
  return request(`${prefix}/smsacct/query`, METHOD.POST, params);
}

/**
 * 新增用户
 */
export function addAccount(params) {
  Object.assign(params, { operateInfo: '新增用户' })
  return request(`${prefix}/smsacct/create`, METHOD.POST, params);
}

/**
 * 修改用户
 */
export function updateAccount(params) {
  Object.assign(params, { operateInfo: '修改用户' })
  return request(`${prefix}/smsacct/upsmsacct`, METHOD.POST, params);
}

/**
 * 用户信息查询
 */
export function getAccountInfo(params) {
  return request(`${prefix}/smsacct/qrysmsacct`, METHOD.POST, params);
}

/**
 * 用户名判重
 */
export function isExist(params) {
  return request(`${prefix}/smsacct/qrysmsacctrepeat`, METHOD.POST, params);
}
