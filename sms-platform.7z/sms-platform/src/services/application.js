import { request, METHOD } from '@/utils/request'

const prefix = '/api/smsplatform';


/**
 * 查询短信应用列表
 */
export function getApplications(params) {
  return request(`${prefix}/apps/queryapps`, METHOD.POST, params);
}

/**
 * 新建短信应用
 */
export function addApp(params) {
  Object.assign(params, { operateInfo: '新建短信应用' })
  return request(`${prefix}/apps/create`, METHOD.POST, params);
}

/**
 * 更新短信应用
 */
export function updateApp(params) {
  Object.assign(params, { operateInfo: '更新短信应用' })
  return request(`${prefix}/apps/update`, METHOD.POST, params);
}

/**
 * 发送验证码
 */
export function sendCheckSms(params) {
  Object.assign(params, { operateInfo: '发送验证码' })
  return request(`${prefix}/apps/sendchecksms`,METHOD.POST, params);
}

/**
 * 短信验证码校验
 */
export function checkSmsCode(params) {
  Object.assign(params, { operateInfo: '短信验证码校验' })
  return request(`${prefix}/apps/checksmscode`,METHOD.POST, params);
}

/**
 * 显示AppSecret
 */
export function getSecret(params) {
  return request(`${prefix}/apps/qryappSecret`,METHOD.POST, params);
}

/**
 * 更新AppSecret
 */
export function updateSecret(params) {
  Object.assign(params, { operateInfo: '更新AppSecret' })
  return request(`${prefix}/apps/updateappsecret`,METHOD.POST, params);
}

/**
 * 短信名称判重
 */
export function isExist(params) {
  return request(`${prefix}/apps/checksmsappname`,METHOD.POST, params);
}

/**
 * 短信应用审核
 */
export function aduitApp(params) {
  Object.assign(params, { operateInfo: '短信应用审核' })
  return request(`${prefix}/apps/aduitsmsapp`,METHOD.POST, params);
}

/**
 * 通道号判重
 */
export function isExistWayId(params) {
  return request(`${prefix}/apps/isrepeatwayid`,METHOD.POST, params);
}

/**
 * 查询应用下拉列表
 */
export function getAppOptions(params) {
  return request(`${prefix}/apps/smsappsname`,METHOD.POST, params);
}
