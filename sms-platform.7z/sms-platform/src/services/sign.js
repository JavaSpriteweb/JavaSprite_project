import { request, METHOD } from '@/utils/request'

const prefix = '/api/smsplatform';

/**
 * 查询短信签名列表
 */
export function getSignList(params) {
  return request(`${prefix}/sign/get`, METHOD.POST, params);
}

/**
 * 获取签名详情
 */
export function getSignDetail(params) {
  return request(`${prefix}/sign/getSign`, METHOD.POST, params);
}

/**
 * 短信签名上传文件
 */
export function uploadFile(params) {
  Object.assign(params, { operateInfo: '短信签名上传文件' })
  return request(`${prefix}/sign/uploadTemp`, METHOD.POST, params);
}

/**
 * 新增短信签名
 */
export function addSign(params) {
  Object.assign(params, { operateInfo: '新增短信签名' })
  return request(`${prefix}/sign/add`, METHOD.POST, params);
}

/**
 * 更新短信签名
 */
export function updateSign(params) {
  Object.assign(params, { operateInfo: '更新短信签名' })
  return request(`${prefix}/sign/modify`, METHOD.POST, params);
}

/**
 * 删除短信签名
 */
export function deleteSign(params) {
  Object.assign(params, { operateInfo: '删除短信签名' })
  return request(`${prefix}/sign/delete`, METHOD.POST, params);
}

/**
 * 判重签名名称
 */
export function isExist(params) {
  return request(`${prefix}/sign/checkBeforeAdd`, METHOD.POST, params);
}

/**
 * 短信签名催审
 */
export function urgeSign(params) {
  Object.assign(params, { operateInfo: '短信签名催审' })
  return request(`${prefix}/sign/urge`, METHOD.POST, params);
}

/**
 * 短信签名审核
 */
export function checkSign(params) {
  Object.assign(params, { operateInfo: '短信签名审核' })
  return request(`${prefix}/sign/check`, METHOD.POST, params);
}

/**
 * 短信签名配置通道号
 */
export function setConfigWay(params) {
  Object.assign(params, { operateInfo: '短信签名配置通道号' })
  return request(`${prefix}/sign/configWay`, METHOD.POST, params);
}

/**
 * 根据应用查询签名
 */
export function getSignOptions(params) {
  return request(`${prefix}/sign/getSignListByAppId`, METHOD.POST, params);
}


/**
 * 获取图片
 */
export function getPicture(params) {
  return request(`${prefix}/sign/showPicture`, METHOD.POST, params);
}
