import { request, METHOD } from "@/utils/request";

const prefix = "/api/smsPlatform"

/**
 * 操作日志插入
 */
export function insertOperationLog(params) {
  return request(`${prefix}/smsOperateLog/create`, METHOD.POST, params);
}

export function getOperationLogs(params) {
  return request(`${prefix}/smsOperateLog/retrieve`, METHOD.POST, params);
}
