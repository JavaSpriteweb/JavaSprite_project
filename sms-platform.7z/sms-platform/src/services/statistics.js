import { request, METHOD } from "@/utils/request";

const prefix = "/api/smsplatform"

/**
 * 查询统计数据
 */

export function getSummaryData(params) {
  return request(`${prefix}/statistics/businessInfo`, METHOD.POST, params);
}

export function getFailBusinessInfo(params) {
  return request(`${prefix}/statistics/failBusinessInfo`, METHOD.POST, params);
}

export function getAllSignNames(params) {
  return request(`${prefix}/statistics/signName`, METHOD.POST, params);
}
