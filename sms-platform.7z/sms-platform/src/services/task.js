import { request, METHOD } from '@/utils/request'

const prefix = '/api/smsplatform';

/*************************************  群发助手  **************************************************/

/**
 * 查询所有任务名称
 */
export function getTaskOptions(params) {
  return request(`${prefix}/send/getSelectList`, METHOD.POST, params);
}

/**
 * 查询群发任务列表
 */
export function getTaskList(params) {
  return request(`${prefix}/send/getTaskList`, METHOD.POST, params);
}

/**
 * 删除任务
 */
export function deleteTask(params) {
  Object.assign(params, { operateInfo: '删除任务' })
  return request(`${prefix}/send/delete`, METHOD.POST, params);
}

/**
 * 撤销任务
 */
export function revokeTask(params) {
  Object.assign(params, { operateInfo: '撤销任务' })
  return request(`${prefix}/send/revoke`, METHOD.POST, params);
}

/**
 * 查询短信签名/模板下拉
 */
export function getOptions(params) {
  return request(`${prefix}/send/getSignOrTemplate`, METHOD.POST, params);
}

/**
 * 根据签名ID查询模板列表
 */
export function getTemplates(params) {
  return request(`${prefix}/send/getTemplateListBySignId`, METHOD.POST, params);
}

/**
 * 新增任务
 */
export function addTask(params) {
  Object.assign(params, { operateInfo: '新增任务' })
  return request(`${prefix}/send/add`, METHOD.POST, params, { headers: {
      'Content-Type': 'multipart/form-data'
    }});
}

/*************************************  短信详情  **************************************************/

/**
 * 根据用户查询签名列表
 */
export function getSignList(params) {
  return request(`${prefix}/send/getSignListByAccountId`, METHOD.POST, params);
}

/**
 * 根据用户查询模板列表
 */
export function getTempListByAcct(params) {
  return request(`${prefix}/send/getTemplateListByAppId`, METHOD.POST, params);
}

/**
 * 根据签名查询模板列表
 */
export function getTempListBySign(params) {
  return request(`${prefix}/send/getTemplateListBySignIdInDetails`, METHOD.POST, params);
}


/**
 * 查询发送详情列表
 */
export function getSendSmsList(params) {
  return request(`${prefix}/send/getSendDetails`, METHOD.POST, params);
}
