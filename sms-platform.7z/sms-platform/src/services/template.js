import { request, METHOD } from '@/utils/request'

const prefix = '/api/smsPlatform';

/**
 * 查询短信模板列表
 */
export function getTemplates(params) {
  return request(`${prefix}/template/retrieve`, METHOD.POST, params);
}

/**
 * 新增短信模板
 */
export function addTemplate(params) {
  Object.assign(params, { operateInfo: '新增短信模板' })
  return request(`${prefix}/template/create`, METHOD.POST, params);
}

/**
 * 更新短信模板
 */
export function updateTemplate(params) {
  Object.assign(params, { operateInfo: '更新短信模板' })
  return request(`${prefix}/template/update`, METHOD.POST, params);
}

/**
 * 删除短信模板
 */
export function deleteTemplate(params) {
  Object.assign(params, { operateInfo: '删除短信模板' })
  return request(`${prefix}/template/delete`, METHOD.POST, params);
}

/**
 * 短信模板提交审核
 */
export function submitTemplate(params) {
  Object.assign(params, { operateInfo: '短信模板提交审核' })
  return request(`${prefix}/template/submit`, METHOD.POST, params);
}

/**
 * 短信模板催审
 */
export function pushOnTemplate(params) {
  Object.assign(params, { operateInfo: '短信模板催审' })
  return request(`${prefix}/template/pushOn`, METHOD.POST, params);
}

/**
 * 短信模板名称判重
 */
export function isExist(params) {
  return request(`${prefix}/template/existsTemplateName`, METHOD.POST, params);
}

/**
 * 短信模板审核通过
 */
export function passTemplate(params) {
  Object.assign(params, { operateInfo: '短信模板审核通过' })
  return request(`${prefix}/template/passAudit`, METHOD.POST, params);
}

/**
 * 短信模板审核不通过
 */
export function rejectTemplate(params) {
  Object.assign(params, { operateInfo: '短信模板审核不通过' })
  return request(`${prefix}/template/noPassAudit`, METHOD.POST, params);
}

/**
 * Domain表数据查询
 * params 根据编码不同查询不同数据
 */
export function getDomainData(params) {
  return request(`${prefix}/domain/retrieve`, METHOD.POST, params);
}
