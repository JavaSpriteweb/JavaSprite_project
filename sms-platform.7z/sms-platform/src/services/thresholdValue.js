import { request, METHOD } from "@/utils/request";

const prefix = "/api/smsplatform"

/**
 * 操作日志插入
 */
export function getThresholdValue(params) {
  return request(`${prefix}/apps/thresholdvalue`, METHOD.POST, params);
}
