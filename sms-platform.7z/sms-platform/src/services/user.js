import {ROUTES} from '@/services/api'
import {request, METHOD, removeAuthorization} from '@/utils/request'

const prefix = '/api/smsPlatform';
const prefix1 = '/api/smsplatform';


/**
 * 登录服务
 * @param name 账户名
 * @param password 账户密码
 * @returns {Promise<AxiosResponse<T>>}
 */
export async function login(params) {
  return request(`${prefix}/smsacct/login`, METHOD.POST, params)
}

export async function getRoutesConfig() {
  return request(ROUTES, METHOD.GET)
}

// 单点登录验证票据信息
export async function validate(params) {
  return request('/cas/validate', METHOD.GET, params)
}

// 获取单点获取token
export async function gettoken(params) {
  return request(`${prefix}/smsacct/gettoken`, METHOD.POST, params)
}

// 获取单点签名
export async function getSignature(params) {
  return request(`${prefix}/smsacct/signature`, METHOD.POST, params)
}

/**
 * 获取路由菜单权限
 */
export async function getMenu(params) {
  return request(`${prefix1}/permission/menu`, METHOD.POST, params)
}

/**
 * 获取功能权限
 */
export async function getFunctionRoot(params) {
  return request(`${prefix1}/permission/function`, METHOD.POST, params)
}

/**
 * 修改密码
 */
export async function updatePassword(params) {
  Object.assign(params, { operateInfo: '修改密码' })
  return request(`${prefix}/smsacct/uppassword`, METHOD.POST, params)
}

/**
 * 退出登录
 */
export function logout() {
  localStorage.removeItem(process.env.VUE_APP_ROUTES_KEY)
  localStorage.removeItem(process.env.VUE_APP_PERMISSIONS_KEY)
  localStorage.removeItem(process.env.VUE_APP_USER_KEY)
  localStorage.removeItem(process.env.VUE_APP_ROLES_KEY)
  removeAuthorization()
}
export default {
  login,
  logout,
  getRoutesConfig
}
