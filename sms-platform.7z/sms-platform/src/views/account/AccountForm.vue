<template>
  <div class="account-form">
    <a-form
      :form="form"
      :label-col="{ span: 5 }"
      :wrapper-col="{ span: 12 }"
      @submit="handleSubmit"
    >
      <a-form-item label="绑定号码">
        <a-input v-decorator="['phone',{ rules: [
        { required: true, message: '号码不能为空' },
        { pattern: /^((\\+86)|(86))?[1][3456789][0-9]{9}$/, message: '请输入正确的手机号'}]}]"
         placeholder="请输入绑定号码"
        ></a-input>
      </a-form-item>
      <a-form-item v-if="isCreate" label="账户名称">
        <a-input v-decorator="['userName',{ rules: [
        { max: 12, message: '账户名称不能超过12个字' },
        { required: true, message: '账户名称不能为空' },
        { validator: validUserName }
        ], trigger: 'blur'}]"
         placeholder="请输入账户名称"
        ></a-input>
      </a-form-item>
      <a-form-item v-if="isCreate" label="密码">
        <a-input v-decorator="['password',
        {rules: [{ required: true, message: '密码不能为空'},
        { pattern: /^[a-zA-Z0-9-*/+.~!@#$%^&*()]{8,12}$/, message: '密码支持数字、字母、特殊符号的8-12位字符' },
        ]}]"></a-input>
      </a-form-item>
      <a-form-item label="状态">
        <a-radio-group name="radioGroup" v-decorator="['accountStatus']">
          <a-radio :value="1">可用</a-radio>
          <a-radio :value="0">禁用</a-radio>
        </a-radio-group>
      </a-form-item>
      <a-form-item v-if="false" label="用户类型">
        <a-radio-group name="radioGroup" v-decorator="['accountType']">
          <a-radio :value="1">用户</a-radio>
          <a-radio :value="0">管理员</a-radio>
        </a-radio-group>
      </a-form-item>
      <a-form-item :wrapper-col="{ span: 24 }" style="text-align: center">
        <a-button @click="goBack" style="margin-right: 20px">返回</a-button>
        <a-button v-if="hasPermission(addOrUpdate)" :loading="loading" type="primary"  html-type="submit">确定</a-button>
      </a-form-item>
    </a-form>
  </div>
</template>

<script>
import { addAccount, updateAccount, isExist } from '@/services/account'
import {mapState} from 'vuex'
import md5 from 'js-md5';

export default {
  name: "AccountForm",
  data() {
    return {
      form: this.$form.createForm(this),
      isCreate: true,
      loading: false,
      formData: {},
      nameInput: null,
    }
  },
  computed: {
    ...mapState('account', ['user']),
    addOrUpdate() {
      return this.isCreate ? 'createAccount' : 'accountDetail'
    }
  },
  mounted() {
    if (this.$route.params.userName) {
      this.isCreate = false
      this.init()
    } else {
      this.form.setFieldsValue({ accountStatus: 1, accountType: 1 })
    }
  },
  methods: {
    init() {
      const data = this.$route.params
      this.formData = data
      this.$nextTick(() => {
        this.form.setFieldsValue(this.$_.pick(data, 'phone', 'accountStatus'))
      })
    },
    addAccount(params) {
      params = {...params, password: md5(params.password)}
      // 新建用户只能是管理员
      params.accountType = 0
      addAccount(params).then((data) => {
        const { errorCode, errorMsg }  = data
        if (errorCode === '0') {
          this.$message.success('添加用户成功')
          this.$router.push('/account/list')
        } else {
          this.$message.error(errorMsg)
        }
        this.loading = false
      }).catch(() => {
        this.loading = false
      })
    },
    updateAccount(params) {
      const { phone, accountStatus } = params
      updateAccount({ phone, accountStatus , accountId: this.formData.accountId }).then((data) => {
        const { errorCode, errorMsg }  = data
        if (errorCode === '0') {
          this.$message.success('更新用户成功')
          this.$router.push('/account/list')
        } else {
          this.$message.error(errorMsg)
        }
        this.loading = false
      })
    },
    handleSubmit(e) {
      this.loading = true
      e.preventDefault();
      const validItems = this.isCreate ? null : ['phone', 'accountStatus']
      this.form.validateFields(validItems, (err, values) => {
        if (!err) {
          if (this.isCreate) {
            this.addAccount(values);
          } else {
            this.updateAccount(values);
          }
        } else {
          this.loading = false
        }
      });
    },
    validUserName(rule, value, callback) {
      if (value && value !== this.formData.userName) {
        isExist({ userName: value }).then((res) => {
          if (res.errorCode !== '0') {
            callback(res.errorMsg)
          } else {
            callback()
          }
        })
      } else {
        callback()
      }
    },
    goBack() {
      this.$router.go(-1)
    },
  }
}
</script>

<style lang="less" scoped>
.account-form{
  background: #ffffff;
  padding: 20px;
}
</style>
