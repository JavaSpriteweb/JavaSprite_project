<template>
  <div class="account-container">
    <div class="header">
      <a-form layout="inline" @submit="handleSearch">
        <a-form-item label="用户名称">
          <a-input placeholder="请输入名称" v-model="userName" allowClear></a-input>
        </a-form-item>
        <a-form-item>
          <a-button v-if="hasPermission('accountList')" type="primary" html-type="submit">查询</a-button>
          <a-button v-if="hasPermission('createAccount')" type="primary" @click="jumpToCreate" style="margin-left: 10px">新增用户</a-button>
        </a-form-item>
      </a-form>
    </div>
    <div class="account-table">
      <a-table
        :columns="tableColumns"
        :data-source="tableData"
        rowKey="accountId"
        :scroll="{x: 900}"
        :loading="loading"
        :pagination="tablePagination"
      >
        <template slot="accountStatus" slot-scope="text">
        <span >{{text === 0 ? '禁用' : '可用'}}</span>
        </template>
        <template slot="accountType" slot-scope="text">
          <span >{{text === 0 ? '管理员' : '用户'}}</span>
        </template>
        <template slot="operation" slot-scope="text, record">
          <a-button v-if="hasPermission('accountDetail')" type="link" size="small" @click="jumpToEdit(record)">修改</a-button>
        </template>
      </a-table>
    </div>
  </div>
</template>

<script>
import { getAccounts } from '@/services/account'

export default {
  name: "index",
  data() {
    this.tableColumns = [
      { title: '用户名称', dataIndex: 'userName' },
      { title: '状态', dataIndex: 'accountStatus', scopedSlots: { customRender: 'accountStatus' }},
      { title: '绑定号码', dataIndex: 'phone' },
      { title: '账户类型', dataIndex: 'accountType', scopedSlots: { customRender: 'accountType' }},
      { title: '创建时间', dataIndex: 'createdDate' },
      { title: '操作', dataIndex: 'operation', scopedSlots: { customRender: 'operation' }, fixed: 'right', width: 90, align: 'center'},
    ];
    return {
      userName: '',
      tableData: [],
      loading: false
    }
  },
  mounted() {
    this.getAccounts()
  },
  methods: {
    handleTableChange(pagination) {
      this.myPagination = { ...this.myPagination, current: pagination.current, pageSize: pagination.pageSize }
      this.getAccounts()
    },
    getAccounts() {
      if (!this.hasPermission('accountList')) {
        return this.$message.error('该用户暂无查看用户列表权限')
      }
      const pagination = { page: this.myPagination.current, size: this.myPagination.pageSize }
      this.loading = true
      getAccounts({ userName: this.userName, pagination }).then((data) => {
        const { errorCode, errorMsg, result, pagination }  = data
        if (errorCode === '0') {
          if (result) {
            this.tableData = result.smsAccountOutVos
          }
          this.myPagination.total = pagination.total
        } else {
          this.$message.error(errorMsg)
        }
        this.loading = false
      }).catch(() => {
        this.loading = false
      })
    },
    handleSearch(e) {
      e.preventDefault();
      this.myPagination.current = 1
      this.getAccounts();
    },
    jumpToEdit(row) {
      this.$router.push({ name: '用户详情', params: row})

    },
    jumpToCreate() {
      this.$router.push('/account/create')
    }
  }
}
</script>

<style lang="less" scoped>
.account-container{
  background: #ffffff;
  .header{
    padding: 10px 20px;
  }
}
</style>
