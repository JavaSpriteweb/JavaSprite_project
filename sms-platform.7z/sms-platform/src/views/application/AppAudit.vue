<template>
  <a-card>
    <a-form class="app-form" layout="inline">
      <a-row>
        <a-col :span="12" v-for="item in appForm" :key="item.prop">
          <a-form-item :label="item.label">
            <span v-if="item.filter">{{item.filter(appData[item.prop])}}</span>
            <span v-else>{{appData[item.prop]}}</span>
          </a-form-item>
        </a-col>
      </a-row>
    </a-form>
    <a-form
      :form="form"
      :label-col="{ span: 5 }"
      :wrapper-col="{ span: 19 }"
      class="audit-form"
    >
      <a-form-item label="通道号：">
        <a-input v-decorator="['wayId', { rules: [
         { pattern: /^\d{1,6}$/, message: '只支持1-6位数字' },
         { required: true, message: '通道号不能为空' },
         { validator: validateWayId }], trigger: 'blur'}]">
        </a-input>
      </a-form-item>
      <a-form-item label="审核建议（审核说明）：">
        <a-textarea
          v-decorator="['auditInstructions', { rules: [
          { max: 1000, message: '最大输入1000个字符' },
          ]}]"
          placeholder="请输入审核说明"></a-textarea>
      </a-form-item>
      <a-form-item :wrapper-col="{ span: 24 }" style="text-align: center" v-if="hasPermission('appAudit')">
        <a-button @click="back" style="margin-right: 20px">返回</a-button>
        <a-button :loading="loading" type="primary" style="margin-right: 20px"  @click="handleAudit(0)">通过</a-button>
        <a-button :loading="loading" type="danger" @click="handleAudit(3)">不通过</a-button>
      </a-form-item>
    </a-form>
  </a-card>
</template>

<script>
import ARow from "ant-design-vue/es/grid/Row"
import { aduitApp, isExistWayId } from '@/services/application'
import AFormItem from "ant-design-vue/es/form/FormItem"
import ATextarea from "ant-design-vue/es/input/TextArea"
import {  APP_STATUS } from '@/config/default/sms.config'

export default {
  name: "AppAudit",
  components: {ATextarea, AFormItem, ARow},
  data() {
    this.appForm = [
      { label: '应用名称', prop: 'appName' },
      { label: 'APP_Key', prop: 'appKey' },
      { label: '上行短信接收地址', prop: 'smsUplinkAddr' },
      { label: '状态', prop: 'appStatus', filter: this.parseStatus },
    ];
    return{
      form: this.$form.createForm(this),
      appData: {},
      loading: false
    }
  },
  mounted() {
    this.appData = this.$route.params
  },
  methods: {
    handleAudit(type) {
      // type: 0通过，3不通过
      this.$bus.$emit('bigLoading', true)
      const validItems = type === 0 ? null : ['auditInstructions']
      this.form.validateFields(validItems, (err, values) => {
        if (!err) {
          const { appId, isDomestic } = this.appData
          aduitApp({ appId, isDomestic, aduitStatus: type, wayId: values.wayId, auditInstructions: values.auditInstructions }).then((data) => {
            const { errorCode, errorMsg }  = data
            if (errorCode === '0') {
              this.$message.success(errorMsg)
              this.$router.push('/application/list')
            } else {
              this.$message.error(errorMsg)
            }
            this.$bus.$emit('bigLoading', false)
          }).catch(() => {
            this.$bus.$emit('bigLoading', false)
          })
        } else {
          this.$bus.$emit('bigLoading', false)
        }
      })

    },
    validateWayId(rule, value, callback) {
      if (value) {
        isExistWayId({ wayId: value }).then((res) => {
          if (res.errorCode !== '0') {
            callback(res.errorMsg)
          } else {
            callback()
          }
        })
      } else {
        callback()
      }
    },
    parseStatus(value) {
      const map = new Map(APP_STATUS)
      return map.get(value)
    },
    back() {
      this.$router.go(-1)
    }
  }
}
</script>

<style lang="less" scoped>
.app-form{
  border: 1px solid @border-color;
  border-radius: 4px;
  padding: 0 20px;
  height: 100%;
}
.audit-form{
  margin-top: 20px;
}
.content-box{
  margin-top: 20px;
  display: flex;
  label{
    display: inline-block;
    flex: 0.2;
  }
  .ant-input{
    flex: 0.8;
  }
}
.btn-box{
  display: flex;
  width: 60%;
  margin: 30px auto 0;
  justify-content: space-around;
}
</style>
