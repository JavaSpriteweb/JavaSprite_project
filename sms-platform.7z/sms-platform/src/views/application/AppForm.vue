<template>
  <div class="application-container">
    <a-form
      :form="form"
      :label-col="{ span: 5 }"
      :wrapper-col="{ span: 12 }"
      @submit="handleSubmit"
    >
      <a-form-item label="应用名称">
        <a-input v-decorator="['appName',{ rules: [
        { required: true, message: '应用名称不能为空' },
        { max: 30, message: '最大输入30个字符' },
        { pattern: /^[a-zA-Z0-9_]*$/, message: '只能包含英文字母、数字、下划线' },
        { validator: validAppName}],
        trigger: 'blur'}]"
         placeholder="请输入应用名称"
        ></a-input>
        <template slot="extra">
          <a-alert message="只能包含英文字母、数字、下划线，应用添加后不能删除" type="info" show-icon />
        </template>
      </a-form-item>
      <a-form-item v-if="!isEdit" label="是否国内">
        <a-radio-group name="radioGroup" v-decorator="['isDomestic']" @change="changeCountry">
          <a-radio :value="1">是</a-radio>
          <a-radio :value="0">否</a-radio>
        </a-radio-group>
      </a-form-item>
      <a-form-item v-if="showStatus" label="状态">
        <a-radio-group name="radioGroup" v-decorator="['appStatus']">
          <a-radio :value="1">暂停</a-radio>
          <a-radio :value="0">正常</a-radio>
        </a-radio-group>
      </a-form-item>
      <a-form-item label="上行短信接收地址" v-if="formData.isDomestic === 1">
        <a-input v-decorator="['smsUplinkAddr',{ rules: [
        { max: 500, message: '应用不能超过500个字' },
        { pattern: /(http|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/,
        message: '请输入有效地址'}]}]"
         placeholder="例如：http://hw1.com/xxx"
        ></a-input>
        <template slot="extra">
          <span>如果业务方需要接收用户回复的短信，并进行相应的业务处理，
            则需要配置能正常接收HTTP请求的公网URL（可以是域名或者IPPORT，推荐使用域名）。否则，可以不配置上行短信接收地址</span>
        </template>
      </a-form-item>
      <a-form-item v-if="!isEdit && formData.isDomestic === 1" label="测试签名和模板">
        <a-radio-group name="radioGroup" v-decorator="['isTest']">
          <a-radio :value="0">不需要</a-radio>
          <a-radio :value="1">需要</a-radio>
        </a-radio-group>
      </a-form-item>
      <a-form-item :wrapper-col="{ span: 24 }" style="text-align: center">
        <a-button @click="goBack" style="margin-right: 20px">返回</a-button>
        <a-button :loading="loading" type="primary"  html-type="submit">确定</a-button>
      </a-form-item>
    </a-form>
  </div>
</template>

<script>
import { addApp, updateApp, isExist } from '@/services/application'
import {mapState} from 'vuex'

export default {
  name: "AppForm",
  data() {
    return {
      form: this.$form.createForm(this),
      loading: false,
      formData: {
        isDomestic: 1
      },
      nameInput: null
    }
  },
  computed: {
    ...mapState('account', ['user']),
    isEdit() {
      return this.$route.params.appId;
    },
    showStatus() {
      const { isDomestic, appStatus } = this.formData
      return this.isEdit && (isDomestic || appStatus === 0 || appStatus === 1)
    },
    addOrUpdate() {
      return this.isEdit ? 'appDetail' : 'createApp'
    }
  },
  mounted() {
    this.$nextTick(() => {
      if (!this.isEdit) {
        this.form.setFieldsValue({ isTest: 0 })
        this.form.setFieldsValue({ isDomestic: 1 })
      } else {
        this.formData = this.$route.params
        this.getAppDetail();
      }
    })
  },
  beforeDestroy() {
    this.form.resetFields();
  },
  methods: {
    getAppDetail() {
      this.form.setFieldsValue(this.$_.pick(this.formData, 'appName', 'smsUplinkAddr', 'isTest', 'appStatus'));
    },
    handleSubmit(e) {
      this.loading = true
      e.preventDefault();
      this.form.validateFields((err, values) => {
        if (!err) {
          if (this.isEdit) {
            this.updateApp(values);
          } else {
            this.addApp(values);
          }
        } else {
          this.loading = false
        }
      });
    },
    addApp(values) {
      addApp({ ...values, accountId: this.user.accountId, accountType: this.user.accountType }).then((data) => {
        const { errorCode, errorMsg }  = data
        this.loading = false
        if (errorCode === '0') {
          this.$message.success('添加应用成功')
          this.$router.push('/application/list')
        } else {
          this.$message.error(errorMsg)
        }
      }).catch(() => {
        this.loading = false
      })
    },
    updateApp(values) {
      updateApp({ ...values, appId: this.formData.appId, accountId: this.user.accountId, accountType: this.user.accountType, updateType: 0 }).then((data) => {
        const { errorCode, errorMsg }  = data
        this.loading = false
        if (errorCode === '0') {
          this.$message.success('更新应用成功')
          this.$router.push('/application/list')
        } else {
          this.$message.error(errorMsg)
        }
      }).catch((error) => {
        console.log(error)
        this.loading = false
      })
    },
    changeCountry(event) {
      this.formData.isDomestic = event.target.value
    },
    validAppName(rule, value, callback) {
      if (value && value !== this.formData.appName) {
        isExist({ accountId: this.user.accountId, appName: value, queryType: 2}).then((res) => {
          if (res.errorCode !== '0') {
            callback('存在重名应用名')
          } else {
            callback()
          }
        })
      } else {
        callback()
      }
    },
    goBack() {
      this.$router.go(-1)
    }
  }
}
</script>

<style lang="less" scoped>
.application-container{
  background: #ffffff;
  padding: 20px;
}
</style>
