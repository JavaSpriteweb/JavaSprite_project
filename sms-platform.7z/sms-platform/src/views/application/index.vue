<template>
  <div class="app-container">
    <div class="header">
      <a-form layout="inline" @submit="handleSearch">
        <a-form-item label="应用名称">
         <a-input placeholder="请输入名称" v-model="appValue" allowClear></a-input>
        </a-form-item>
        <a-form-item>
          <a-button type="primary" v-if="hasPermission('appList')" html-type="submit">查询</a-button>
          <a-button type="primary" v-if="hasPermission('createApp')" @click="jumpToCreate" style="margin-left: 10px">新建应用</a-button>
        </a-form-item>
      </a-form>
    </div>
    <div class="app-table">
      <a-table
        :columns="tableColumns"
        :data-source="tableData"
        rowKey="appId"
        :scroll="{x: 1600}"
        :loading="loading"
        :pagination="tablePagination"
      >
        <template slot="appSecret" slot-scope="text, record">
          <a-button v-if="!text" type="link" size="small" @click="openSecret(record, 'show')">显示</a-button>
          <span v-else>{{text}}</span>
          <a-button v-if="hasPermission('updateAppSecret')" type="link" size="small" @click="openSecret(record, 'update')">更新</a-button>
        </template>
        <template slot="appStatus" slot-scope="text">
          <span v-if="text === 0">
            <a-icon type="check-circle" theme="twoTone" two-tone-color="#52c41a"/>正常
          </span>
          <span v-else-if="text ===1">
            <a-icon type="pause-circle" theme="twoTone" two-tone-color="#ff4d4f"/>暂停
          </span>
          <span v-else>{{text | filterStatus}}</span>
        </template>
        <template slot="isDomestic" slot-scope="text">
          {{text === 1 ? '国内' : '国际'}}
        </template>
        <template slot="operation" slot-scope="text, record">
          <a-button type="link" size="small" v-if="hasPermission('appDetail')" @click="jumpToEdit(record)">修改</a-button>
            <!--          国际应用且状态为未审核时才能审核-->
          <a-button v-if="hasPermission('appAudit')" type="link" size="small" :disabled="!(record.appStatus===2 && record.isDomestic===0)" @click="jumpToAudit(record)">审核</a-button>
        </template>
      </a-table>
    </div>
    <a-modal
      title="身份验证"
      :visible="visible"
      dialogClass="identity-modal"
      @cancel="handleCancel"
      :maskClosable="false">
      <a-alert message="为保障您的账号及资产安全，完成敏感操作需要身份验证。" type="info" show-icon />
      <div class="phone-info">
        <label>绑定手机</label><span>{{user.phone}}</span><br/>
        <label>验证码</label>
        <a-input v-model="vsCode"></a-input>
<!--        验证码按钮组件 -->
        <SmsCode ref="smsCode" :phone="user.phone" :vsCode.sync="vsCode"></SmsCode>
      </div>
      <template slot="footer">
        <a-button key="back" @click="handleCancel">取消</a-button>
        <a-button key="submit" type="primary" :loading="submitLoading" @click="handleOk">确认</a-button>
      </template>
    </a-modal>
  </div>
</template>

<script>
import { getApplications, getSecret, updateSecret } from '@/services/application'
import {  APP_STATUS } from '@/config/default/sms.config'
import {mapState} from 'vuex'
import SmsCode from '@/components/smsCode'

const AUDIT_STATUS = [
  [0, '初始'],
  [1, '审核通过'],
  [2, '审核不通过']
]

export default {
  name: "index",
  components: { SmsCode },
  data() {
    this.tableColumns = [
      { title: '应用名称', dataIndex: 'appName' },
      { title: 'APP_Key', dataIndex: 'appKey' },
      { title: 'APP_Secret', dataIndex: 'appSecret', scopedSlots: { customRender: 'appSecret' }, width: 200},
      { title: 'APP接入地址', dataIndex: 'appAdress'},
      { title: '上行短信接收地址', dataIndex: 'smsUplinkAddr', width: 180, ellipsis: true },
      { title: '通道号', dataIndex: 'wayId' },
      { title: '国内/国际', dataIndex: 'isDomestic', scopedSlots: { customRender: 'isDomestic' } },
      { title: '状态', dataIndex: 'appStatus', scopedSlots: { customRender: 'appStatus' }},
      { title: '创建时间', dataIndex: 'createdDate', scopedSlots: { customRender: 'createdDate' }, width: 160},
      { title: '审核说明', dataIndex: 'auditInstructions', width: 200, ellipsis: true},
      { title: '操作', dataIndex: 'operation', scopedSlots: { customRender: 'operation' }, fixed: 'right', width: 90, align: 'center'},
    ];
    return {
      appValue: '',
      vsCode: '',
      visible: false,
      appOptions: [],
      signOptions: [],
      tableData: [],
      loading: false,
      isChecked: false,
      activeApp: null,
      activeType: 'show',
      submitLoading: false,
      timestamp: '',
      passApp: null
    }
  },
  computed: {
    ...mapState('account', ['user'])
  },
  mounted() {
    setTimeout(() => {
      this.getAppList()
    }, 600);
  },
  methods: {
    getAppList() {
      if (!this.hasPermission('appList')) {
        return this.$message.error('该用户暂无查看应用列表的权限')
      }
      const { current, pageSize } = this.myPagination
      const params = { accountId: this.user.accountId, appName: this.appValue, queryType: 1 }
      this.loading = true
      getApplications({ ...params, pagination: { page: current, size: pageSize }}).then((res) => {
        const { errorCode, errorMsg, result, pagination }  = res
        if (errorCode === '0') {
          if (result) {
            this.tableData = result.smsAppsPos
          } else {
            this.tableData = []
          }
          this.myPagination.total = pagination?.total || 0
        } else {
          this.$message.error(errorMsg)
        }
        this.loading = false
      }).catch((error) => {
        console.log(error)
        this.loading = false
      })
    },
    handleSearch(e) {
      e.preventDefault();
      this.myPagination.current = 1
      this.getAppList();
    },
    handleAppChange(val) {
      this.formData.appId = val
    },
    handleSignChange(val) {
      this.formData.signId = val
    },
    openSecret(row, type) {
      // 已验证过身份信息的app更新时无需校验
      if (row.appId === this.passApp?.appId && this.isChecked && type === 'update') {
        this.updateSecret(row)
        return false
      }
      this.activeApp = row
      this.activeType = type
      this.visible = true
      if ( !this.passApp || row.appId !== this.passApp.appId) {
        this.$nextTick(() => {
          this.$refs.smsCode.clearTime()
        })
      }
    },
    handleOk(){
      // 校验验证码
      if (!this.vsCode) {
        return this.$message.error('请输入验证码')
      }
      this.submitLoading = true
      this.$refs.smsCode.checkPwdCode(this.vsCode).then((data) => {
        this.submitLoading = false
        if (data) {
          this.passApp = this.$_.cloneDeep(this.activeApp)
          this.$refs.smsCode.clearTime()
          this.visible = false
          this.isChecked = true
          this.vsCode = ''
          if (this.activeType === 'show') {
            this.getAppSecret();
          } else {
            this.updateSecret()
          }
        }
      }).catch(() => {
        this.submitLoading = false
      })
    },
    getAppSecret() {
      this.loading = true
      getSecret({ appId: this.passApp.appId, queryType: 0 }).then((data) => {
        const { errorCode, errorMsg, result }  = data
        if (errorCode === '0') {
          if (result) {
            this.tableData.find((ele) => ele.appId === this.passApp.appId).appSecret = result.appSecret
            this.tableData = this.$_.cloneDeep(this.tableData)
          }
        } else {
          this.$message.error(errorMsg)
        }
        this.loading = false
      }).catch(() => {
        this.loading = false
      })
    },
    updateSecret() {
      this.loading = true
      updateSecret({ appId: this.passApp.appId, updateType: 1 }).then((data) => {
        const { errorCode, errorMsg, result }  = data
        if (errorCode === '0') {
          if (result) {
            this.tableData.find((ele) => ele.appId === this.passApp.appId).appSecret = result.appSecret
            this.tableData = this.$_.cloneDeep(this.tableData)
            this.$message.success('更新成功')
          }
        } else {
          this.$message.error(errorMsg)
        }
        this.loading = false
      }).catch(() => {
        this.loading = false
      })
    },
    handleTableChange(pagination) {
      const { current, pageSize } = pagination
      this.myPagination = { ...this.myPagination, current, pageSize };
      this.getAppList();
    },
    jumpToCreate() {
      this.$router.push('/application/create')
    },
    jumpToEdit(row) {
      this.$router.push({ name: '应用详情', params: row })
    },
    jumpToAudit(row) {
      // 国际应用需审核，初始状态可审核
      this.$router.push({ name: '应用审核', params: row })
    },
    handleCancel(){
      this.visible = false;
      this.vsCode = '';
    }
  },
  filters: {
    filterAudit(value) {
      const map = new Map(AUDIT_STATUS)
      return map.get(value)
    },
    filterStatus(value) {
      const map = new Map(APP_STATUS)
      return map.get(value)
    }
  }
}
</script>

<style lang="less" scoped>
.app-container{
  background: #ffffff;
  width: 100%;
  height: 100%;
  .header{
    padding: 10px 20px;
    /deep/ .ant-select-selection{
      width: 160px;
    }
  }
  .app-table{
    span{
      i{
        margin-right: 5px;
      }
    }
  }
}
.identity-modal{
  .phone-info{
    padding-top: 20px;
    label{
      display: inline-block;
      width: 80px;
      text-align: right;
      margin-right: 20px;
      margin-bottom: 10px;
    }
    /deep/ .ant-input{
      width: 50%;
      margin-right: 10px;
    }
  }
}
</style>
