<template>
  <a-modal
    title="忘记密码"
    :visible="visible"
    :maskClosable="false"
    destroyOnClose
    @cancel="cancel"
  >
    <div class="forget-box">
      <template>
        <a-form
          :form="form"
          :label-col="{ span: 5 }"
          :wrapper-col="{ span: 19 }"
        >
          <a-form-item v-if="step===1" label="用户名">
            <a-input v-decorator="['userName', {rules: [{ required: true, message: '请输入用户名'}]}]"></a-input>
          </a-form-item>
          <template v-if="step === 2">
            <a-form-item label="绑定手机">
              <a-input disabled v-decorator="['phone']"></a-input>
            </a-form-item>
            <a-form-item label="验证码">
              <a-input v-decorator="['vsCode', {rules: [{ required: true, message: '请输入验证码'}]}]"></a-input>
<!--              验证码按钮   -->
              <SmsCode ref="smsCode" :phone="userInfo.phone" :vsCode.sync="vsCode"></SmsCode>
            </a-form-item>
          </template>
          <template v-if="step === 3">
            <a-form-item label="密码:">
              <a-input v-decorator="['passWord', {rules: [
              { required: true, message: '请输入密码'},
              { pattern: /^[a-zA-Z0-9-*/+.~!@#$%^&*()]{8,12}$/, message: '密码支持数字、字母、特殊符号的8-12位字符' },
              ]}]"></a-input>
            </a-form-item>
            <a-form-item label="确认密码:">
              <a-input
                v-decorator="['newPassWord', {rules: [
                { required: true, message: '请输入密码'},
                { validator: validPassword }
                ]}]"
              >
              </a-input>
            </a-form-item>
          </template>
        </a-form>
      </template>
    </div>
    <template slot="footer">
      <a-button @click="preStep" v-if="step!==1">上一步</a-button>
      <a-button @click="nextStep" v-if="step!==3" :loading="nextLoading">下一步</a-button>
      <a-button v-if="step === 3" :loading="loading" type="primary" @click="nextStep">确定</a-button>
    </template>
  </a-modal>
</template>

<script>
import { updatePassword} from '@/services/user'
import { getAccountInfo } from '@/services/account'
import AFormItem from "ant-design-vue/es/form/FormItem"
import SmsCode from '@/components/smsCode'
import md5 from 'js-md5';

export default {
  name: "ForgetPwd",
  components: { AFormItem, SmsCode },
  props: {
    visible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      form: this.$form.createForm(this),
      step: 1,
      userInfo: {},
      vsCode: '',
      loading: false,
      nextLoading: false,
      newPassword: '',
      checkPassword: '',
      showCode: true,
      timestamp: ''
    }
  },
  methods: {
    handleSubmit() {
      if (this.showCode) {
        this.checkPwdCode()
      } else {
        this.submitPassword()
      }
    },
    // 校验验证码
    checkPwdCode(){
      this.nextLoading = true
      const smsCheckCode = this.form.getFieldValue('vsCode')
      this.$refs.smsCode.checkPwdCode(smsCheckCode).then((data) => {
        this.nextLoading = false
        if (data) {
          this.$refs.smsCode.clearTime()
          this.step++
        }
      }).catch(() => {
        this.nextLoading = false
      })
    },
    // 修改密码
    submitPassword(values) {
      this.loading = true
      updatePassword({ accountId: this.userInfo.accountId, passWord: md5(values.passWord) }).then((data) => {
        const { errorCode, errorMsg }  = data
        if (errorCode === '0') {
          this.$message.success('修改成功')
          this.cancel()
        } else {
          this.$message.error(errorMsg)
        }
        this.loading = false
      }).catch(() => {
        this.loading = false
      })
    },
    getAccountInfo() {
      const userName = this.form.getFieldValue('userName')
      this.nextLoading = true
      getAccountInfo({ userName }).then((data) => {
        this.nextLoading = false
        const { errorCode, errorMsg, result } = data
        if (errorCode === '0' && result) {
          this.userInfo = result
          this.step++
          this.$nextTick(() => {
            this.form.setFieldsValue({ phone: result.phone })
            this.$refs.smsCode.clearTime()
          })
        } else {
          this.$message.error(errorMsg)
        }
      }).catch(() => {
        this.nextLoading = false
      });
    },
    validPassword(rule, value, callback) {
      const userName = this.form.getFieldValue('passWord')
      if (value && value !== userName) {
        callback('密码不一致')
      } else {
        callback()
      }
    },
    preStep() {
      if(this.step !== 1) this.step --
    },
    nextStep() {
      this.form.validateFields((err, values) => {
        if (!err) {
          if (this.step === 1) {
            this.getAccountInfo()
          }else if (this.step === 2) {
            this.checkPwdCode()
          }else if (this.step === 3) {
            this.submitPassword(values)
          }
        }
      })
    },
    cancel() {
      this.step = 1
      this.$emit('update:visible', false)
    }
  }
}
</script>

<style lang="less" scoped>
.forget-box{
  label{
    display: inline-block;
    width: 80px;
    text-align: right;
    margin-right: 20px;
    margin-bottom: 10px;
  }
  /deep/ .ant-input{
    width: 50%;
    margin-right: 10px;
  }
}
</style>
