<template>
  <common-layout>
    <div class="top">
      <div class="header">
        <span class="title">{{systemName}}</span>
      </div>
    </div>
    <div v-if="!isAutologin" class="login">
      <a-form @submit="onSubmit" :form="form">
        <a-alert type="error" :closable="true" v-show="error" :message="error" showIcon style="margin-bottom: 24px;" />
        <a-form-item>
          <a-input
            autocomplete="autocomplete"
            size="large"
            placeholder="账户名称"
            v-decorator="['userName', {rules: [{ required: true, message: '请输入账户名', whitespace: true}]}]"
          >
            <a-icon slot="prefix" type="user" />
          </a-input>
        </a-form-item>
        <a-form-item>
          <a-input
            size="large"
            placeholder="密码"
            autocomplete="autocomplete"
            type="password"
            v-decorator="['passWord', {rules: [{ required: true, message: '请输入密码', whitespace: true}]}]"
          >
            <a-icon slot="prefix" type="lock" />
          </a-input>
        </a-form-item>
        <div style="height: 24px; margin-top: -10px">
          <a style="float: right;" @click="forgetPwd">忘记密码</a>
        </div>
        <a-form-item>
          <a-button :loading="logging" style="width: 100%;margin-top: 24px" size="large" htmlType="submit" type="primary">登录</a-button>
        </a-form-item>
      </a-form>
      <ForgetPwd :visible.sync="visible" />
    </div>
    <div v-else style="text-align: center;margin-top: 80px;">
      <a-spin size="large" />
    </div>
  </common-layout>
</template>

<script>
import CommonLayout from '@/layouts/CommonLayout'
import { login, getMenu, validate, gettoken, getSignature } from '@/services/user'
import {setAuthorization} from '@/utils/request'
import {loadRoutes} from '@/utils/routerUtil'
import AFormItem from "ant-design-vue/es/form/FormItem"
import ForgetPwd from './ForgetPwd'
import convert from 'xml-js'
import md5 from 'js-md5';

export default {
  name: 'Login',
  components: {AFormItem, CommonLayout, ForgetPwd},
  data () {
    return {
      logging: false,
      error: '',
      form: this.$form.createForm(this),
      visible: false,
      vsCode: '',
      isAutologin: true
    }
  },
  computed: {
    systemName () {
      return this.$store.state.setting.systemName
    },
    accountId() {
      return this.$store.state.account.user.accountId
    },
    callbackUrl() {
      const { origin, pathname } = document.location
      return `${origin}${pathname}`
    }
  },
  methods: {
    onSubmit (e) {
      e.preventDefault()
      this.form.validateFields((err) => {
        if (!err) {
          this.logging = true
          const userName = this.form.getFieldValue('userName')
          const passWord = this.form.getFieldValue('passWord')
          login({ userName, passWord: md5(passWord) }).then((data) => {
            const { errorCode, result, errorMsg } = data
            if (errorCode === '0' && result?.token) {
              // 保存token添加到请求头
              setAuthorization({token: result.token})
              this.handleLoginProcess(userName)
              // this.getAccount(userName)
            } else {
              this.$message.error(errorMsg)
              this.logging = false
            }
          }).catch(() => {
            this.logging = false
          })
        }
      })
    },
    // 获取用户信息
    getAccount(userName) {
      this.$store.dispatch('account/getAccount', userName).then((data) => {
        const { errorCode, result, errorMsg } = data
        if (errorCode === '0') {
          this.getMenu(result.accountId)
        } else {
          this.$message.error(errorMsg)
          this.logging = false
        }
      }).catch(() => {
        this.logging = false
      })
    },
    // 获取路由配置
    getMenu(accountId) {
      getMenu({ accountId }).then((data) => {
        const { errorCode, errorMsg, result } = data
        if (errorCode === '0') {
          const routesConfig = result?.menuTree[0]
          if (routesConfig) {
            loadRoutes([routesConfig])
            this.getFunctionRoot(accountId)
          } else {
            this.$message.error('该用户暂无菜单权限')
          }
        } else {
          this.$message.error(errorMsg)
        }
        this.logging = false
      }).catch(() => {
        this.logging = false
      })
    },
    // 获取功能权限
    getFunctionRoot(accountId) {
      this.logging = true
      this.$store.dispatch('account/getPermissions', accountId).then((data) => {
        const { errorCode, result, errorMsg } = data
        if (errorCode === '0' && (!result || !result.functions)) {
          this.$message.error('该用户暂无功能权限')
        } else if (errorCode !== '0' ){
          this.$message.error(errorMsg)
        }
        this.$router.push('/')
        this.logging = false
      }).catch(() => {
        this.logging = false
      })
    },
    // 忘记密码
    forgetPwd() {
      this.visible = true
    },
    async autologin() {
      const { query: { ticket } } = this.$route
      const { result: { signature, timestamp } } = await getSignature({ service: encodeURI(this.callbackUrl), ticket })
      const appId = '152999073894506102'
      const params = { service: encodeURI(this.callbackUrl), ticket, signature, timestamp, appId }
      // 验证票据
      try {
        const xmlData = await validate(params)
        const jsonData = JSON.parse(convert.xml2json(xmlData, { compact: true }))
        const serviceResponse = jsonData['cas:serviceResponse']
        const authenticationSuccess = serviceResponse['cas:authenticationSuccess']
        const attributes = authenticationSuccess['cas:attributes']
        const userId = attributes['userId']._text
        const accountId = attributes['domainId']._text
        const customerEmail = attributes['email']._text
        const mobilePhone = attributes['mobile']._text
        const accountType = 1
        const { errorCode, errorMsg, result = {} } = await gettoken({ userId, accountId, customerEmail, mobilePhone, accountType })
        if (+errorCode === 0 && result.token) {
          const { token, userName } = result
          // 保存token添加到请求头
          setAuthorization({ token })
          this.handleLoginProcess(userName)
          // this.getAccount(userName)
        } else {
          this.$router.push('/login')
          this.isAutologin = false
          this.$message.warning(errorMsg)
        }
      } catch (error) {
        console.log(error)
        this.$router.push('/login')
        this.isAutologin = false
        this.$message.warning('单点登录服务调用失败，请重新登录！')
      }
    },
    async handleLoginProcess(userName) {
      try {
        // 获取用户信息
        const userInfo = await this.$store.dispatch('account/getAccount', userName)
        if (userInfo?.errorCode !== '0') throw userInfo.errorMsg
        const { result: { accountId } } = userInfo
        // 获取菜单信息
        const menuInfo = await getMenu({ accountId })
        if (menuInfo?.errorCode !== '0') throw menuInfo.errorMsg
        const { result } = menuInfo
        const routesConfig = result?.menuTree[0]
        if (!routesConfig) throw '该用户暂无菜单权限'
        // 加载路由配置
        loadRoutes([routesConfig])
        // 获取用户权限
        const permissionInfo = await this.$store.dispatch('account/getPermissions', accountId)
        if (permissionInfo?.errorCode !== '0') {
          throw permissionInfo.errorMsg
        } else {
          const { result } = permissionInfo
          if (!result?.functions) {
            this.$message.error('该用户暂无功能权限')
          }
        }
        // 重定向到首页
        this.logging = false
        this.$router.push('/')
      } catch (error) {
        this.logging = false
        this.$message.error(error)
      }
    }
  },
  async created() {
    const { path, query: { ticket = '' } } = this.$route
    if (path === '/autologin') {
      if (ticket.trim()) {
        this.autologin()
      } else {
        // 重定向到单点登录地址
        const redirectPath = `https://www.ctyun.cn/cas/login?service=${encodeURI(this.callbackUrl)}`
        document.location.href = redirectPath
      }
    } else {
      this.isAutologin = false
    }
  }
}
</script>

<style lang="less" scoped>
  .common-layout{
    .top {
      text-align: center;
      .header {
        height: 44px;
        line-height: 44px;
        a {
          text-decoration: none;
        }
        .logo {
          /*height: 44px;*/
          font-size: 80px;
          color: #1f1f1f;
          vertical-align: top;
          margin-right: 16px;
        }
        .title {
          font-size: 33px;
          color: @title-color;
          font-family: 'Myriad Pro', 'Helvetica Neue', Arial, Helvetica, sans-serif;
          font-weight: 600;
          position: relative;
          top: 2px;
        }
      }
      .desc {
        font-size: 14px;
        color: @text-color-second;
        margin-top: 12px;
        margin-bottom: 40px;
      }
    }
    .login{
      width: 368px;
      margin: 20px auto 0;
      @media screen and (max-width: 576px) {
        width: 95%;
      }
      @media screen and (max-width: 320px) {
        .captcha-button{
          font-size: 14px;
        }
      }
      .icon {
        font-size: 24px;
        color: @text-color-second;
        margin-left: 16px;
        vertical-align: middle;
        cursor: pointer;
        transition: color 0.3s;

        &:hover {
          color: @primary-color;
        }
      }
    }
  }
</style>
