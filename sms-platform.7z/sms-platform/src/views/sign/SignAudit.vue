<template>
  <a-card>
    <a-row type="flex" :gutter="16">
      <a-col flex="0.4">
        <a-form class="sign-form" layout="inline">
          <a-row v-for="item in signForm" :key="item.prop">
            <a-form-item  :label="item.label">
              <span v-if="item.filter">{{item.filter(signData[item.prop])}}</span>
              <span class="sign-content" v-else>{{signData[item.prop]}}</span>
            </a-form-item>
          </a-row>
        </a-form>
      </a-col>
      <a-col flex="0.7">
        <div class="sign-form" style="padding: 10px 20px">
          <p>是否涉及第三方权益：{{signData.thirdInterest === 1 ? '是' : '否'}}</p>
          <div class="sign-picture">
            <a-spin :spinning="spinning">
              <div v-if="signData.thirdInterest === 1" style="margin-bottom: 20px">
                <p>（授权委托书）</p>
                <img :src="thirdAuthorize">
              </div>
              <div>
                <p>（营业执照）</p>
                <img :src="businessLicense">
              </div>
            </a-spin>
          </div>
        </div>
      </a-col>
    </a-row>
    <div class="content-box">
      <label>审核建议（审核说明）：</label>
      <a-textarea v-model="auditInstructions" :maxLength="1000"></a-textarea>
    </div>
    <div class="btn-box">
      <a-button type="primary" @click="checkSign(2)" :disabled="disabled">通过</a-button>
      <a-button type="danger" @click="checkSign(3)" :disabled="disabled">不通过</a-button>
      <a-button @click="back">返回</a-button>
    </div>
  </a-card>
</template>

<script>
import AFormItem from "ant-design-vue/es/form/FormItem"
import ARow from "ant-design-vue/es/grid/Row"
import ATextarea from "ant-design-vue/es/input/TextArea"
import { getSignDetail, checkSign, getPicture } from '@/services/sign'
import { TEMPLATE_TYPE, SIGN_SOURCE } from '@/config/default/sms.config'

export default {
  name: "SignAudit",
  components: {ATextarea, ARow, AFormItem},
  data() {
    this.signForm = [
      { label: '签名名称', prop: 'signName' },
      { label: '签名类型', prop: 'signType', filter: this.parseType },
      { label: '所属应用', prop: 'appName' },
      { label: '签名来源', prop: 'signSource', filter: this.parseSource },
      { label: '申请说明', prop: 'applyInstructions' },
    ];
    return {
      signData: {},
      signId: null,
      auditInstructions: '',
      thirdAuthorize: '',
      businessLicense: '',
      spinning: false
    }
  },
  computed: {
    disabled() {
      return this.signData.signStatus!==0
    },
    accountId() {
      return this.$store.state.account.user.accountId
    }
  },
  mounted() {
    this.signId = this.$route.query.id
    this.getSignDetail()
    this.getPicture()
  },
  methods: {
    getSignDetail() {
      this.$bus.$emit('bigLoading', true)
      getSignDetail({ signId: this.signId }).then((data) => {
        const { errorCode, errorMsg, result } = data
        if (errorCode === '0' && result) {
          this.signData = result
        } else {
          this.$message.error(errorMsg)
        }
        this.$bus.$emit('bigLoading', false)
      }).catch(() => {
        this.$bus.$emit('bigLoading', false)
      })
    },
    getPicture() {
      this.spinning = true
      getPicture({ signId: this.signId }).then((data) => {
        const { errorCode, result } = data
        if (errorCode === '0') {
          this.businessLicense = `data:image/png;base64,${result.businessLicenseBase64}`
          this.thirdAuthorize = `data:image/png;base64,${result.thirdAuthorizeBase64}`
        } else {
          this.businessLicense = null
          this.thirdAuthorize = null
        }
        this.spinning = false
      }).catch(() => {
        this.spinning = false
      })
    },
    checkSign(ifPass) {
      this.$bus.$emit('bigLoading', true)
      const { signId, signStatus } = this.signData
      checkSign({ accountId: this.accountId, signId, signStatus, ifPass, auditInstructions: this.auditInstructions}).then((data) => {
        const { errorCode, errorMsg } = data
        if (errorCode === '0') {
          this.$message.success(errorMsg)
          this.$router.push('/sign/list')
        } else {
          this.$message.error(errorMsg)
        }
        this.$bus.$emit('bigLoading', false)
      }).catch(() => {
        this.$bus.$emit('bigLoading', false)
      })
    },
    parseType(value) {
      const map = new Map(TEMPLATE_TYPE)
      return map.get(value)
    },
    parseSource(value) {
      const map = new Map(SIGN_SOURCE)
      return map.get(value)
    },
    back() {
      this.$router.go(-1)
    }
  }
}
</script>

<style lang="less" scoped>
.sign-form{
  border: 1px solid @border-color;
  border-radius: 4px;
  padding: 0px 20px;
  height: 100%;
}
.content-box{
  margin-top: 20px;
  display: flex;
  label{
    display: inline-block;
    flex: 0.2;
  }
  .ant-input{
    flex: 0.8;
  }
}
.btn-box{
  display: flex;
  width: 60%;
  margin: 30px auto 0;
  justify-content: space-around;
}
.sign-picture{
  display: flex;
  img{
    width: 90%;
    margin-right: 5%;
    display: inline-block;
  }
}
.sign-content{
  word-break: break-all;
}
</style>
