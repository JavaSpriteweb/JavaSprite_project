<template>
  <div class="sign-container">
    <a-form
      :form="form"
      :label-col="{ span: 5 }"
      :wrapper-col="{ span: 12 }"
      @submit="handleSubmit"
    >
      <a-form-item label="签名名称">
        <a-input
          v-decorator="[
            'signName',
            {
              rules: [
                { max: 8, message: '单个签名长度为2-8个字符' },
                { min: 2, message: '单个签名长度为2-8个字符' },
                { required: true, message: '请输入名称' },
                {
                  pattern: /^([a-zA-Z\u4E00-\u9FA5].*$)|(^.*[a-zA-Z\u4E00-\u9FA5]$)/,
                  message: '只能包含中文、数字、字母，不能为纯数字',
                },
                { validator: validSignName },
              ],
              trigger: 'blur',
            },
          ]"
          placeholder="请输入签名名称"
          :disabled="disabled"
        ></a-input>
        <template slot="extra">
          <ul style="padding-left: 15px">
            <li>单个签名长度为2-8个字符，建议为下方"签名来源"的全称或简称；</li>
            <li>只能包含中文、数字、字母；</li>
            <li>
              短信发送时签名会自带【】，您无需在签名中添加。查看更多<a
                @click="docVisible = true"
                >签名规范</a
              >
            </li>
          </ul>
        </template>
      </a-form-item>
      <a-form-item label="签名类型">
        <a-select
          v-decorator="[
            'signType',
            { rules: [{ required: true, message: '请选择签名类型' }] },
          ]"
          :getPopupContainer="
            (triggerNode) => triggerNode.parentNode || document.body
          "
          placeholder="请选择签名类型"
          @change="handleSignChange"
          :disabled="disabled"
        >
          <a-select-option v-for="item in typeOptions" :key="item.value">
            {{ item.label }}
          </a-select-option>
        </a-select>
      </a-form-item>
      <a-form-item label="所属应用">
        <a-select
          v-decorator="[
            'appId',
            { rules: [{ required: true, message: '请选择应用' }] },
          ]"
          placeholder="请选择应用"
          :getPopupContainer="
            (triggerNode) => triggerNode.parentNode || document.body
          "
          show-search
          allowClear
          :filter-option="false"
          @search="handleAppSearch"
          @change="handleAppChange"
          :disabled="disabled"
        >
          <a-spin v-if="appFetching" slot="notFoundContent" size="small" />
          <a-select-option
            v-for="item in appOptions"
            :key="item.appId"
            :title="item.appName"
          >
            {{ item.appName }}
          </a-select-option>
        </a-select>
        <template slot="extra">
          <span class="ant-form-text"
            >还没有应用？<a @click="jumpToApp">马上去添加</a></span
          >
        </template>
      </a-form-item>
      <a-form-item label="签名来源">
        <a-radio-group
          v-decorator="[
            'signSource',
            { rules: [{ required: true, message: '请选择应用' }] },
          ]"
          :disabled="disabled"
          @change="handleSourceChange"
        >
          <a-radio
            v-for="item in signSourceOptions"
            :style="radioStyle"
            :key="item.value"
            :value="item.value"
          >
            {{ item.label }}
          </a-radio>
        </a-radio-group>
      </a-form-item>
      <a-form-item v-if="formData.signSource === 2" label="网站域名">
        <a-input
          v-decorator="[
            'website',
            {
              rules: [
                { required: true, message: '请输入网站域名' },
                { max: 500, message: '最多输入500个字符' },
                {
                  pattern: /(http|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/,
                  message: '请输入有效地址',
                },
              ],
            },
          ]"
          :disabled="disabled"
          placeholder="请输入网站域名"
        ></a-input>
      </a-form-item>
      <a-form-item v-if="formData.signSource === 3" label="APP应用下载地址">
        <a-input
          v-decorator="[
            'appDownload',
            {
              rules: [
                { required: true, message: '请输入下载地址' },
                { max: 500, message: '最多输入500个字符' },
                {
                  pattern: /(http|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/,
                  message: '请输入有效地址',
                },
              ],
            },
          ]"
          :disabled="disabled"
          placeholder="请输入下载地址"
        >
        </a-input>
      </a-form-item>
      <a-form-item
        v-if="formData.signSource === 4"
        label="公众号或小程序的全称"
      >
        <a-input
          v-decorator="[
            'officialName',
            {
              rules: [
                { required: true, message: '请输入公众号或小程序' },
                { max: 500, message: '最多输入500个字符' },
              ],
            },
          ]"
          :disabled="disabled"
          placeholder="请输入公众号或小程序的全称"
        ></a-input>
      </a-form-item>
      <a-form-item v-if="formData.signSource === 5" label="电商平台店铺地址">
        <a-input
          v-decorator="[
            'shopUrl',
            {
              rules: [
                { required: true, message: '请输入电商平台店铺地址' },
                { max: 500, message: '最多输入500个字符' },
                {
                  pattern: /(http|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/,
                  message: '请输入有效地址',
                },
              ],
            },
          ]"
          :disabled="disabled"
          placeholder="请输入电商平台店铺地址"
        ></a-input>
      </a-form-item>
      <a-form-item label="是否涉及第三方协议">
        <a-radio-group
          v-decorator="['thirdInterest']"
          @change="changeAuthorize"
          :disabled="disabled"
        >
          <a-radio :value="1">是</a-radio>
          <a-radio :value="0">否</a-radio>
        </a-radio-group>
      </a-form-item>
      <a-form-item label="授权委托书" v-if="formData.thirdInterest === 1">
        <a-upload
          :v-decorator="[
            'thirdAuthorize',
            {
              rules: [{ required: true, message: '请上传授权委托书' }],
            },
          ]"
          name="file"
          accept="image/png, image/jpeg, image/gif, image/jpg"
          :multiple="false"
          :showUploadList="{ showRemoveIcon: false }"
          :file-list="thirdAuthorizeList"
          @remove="
            () => {
              return false;
            }
          "
          :headers="headers"
          :before-upload="(file) => beforeUpload(file, 'thirdAuthorize')"
          @change="uploadFile('thirdAuthorize')"
        >
          <a-button :disabled="disabled">
            <a-icon type="upload" />点击上传扫描件</a-button
          >
        </a-upload>
        <a v-if="thirdAuthorizeData" @click="showVisible(false)">授权委托书</a>
        <template slot="extra">
          <p>授权委托书支持jpg、png、gif、jpeg格式的图片，每张图片不大于2MB</p>
        </template>
      </a-form-item>
      <a-form-item label="营业执照">
        <a-upload
          v-decorator="[
            'businessLicense',
            { rules: [{ required: true, message: '请上传营业执照' }] },
          ]"
          name="file"
          accept="image/png, image/jpeg, image/gif, image/jpg"
          :showUploadList="{ showRemoveIcon: false }"
          :multiple="false"
          :file-list="businessLicenseList"
          :headers="headers"
          :before-upload="(file) => beforeUpload(file, 'businessLicense')"
          @change="uploadFile('businessLicense')"
        >
          <a-button :disabled="disabled"
            ><a-icon type="upload" />点击上传扫描件</a-button
          >
        </a-upload>
        <a v-if="businessLicenseData" @click="showVisible(true)">营业执照</a>
        <template slot="extra">
          <ul style="padding-left: 15px">
            <li>
              营业执照支持jpg、png、gif、jpeg格式的图片，每张图片不大于2MB
            </li>
            <li>上传签名归属方的营业执照</li>
          </ul>
        </template>
      </a-form-item>
      <a-form-item label="申请说明">
        <a-textarea
          v-if="!disabled"
          placeholder="如果您对短信发送号码有特殊要求，请详细列出"
          v-decorator="[
            'applyInstructions',
            { rules: [{ message: '申请说明不能超过500个字', max: 500 }] },
          ]"
        >
        </a-textarea>
        <p class="temp-cont" v-else>
          {{ formData.applyInstructions }}
        </p>
        <template slot="extra">
          <p>
            预计2小时内完成审核<br />
            审核时间:工作日09:00-18:00(GMT+08:00)(法定节假日顺延)
          </p>
        </template>
      </a-form-item>
      <a-form-item :wrapper-col="{ span: 24 }" style="text-align: center">
        <a-button @click="goBack" style="margin-right: 20px">返回</a-button>
        <a-button
          v-if="!disabled"
          type="primary"
          html-type="submit"
          :loading="submitLoading"
          >确定</a-button
        >
      </a-form-item>
    </a-form>
    <a-modal
      :visible="visible"
      :footer="null"
      @cancel="visible = false"
      width="600px"
    >
      <div class="img-box">
        <a-spin :spinning="spinning">
          <img v-if="showBusiness" :src="businessUrl" />
          <img v-else :src="authorizeUrl" />
        </a-spin>
      </div>
    </a-modal>
    <a-modal
      title="签名规范"
      :visible="docVisible"
      class="sign-modal"
      width="700px"
      @cancel="docVisible = false"
      :footer="null"
    >
      <SignStandard></SignStandard>
    </a-modal>
  </div>
</template>

<script>
import {
  getSignDetail,
  isExist,
  addSign,
  uploadFile,
  updateSign,
  getPicture,
} from "@/services/sign";
import { getAppOptions } from "@/services/application";
import { mapState } from "vuex";
import { SIGN_SOURCE_OPTIONS, TYPE_OPTIONS } from "@/config/default/sms.config";
import SignStandard from "../standard/SignStandard";
import debounce from "lodash/debounce";

const SOURCE_TYPE = [
  [2, "website"],
  [3, "appDownload"],
  [4, "officialName"],
  [5, "shopUrl"],
];

export default {
  name: "SignForm",
  components: { SignStandard },
  data() {
    this.lastFetchId = 0;
    this.handleAppSearch = debounce(this.handleAppSearch, 800);
    this.typeOptions = TYPE_OPTIONS;
    this.signSourceOptions = SIGN_SOURCE_OPTIONS;
    this.radioStyle = {
      display: "block",
      height: "30px",
      lineHeight: "30px",
    };
    return {
      form: this.$form.createForm(this),
      signId: null,
      appOptions: [],
      formData: {
        signSource: 1,
        signType: 1,
      },
      headers: {
        authorization: "authorization-text",
      },
      appValue: "",
      appFetching: false,
      thirdAuthorize: "", // 授权委托书
      businessLicense: "", // 营业执照
      businessLicenseData: "",
      thirdAuthorizeData: "",
      submitLoading: false,
      loading: false,
      isLt2M: true,
      isImage: true,
      thirdAuthorizeList: [],
      businessLicenseList: [],
      visible: false,
      businessUrl: "",
      authorizeUrl: "",
      showBusiness: true,
      spinning: false,
      docVisible: false,
    };
  },
  computed: {
    ...mapState("account", ["user"]),
    isCreate() {
      return !this.$route.query.id;
    },
    disabled() {
      return this.$route.query.type === "detail";
    },
  },
  mounted() {
    if (this.isCreate) {
      this.form.setFieldsValue({
        signType: 1,
        thirdInterest: 0,
        signSource: 1,
      });
    } else {
      this.signId = this.$route.query.id;
      this.getSignDetail();
      this.getPicture();
    }
    this.handleAppSearch();
  },
  methods: {
    getSignDetail() {
      this.$bus.$emit("bigLoading", true);
      getSignDetail({ signId: this.signId })
        .then((data) => {
          const { errorCode, errorMsg, result } = data;
          if (errorCode === "0" && result) {
            this.initData(result);
          } else {
            this.$message.error(errorMsg);
          }
          this.$bus.$emit("bigLoading", false);
        })
        .catch(() => {
          this.$bus.$emit("bigLoading", false);
        });
    },
    getPicture() {
      this.spinning = true;
      getPicture({ signId: this.signId })
        .then((data) => {
          const { errorCode, result } = data;
          if (errorCode === "0") {
            this.businessUrl = `data:image/png;base64,${result.businessLicenseBase64}`;
            this.authorizeUrl = `data:image/png;base64,${result.thirdAuthorizeBase64}`;
          } else {
            this.businessUrl = "";
            this.authorizeUrl = "";
          }
          this.spinning = false;
        })
        .catch(() => {
          this.spinning = false;
        });
    },
    initData(data) {
      this.formData = data;
      this.thirdAuthorizeData = data.thirdAuthorize;
      this.businessLicenseData = data.businessLicense;
      const { signSource, thirdInterest } = data;
      let sourceType = "website";
      if (!signSource) {
        this.form.setFieldsValue({ signSource: 1 });
        this.formData.signSource = 1;
      } else {
        // 根据signSource获取不同formItem
        const map = new Map(SOURCE_TYPE);
        sourceType = map.get(signSource);
      }
      if (thirdInterest === 0) {
        this.form.setFieldsValue({ thirdInterest: 0 });
        this.formData.thirdInterest = 0;
      }

      this.$nextTick(() => {
        this.form.setFieldsValue(
          this.$_.pick(
            data,
            "signName",
            "signType",
            "appId",
            "signSource",
            "businessLicense",
            sourceType
          )
        );
        if (this.thirdInterest === 1) {
          this.form.setFieldsValue({
            thirdAuthorize: data.thirdAuthorize,
          });
        }
        if (!this.disabled) {
          this.form.setFieldsValue({
            applyInstructions: data.applyInstructions,
          });
        }
        setTimeout(() => {
          this.form.setFieldsValue({
            thirdInterest: data.thirdInterest,
          });
        }, 200)
      });
    },
    getAppList() {
      const params = {
        accountId: this.user.accountId,
        appName: this.appValue,
        queryType: 1,
        isDomestic: 1,
      };
      this.appFetching = true;
      return getAppOptions({ ...params, pagination: { page: 1, size: 100 } });
    },
    handleAppSearch(val) {
      this.lastFetchId += 1;
      const fetchId = this.lastFetchId;
      this.appValue = val;
      this.appFetching = true;
      this.getAppList()
        .then((data) => {
          if (fetchId !== this.lastFetchId) {
            return;
          }
          const { errorCode, result } = data;
          if (errorCode === "0") {
            if (result) {
              this.appOptions = result.smsAppsPos || [];
            } else {
              this.appOptions = [];
            }
          }
          this.appFetching = false;
        })
        .catch((error) => {
          console.log(error);
          this.appFetching = false;
        });
    },
    handleSignChange(val) {
      this.formData.signType = val;
      this.$nextTick(() => {
        this.form.validateFields(["signName"], (err) => {
          console.log(err);
        });
      });
    },
    handleSourceChange(e) {
      this.formData.signSource = e.target.value;
    },
    handleAppChange(val) {
      this.formData.appId = val;
      if (!val) {
        this.handleAppSearch();
      }
    },
    changeAuthorize(e) {
      this.formData.thirdInterest = e.target.value;
    },
    handleSubmit(e) {
      e.preventDefault();
      this.submitLoading = true;
      this.form.validateFields(async (err, values) => {
        if (!err) {
          const { businessLicense, thirdAuthorize } = this.formData;
          if (this.isCreate) {
            // 新增时必穿，更新时若无修改营业执照或委托书则不传
            if (!businessLicense) {
              return this.$message.error("请先上传营业执照");
            }
            if (values.thirdInterest === 1 && !thirdAuthorize) {
              return this.$message.error("请上传授权委托书");
            }
            values = { ...values, thirdAuthorize, businessLicense };
            this.addSign(values);
          } else {
            values =
              this.businessLicenseData === businessLicense
                ? this.$_.omit(values, ["businessLicense"])
                : { ...values, businessLicense };
            values =
              this.thirdAuthorizeData === thirdAuthorize
                ? this.$_.omit(values, ["thirdAuthorize"])
                : { ...values, thirdAuthorize };
            this.updateSign(values);
          }
        } else {
          this.submitLoading = false;
        }
      });
    },
    addSign(params) {
      addSign({ ...params, accountId: this.user.accountId })
        .then((data) => {
          const { errorCode, errorMsg } = data;
          if (errorCode === "0") {
            this.$message.success("新增签名成功");
            this.$router.push("/sign/list");
          } else {
            this.$message.error(errorMsg);
          }
          this.submitLoading = false;
        })
        .catch(() => {
          this.submitLoading = false;
        });
    },
    updateSign(params) {
      updateSign({
        ...params,
        accountId: this.user.accountId,
        signId: this.formData.signId,
      })
        .then((data) => {
          const { errorCode, errorMsg } = data;
          if (errorCode === "0") {
            this.$message.success("更新签名成功");
            this.$router.push("/sign/list");
          } else {
            this.$message.error(errorMsg);
          }
          this.submitLoading = false;
        })
        .catch(() => {
          this.submitLoading = false;
        });
    },
    // 上传前
    beforeUpload(file, type) {
      // type: 营业执照/委托书
      this.isLt2M = true;
      this.isImage = true;
      this[type] = file;
      // 限制文件格式
      this.isImage =
        file.type === "image/jpeg" ||
        file.type === "image/png" ||
        file.type === "image/gif" ||
        file.type === "image/jpeg";
      // 限制图片大小小于2M
      this.isLt2M = file.size / 1024 / 1024 < 2;
      if (!this.isLt2M || !this.isImage) {
        this[`${type}List`] = [];
      } else {
        this[`${type}List`] = [file];
      }
      return false;
    },
    // 上传文件
    uploadFile(type) {
      if (!this.isLt2M) {
        return this.$message.error("上传图片必须小于2M！");
      }
      if (!this.isImage) {
        return this.$message.error("支持jpg、png、gif、jpeg格式的图片");
      }
      const formData = new FormData();
      formData.append(type, this[type]);
      this.submitLoading = true;
      uploadFile(formData)
        .then((data) => {
          const { errorCode, errorMsg, result } = data;
          this.submitLoading = false;
          if (errorCode === "0" && result) {
            this[`${type}Data`] = "";
            this.formData[type] = result[type];
          } else {
            this.$message.error(errorMsg);
            return false;
          }
        })
        .catch(() => {
          this.submitLoading = false;
          return false;
        });
    },
    showVisible(type) {
      this.visible = true;
      this.showBusiness = type;
    },
    validSignName(rule, value, callback) {
      if (value && value !== this.formData.signName) {
        isExist({
          accountId: this.user.accountId,
          signName: value,
          signType: this.formData.signType,
        }).then((res) => {
          if (res.errorCode !== "0") {
            callback("存在重名签名");
          } else {
            callback();
          }
        });
      } else {
        callback();
      }
    },
    jumpToApp() {
      this.$router.push("/application/create");
    },
    goBack() {
      this.$router.go(-1);
    },
  },
};
</script>

<style lang="less" scoped>
.sign-container {
  background: #ffffff;
  padding: 20px;
}
.img-box {
  padding-top: 20px;
  width: 100%;
  overflow: hidden;
  img {
    width: 100%;
  }
}
.temp-cont {
  width: 100%;
  word-break: break-all;
  line-height: 30px;
}
.sign-modal {
  /deep/ .ant-modal-body {
    height: 600px;
    overflow-y: auto;
  }
}
</style>
