<template>
  <div class="sign-container">
    <div class="header">
      <a-form layout="inline" @submit="handleSearch">
        <a-form-item label="状态">
          <a-select
            placeholder="请选择状态"
            allowClear
            :getPopupContainer="
              (triggerNode) => triggerNode.parentNode || document.body
            "
            @change="getSignList"
            v-model="form.signStatus"
          >
            <a-select-option v-for="ele in statusOptions" :key="ele.value">
              {{ ele.label }}
            </a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="签名名称">
          <a-input v-model="form.signName" allowClear></a-input>
        </a-form-item>
        <a-form-item>
          <a-button
            v-if="hasPermission('signList')"
            type="primary"
            html-type="submit"
            >查询</a-button
          >
          <a-button
            v-if="hasPermission('createSign')"
            type="primary"
            @click="jumpToCreate"
            style="margin-left: 10px"
            >新建签名</a-button
          >
        </a-form-item>
      </a-form>
    </div>
    <div class="sign-table">
      <a-table
        :columns="tableColumns"
        :data-source="tableData"
        rowKey="signId"
        :scroll="{x: 1600}"
        :loading="loading"
        :pagination="tablePagination"
      >
        <template slot="signType" slot-scope="text">
          <span>{{ text | TypeFilter }}</span>
        </template>
        <template slot="signStatus" slot-scope="text, record">
          <a-button
            v-if="hasPermission('configureWayId') && text === 2"
            type="link"
            @click="openPass(record)"
            style="padding: 0"
            >{{ text | StatusFilter }}</a-button
          >
          <span v-else>{{ text | StatusFilter }}</span>
        </template>
        <template slot="auditUrgedStatus" slot-scope="text, record">
          <span>{{ text | AuditFilter(record) }}</span>
        </template>
        <template slot="operation" slot-scope="text, record">
          <a-button
            type="link"
            size="small"
            @click="jumpToEdit(record, 'detail')"
            >详情</a-button
          >
          <a-divider type="vertical" />
          <a-button v-if="hasPermission('signAudit')" :disabled="record.signStatus!==0" type="link" size="small" @click="jumpToAudit(record)">审核</a-button>
          <template v-else>
            <a-button
              v-if="hasPermission('signDetail')"
              type="link"
              size="small"
              :disabled="record.signStatus !== 3"
              @click="jumpToEdit(record)"
              >修改</a-button
            >
            <a-divider type="vertical" />
            <a-button
              v-if="hasPermission('deleteSign')"
              type="link"
              size="small"
              @click="deleteSign(record)"
              >删除</a-button
            >
            <a-divider type="vertical" />
            <a-button
              v-if="hasPermission('signUrgeAduit')"
              :disabled="
                record.auditUrgedStatus === 1 ||
                (record.signStatus !== 0 && record.signStatus !== 5)
              "
              type="link"
              size="small"
              @click="urgeSign(record)"
              >催审
            </a-button>
          </template>
        </template>
      </a-table>
    </div>
    <a-modal
      title="短信签名通道号配置"
      dialogClass="wayId-modal"
      :visible="visible"
      @ok="setConfigWay"
      @cancel="visible = false"
      :confirmLoading="confirmLoading"
    >
      <div class="wayId-cont">
        <a-row>
          <a-col :span="12" v-for="(item, index) in passForm" :key="index">
            <label>{{ item.label }}</label>
            <span v-if="item.prop === 'signStatus'">{{
              activeSign[item.prop] | StatusFilter
            }}</span>
            <span v-else-if="item.prop === 'signType'">{{
              activeSign[item.prop] | TypeFilter
            }}</span>
            <span v-else>{{ activeSign[item.prop] }}</span>
          </a-col>
          <a-col :span="24">
            <label>通道号：</label>
            <a-input
              v-model="activeSign.wayId"
              @input="oninputLimit"
              style="width: 70%"
            ></a-input>
          </a-col>
        </a-row>
      </div>
    </a-modal>
  </div>
</template>

<script>
import {
  TEMPLATE_TYPE,
  SIGN_STATUS,
  SIGN_STATUS_OPTIONS,
} from "@/config/default/sms.config";
import {
  getSignList,
  deleteSign,
  urgeSign,
  setConfigWay,
} from "@/services/sign";
import { mapState } from "vuex";

export default {
  name: "index",
  data() {
    return {
      form: {
        signStatus: undefined,
        signName: "",
      },
      tableData: [],
      loading: false,
      visible: false,
      passForm: [
        { label: "短信签名：", prop: "signName" },
        { label: "签名类型：", prop: "signType", filter: "signType" },
        { label: "所属应用：", prop: "appName" },
        { label: "签名状态：", prop: "signStatus" },
      ],
      activeSign: {},
      confirmLoading: false,
    };
  },
  computed: {
    ...mapState("account", ["user"]),
    tableColumns() {
      return [
        { title: '签名名称', dataIndex: 'signName'},
        { title: '签名类型', dataIndex: 'signType', scopedSlots: { customRender: 'signType' }},
        { title: '所属应用', dataIndex: 'appName' },
        { title: '通道号', dataIndex: 'wayId' },
        { title: '签名状态', dataIndex: 'signStatus', scopedSlots: { customRender: 'signStatus' }, ellipsis: true, width: 180 },
        { title: '催审状态', dataIndex: 'auditUrgedStatus', scopedSlots: { customRender: 'auditUrgedStatus' }},
        { title: '催审时间', dataIndex: 'auditUgedDate', width: 160 },
        { title: '创建时间', dataIndex: 'createdDate', width: 160 },
        { title: '审核说明', dataIndex: 'auditInstructions', ellipsis: true, width: 200 },
        { title: '操作', dataIndex: 'operation', scopedSlots: { customRender: 'operation' },
          width: this.user.accountType === 0 ? 100 : 180, fixed: 'right',  align: 'center' },
      ]
    },
    statusOptions() {
      return this.user.accountType === 0
        ? SIGN_STATUS_OPTIONS
        : SIGN_STATUS_OPTIONS.slice(0, 6);
    },
  },
  mounted() {
    this.getSignList();
  },
  methods: {
    getSignList() {
      if (!this.hasPermission("signList")) {
        return this.$message.error("该用户暂无查询签名权限");
      }
      const { signStatus, signName } = this.form;
      const { current, pageSize } = this.myPagination;
      this.loading = true;
      getSignList({
        accountId: this.user.accountId,
        signStatus,
        signName,
        pagination: { page: current, size: pageSize },
      })
        .then((res) => {
          const { errorCode, errorMsg, result } = res;
          if (errorCode === "0") {
            if (result) {
              const { pagination } = result;
              this.tableData = result.result;
              this.myPagination.total = pagination?.total || 0;
            } else {
              this.tableData = [];
              this.myPagination.total = 0;
            }
          } else {
            this.tableData = [];
            this.myPagination.total = 0;
            this.$message.error(errorMsg);
          }
          this.loading = false;
        })
        .catch(() => {
          this.loading = false;
        });
    },
    handleTableChange(pagination) {
      const { current, pageSize } = pagination;
      this.myPagination = { ...this.myPagination, current, pageSize };
      this.getSignList();
    },
    deleteSign(row) {
      this.$confirm({
        okText: "确认",
        content:
          "删除该状态下的签名，会同步删除该签名对应的通道号和该签名下的所有短信模板，请谨慎操作",
        cancelText: "取消",
        onOk: () => {
          this.loading = true;
          deleteSign({ accountId: this.user.accountId, signId: row.signId })
            .then((data) => {
              if (data.errorCode === "0") {
                this.$message.success("删除成功");
                this.getSignList();
              } else {
                this.$message.error(data.errorMsg);
              }
              this.loading = false;
            })
            .catch(() => {
              this.loading = false;
            });
        },
        onCancel() {
          console.log("Cancel");
        },
      });
    },
    //催审
    urgeSign(row) {
      this.loading = true;
      urgeSign({
        accountId: this.user.accountId,
        signId: row.signId,
        auditUrgedStatus: row.auditUrgedStatus,
      })
        .then((data) => {
          const { errorCode, errorMsg } = data;
          if (errorCode === "0") {
            this.$message.success(errorMsg);
            this.getSignList();
          } else {
            this.$message.error(errorMsg);
          }
          this.loading = false;
        })
        .catch(() => {
          this.loading = false;
        });
    },
    // 设置通道号
    setConfigWay() {
      this.confirmLoading = true;
      const { signId, signStatus, wayId } = this.activeSign;
      setConfigWay({
        accountId: this.user.accountId,
        signId,
        signStatus,
        wayId,
      })
        .then((data) => {
          const { errorCode, errorMsg } = data;
          if (errorCode === "0") {
            this.$message.success("配置通道号成功");
            this.visible = false;
            this.getSignList();
          } else {
            this.$message.error(errorMsg);
          }
          this.confirmLoading = false;
        })
        .catch(() => {
          this.confirmLoading = false;
        });
    },
    handleSearch(e) {
      e.preventDefault();
      this.myPagination.current = 1;
      this.getSignList();
    },
    oninputLimit(e) {
      if (e.target.value) {
        const value = e.target.value.match(/^\d{1,6}/g);
        this.activeSign.wayId = Array.isArray(value) ? value[0] : value;
      } else {
        this.activeSign.wayId = null;
      }
    },
    openPass(row) {
      this.visible = true;
      this.activeSign = this.$_.cloneDeep(row);
    },
    jumpToCreate() {
      this.$router.push({ path: "/sign/create" });
    },
    jumpToEdit(row, type) {
      this.$router.push({
        path: "/sign/detail",
        query: { id: row.signId, type },
      });
    },
    jumpToAudit(row) {
      this.$router.push({ path: "/sign/audit", query: { id: row.signId } });
    },
  },
  filters: {
    TypeFilter(value) {
      const map = new Map(TEMPLATE_TYPE);
      return map.get(value);
    },
    StatusFilter(value) {
      const map = new Map(SIGN_STATUS);
      return map.get(value);
    },
    /**
     * @return {string}
     */
    AuditFilter(value, record) {
      if (value === 1) {
        return "已催审";
      } else if (value === 0 && record.signStatus === 1) {
        return "无催审";
      } else {
        return "未催审";
      }
    },
  },
};
</script>

<style lang="less" scoped>
.sign-container {
  background: #ffffff;
  .header {
    padding: 10px 20px;
    /deep/ .ant-select-selection {
      width: 220px;
    }
  }
  .sign-table {
    /deep/ .ant-table-fixed-right {
      .ant-table-fixed {
        tr td {
          padding: 0 10px;
        }
      }
    }
  }
}
.wayId-modal {
  .wayId-cont {
    /deep/ .ant-col-12 {
      margin-bottom: 10px;
    }
  }
}
</style>
