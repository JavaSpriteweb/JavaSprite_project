<template>
  <div class="app-container">
    <div class="header">
      <a-form layout="inline" @submit.prevent="handleSearch">
        <a-form-item label="统计类型：">
          <a-radio-group v-model="searchForm.queryType" button-style="solid" @change="handleSearch">
            <a-radio-button :value="0">
              详细查询
            </a-radio-button>
            <a-radio-button :value="1">
              按账号统计
            </a-radio-button>
          </a-radio-group>
        </a-form-item>

        <a-form-item v-if="user.accountType === 0" label="账号：">
          <a-select
            allowClear
            show-search
            style="width: 200px"
            :disabled="user.accountType !== 0"
            v-model="searchForm.queryAccountId"
          >
            <a-select-option
              v-for="accountItem in accountList"
              :key="accountItem.accountId"
              :value="accountItem.userName"
            >
              {{ accountItem.userName }}
            </a-select-option>
          </a-select>
        </a-form-item>

        <a-form-item label="起止日期:">
          <a-range-picker
            :show-time="{ format: 'HH:mm' }"
            format="YYYY-MM-DD HH:mm"
            :placeholder="['开始', '截至']"
            v-model="searchForm.dateTimeRange"
          />
        </a-form-item>

        <a-form-item>
          <a-button type="primary" html-type="submit">查询</a-button>
        </a-form-item>
      </a-form>
    </div>
    <div class="content">
      <a-table
        v-if="!searchForm.queryType"
        row-key="serail"
        :columns="detailColumns"
        :scroll="{ x: 900 }"
        :loading="loading"
        :data-source="detailData"
        :pagination="tablePagination"
      >
        <template slot="operation" slot-scope="text, record">
          <a-button type="link" size="small" @click="handleClickDetailInfo(record)">详情</a-button>
        </template>
      </a-table>
      <a-table
        v-else
        :columns="summaryColumns"
        row-key="serail"
        :scroll="{ x: 900 }"
        :loading="loading"
        :data-source="summaryData"
        :pagination="tablePagination"
      >
      </a-table>
    </div>
    <a-modal :visible="isShowDetailInfo" title="查看详情" :closable="false">
      <template slot="footer">
        <a-button key="back" @click="handleCancel">
          返回
        </a-button>
      </template>
      <a-form>
        <a-form-item label="入参">
          <a-textarea v-model="modalForm.inputParam" :rows="5" />
        </a-form-item>
        <a-form-item label="出参">
          <a-textarea v-model="modalForm.outputParam" :rows="5" />
        </a-form-item>
        <a-form-item label="响应时间(ms)">
          <a-input v-model="modalForm.responseTime" />
        </a-form-item>
      </a-form>
    </a-modal>
  </div>
</template>

<script>
import moment from 'moment'
import { mapState } from 'vuex'
import { getAccounts } from '@/services/account'
import { getOperationLogs } from '@/services/smsOperateLog'
export default {
  name: 'index',
  data() {
    return {
      loading: false,
      searchForm: {
        queryType: 0,
        queryAccountId: '',
        dateTimeRange: [moment({ hour: 0, minute: 0 }), moment({ hour: 23, minute: 59 })]
      },
      modalForm: {
        inputParam: '',
        outputParam: '',
        responseTime: ''
      },
      isShowDetailInfo: false,
      accountList: [],
      detailData: [],
      summaryData: [],
      detailColumns: [
        { title: '账户名', dataIndex: 'accountName' },
        { title: '调用页面', dataIndex: 'pageName' },
        { title: '操作信息', dataIndex: 'operateInfo' },
        { title: '服务信息', ellipsis: true, dataIndex: 'serverInfo' },
        { title: '操作时间', width: '170px', dataIndex: 'operateDate' },
        { title: '返回结果', width: '100px', dataIndex: 'errorCode' },
        { title: '响应时间（ms）', width: '140px', dataIndex: 'responseTime' },
        {
          title: '操作',
          width: '80px',
          align: 'center',
          fixed: 'right',
          scopedSlots: { customRender: 'operation' }
        }
      ],
      summaryColumns: [
        { title: '账户名', dataIndex: 'accountName' },
        { title: '调用页面', dataIndex: 'pageName' },
        { title: '操作信息', dataIndex: 'operateInfo' },
        { title: '服务信息', ellipsis: true, dataIndex: 'serverInfo' },
        { title: '操作次数', width: '100px', dataIndex: 'operateTimes' },
        { title: '最小响应时间', width: '120px', dataIndex: 'minTime' },
        { title: '最大响应时间', width: '120px', dataIndex: 'maxTime' },
        { title: '平均响应时间', width: '120px', dataIndex: 'avgTime' }
      ]
    }
  },
  computed: {
    ...mapState('account', ['user'])
  },
  methods: {
    handleTableChange(pagination) {
      this.myPagination = {
        ...this.myPagination,
        current: pagination.current,
        pageSize: pagination.pageSize
      }
      this.getLoggers()
    },
    getLoggers() {
      this.loading = true
      const { current: page, pageSize: size } = this.myPagination
      let { queryType, queryAccountId, dateTimeRange } = this.searchForm
      const account = this.accountList.find(item => !this._isNull(item.userName) && (item.userName === queryAccountId)) || {}
      queryAccountId = account.accountId
      const beginDate = moment(dateTimeRange[0]).format('YYYY-MM-DD HH:mm:ss')
      const endDate = moment(dateTimeRange[1]).format('YYYY-MM-DD HH:mm:ss')
      const { accountId } = this.user
      const params = { queryType, accountId, queryAccountId, beginDate, endDate, pagination: { page, size } }
      getOperationLogs(params)
        .then(res => {
          const { errorCode, errorMsg, operateLogs = [], mergeInfos = [], pagination } = res || {}
          if (+errorCode === 0) {
            if (this.searchForm.queryType) {
              this.summaryData = mergeInfos.map((item, index) => Object.assign({ serail: index }, item))
            } else {
              this.detailData = operateLogs.map((item, index) => Object.assign({ serail: index }, item))
            }
            this.myPagination.total = pagination.total
          } else {
            this.$message.error(errorMsg)
          }
        })
        .finally(() => {
          this.loading = false
        })
    },
    handleSearch() {
      this.myPagination.current = 1
      if (this.searchForm.queryType === 1 && this.user.accountType === 1) {
        const account = this.accountList.find(item => item.accountId === this.user.accountId) || {}
        this.searchForm.queryAccountId = account.userName
      }
      this.getLoggers()
    },
    handleClickDetailInfo(record) {
      let { inputParam, outputParam, responseTime } = record
      try {
        inputParam = JSON.stringify(JSON.parse(inputParam), null, 4)
        outputParam = JSON.stringify(JSON.parse(outputParam), null, 4)
      } catch (error) {
        console.log(error)
      }
      this.modalForm = { inputParam, outputParam, responseTime }
      this.isShowDetailInfo = true
    },
    handleCancel() {
      this.isShowDetailInfo = false
    }
  },
  mounted() {
    getAccounts({ pagination: { page: 1, size: 99999 } }).then(({ errorCode, errorMsg, result }) => {
      if (+errorCode === 0) {
        const { smsAccountOutVos = [] } = result || {}
        this.accountList = smsAccountOutVos
        // const account = this.accountList.find(item => item.accountId === this.user.accountId) || {}
        // this.searchForm.queryAccountId = account.userName
      } else {
        this.$message.error(errorMsg)
      }
    })
    this.getLoggers()
  }
}
</script>

<style lang="less" scoped>
.app-container {
  background: #ffffff;
  width: 100%;
  height: 100%;
  .header {
    padding: 10px 20px;
    /deep/ .ant-select-selection {
      width: 160px;
    }
  }
  .app-table {
    span {
      i {
        margin-right: 5px;
      }
    }
  }
}
</style>
