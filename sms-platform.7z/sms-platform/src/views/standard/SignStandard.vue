<template>
  <div class="help-content" bi_parent_name="content">
    <div id="body8662426"><p id="ZH-CN_TOPIC_0186217386__p940514329011"></p>
      <p id="ZH-CN_TOPIC_0186217386__p483564925615">国内短信需携带签名，短信签名=【】+签名名称，例如【华为云】。</p>
      <p id="ZH-CN_TOPIC_0186217386__p16225613114710">请根据企业业务需要，提前申请短信签名（可申请多个），避免因审核时长（仅支持工作日审核）造成业务损失。</p>
      <p id="ZH-CN_TOPIC_0186217386__p2808433125019">请阅读以下规范，确保您的签名符合。</p>
      <div class="section" id="ZH-CN_TOPIC_0186217386__zh-cn_topic_0147149881_zh-cn_topic_0141091023_section2865035121211"><h4 class="sectiontitle" id="section0">内容规范</h4>
        <div class="tablenoborder"><table cellpadding="4" cellspacing="0" summary="" id="ZH-CN_TOPIC_0186217386__table1855075712526" frame="border" border="1" rules="all"><tbody><tr id="ZH-CN_TOPIC_0186217386__row755113573523"><th class="firstcol" valign="top" width="15.42%" id="mcps1.3.5.2.1.3.1.1"><p id="ZH-CN_TOPIC_0186217386__p18551125719526"><strong id="ZH-CN_TOPIC_0186217386__b174854715534">内容</strong></p>
        </th>
          <td class="cellrowborder" valign="top" width="84.58%" headers="mcps1.3.5.2.1.3.1.1 "><ul id="ZH-CN_TOPIC_0186217386__ul165015212553"><li id="ZH-CN_TOPIC_0186217386__li85021221552">不支持中性化签名，需能辨别所属公司或公司归属的网站、产品、APP，建议为签名来源的全称或简称。</li><li id="ZH-CN_TOPIC_0186217386__li385641318553">签名不能含有黄赌毒及其他违反法律法规的内容。</li></ul>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217386__row19551115715524"><th class="firstcol" valign="top" width="15.42%" id="mcps1.3.5.2.1.3.2.1"><p id="ZH-CN_TOPIC_0186217386__p155175785216"><strong id="ZH-CN_TOPIC_0186217386__b041313413546">长度</strong></p>
        </th>
          <td class="cellrowborder" valign="top" width="84.58%" headers="mcps1.3.5.2.1.3.2.1 "><p id="ZH-CN_TOPIC_0186217386__p15552195785212">签名名称要求2~8个字（只能包含中文、数字、字母，不能为纯数字，单个中文、数字、字母都按一个字计算）。</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217386__row135521457145219"><th class="firstcol" valign="top" width="15.42%" id="mcps1.3.5.2.1.3.3.1"><p id="ZH-CN_TOPIC_0186217386__p85524575524"><strong id="ZH-CN_TOPIC_0186217386__b9587065546">格式</strong></p>
        </th>
          <td class="cellrowborder" valign="top" width="84.58%" headers="mcps1.3.5.2.1.3.3.1 "><ul id="ZH-CN_TOPIC_0186217386__ul1357419815110"><li id="ZH-CN_TOPIC_0186217386__li85741684119">签名名称区分英文大小写，例如：“<span id="ZH-CN_TOPIC_0186217386__ph1828371291811">ABC</span>001”和“<span id="ZH-CN_TOPIC_0186217386__ph556617111815">abc</span>001”是两个不同的签名名称。</li><li id="ZH-CN_TOPIC_0186217386__li11255111014117">申请签名时只需填写签名名称，系统会自动为您加上【】。</li></ul>
          </td>
        </tr>
        </tbody>
        </table>
        </div>
      </div>
      <div class="section" id="ZH-CN_TOPIC_0186217386__zh-cn_topic_0147149881_zh-cn_topic_0141091023_section176185523125"><h4 class="sectiontitle" id="section1">审核规则</h4><ul id="ZH-CN_TOPIC_0186217386__zh-cn_topic_0147149881_zh-cn_topic_0141091023_ul184691857151919"><li id="ZH-CN_TOPIC_0186217386__zh-cn_topic_0147149881_zh-cn_topic_0141091023_li13469175717199">由于短信签名需要在运营商备案，需要您提供企业的营业执照正本或副本复印件（要加盖企业公章），没有涉及第三方权益签名不需要上传授权委托书，如果第三方短信签名侵犯到第三方权益须获第三方的真实授权，查看<a href="#ZH-CN_TOPIC_0186217386__zh-cn_topic_0147149881_zh-cn_topic_0141091023_section474061982014">第三方权益介绍</a>。</li><li id="ZH-CN_TOPIC_0186217386__zh-cn_topic_0147149881_zh-cn_topic_0141091023_li13469205716199">签名来源不同，需要提供的申请材料也不同，查看<a href="#ZH-CN_TOPIC_0186217386__zh-cn_topic_0147149881_zh-cn_topic_0141091023_section155744331202">签名申请材料</a>。</li></ul>
      </div>
      <div class="section" id="ZH-CN_TOPIC_0186217386__zh-cn_topic_0147149881_zh-cn_topic_0141091023_section474061982014"><a name="ZH-CN_TOPIC_0186217386__zh-cn_topic_0147149881_zh-cn_topic_0141091023_section474061982014" style="margin: 0px;"></a><a name="zh-cn_topic_0147149881_zh-cn_topic_0141091023_section474061982014" style="margin: 0px;"></a><h4 class="sectiontitle" id="section2">第三方权益</h4><p id="ZH-CN_TOPIC_0186217386__zh-cn_topic_0147149881_zh-cn_topic_0141091023_p1099344882110"><strong id="ZH-CN_TOPIC_0186217386__zh-cn_topic_0147149881_zh-cn_topic_0141091023_b99931648112112">概念介绍</strong></p>
        <ul id="ZH-CN_TOPIC_0186217386__ul1471638213"><li id="ZH-CN_TOPIC_0186217386__li164723819117">如果A公司申请签名，签名归属主体属于A，则不涉及第三方权益。</li><li id="ZH-CN_TOPIC_0186217386__li374843915116">如果A公司替B公司申请签名，签名归属主体属于B，则涉及第三方权益且需要B公司给予A公司的授权委托书。B为授权方，A为被授权方。</li></ul>
        <p id="ZH-CN_TOPIC_0186217386__zh-cn_topic_0147149881_zh-cn_topic_0141091023_p119931948102112"><strong id="ZH-CN_TOPIC_0186217386__zh-cn_topic_0147149881_zh-cn_topic_0141091023_b3993124810219">功能优势</strong></p>
        <p id="ZH-CN_TOPIC_0186217386__zh-cn_topic_0147149881_zh-cn_topic_0141091023_p3993194817218">加入第三方权益介绍的概念是为了简化签名申请的流程，对于不涉及第三方权益可以直接申请签名，只需上传签名归属主体单位的营业执照，对于涉及第三方权益需要上传签名归属主体单位的企业营业执照和授权委托书。</p>
        <p id="ZH-CN_TOPIC_0186217386__p46046241642"><strong id="ZH-CN_TOPIC_0186217386__b1184116501641">示例说明</strong></p>
        <p id="ZH-CN_TOPIC_0186217386__p1028319451443">A公司因业务需求，为自己申请签名，即签名归属主体属于A，则签名申请材料中的营业执照，需上传A公司的营业执照正本或副本复印件（要加盖企业公章）。</p>
        <p id="ZH-CN_TOPIC_0186217386__p156071956278">A公司替B公司申请签名，即签名归属主体属于B，则签名申请材料中的营业执照，需上传B公司的营业执照正本或副本复印件（要加盖企业公章），且还需上传B公司给予A公司的授权委托书。</p>

        <div class="tablenoborder"><table cellpadding="4" cellspacing="0" summary="" id="ZH-CN_TOPIC_0186217386__table11945131051317" frame="border" border="1" rules="all"><thead align="left"><tr id="ZH-CN_TOPIC_0186217386__row994751051310"><th align="left" class="cellrowborder" valign="top" width="15.000000000000002%" id="mcps1.3.7.9.1.5.1.1"><p id="ZH-CN_TOPIC_0186217386__p9348129131316">华为云账号（企业实名认证主体）</p>
        </th>
          <th align="left" class="cellrowborder" valign="top" width="15.000000000000002%" id="mcps1.3.7.9.1.5.1.2"><p id="ZH-CN_TOPIC_0186217386__p3947141017132">签名归属主体</p>
          </th>
          <th align="left" class="cellrowborder" valign="top" width="35%" id="mcps1.3.7.9.1.5.1.3"><p id="ZH-CN_TOPIC_0186217386__p1594721010138">签名申请材料（营业执照）</p>
          </th>
          <th align="left" class="cellrowborder" valign="top" width="35%" id="mcps1.3.7.9.1.5.1.4"><p id="ZH-CN_TOPIC_0186217386__p139487104135">签名申请材料（授权委托书）</p>
          </th>
        </tr>
        </thead>
          <tbody><tr id="ZH-CN_TOPIC_0186217386__row129481010161317"><td class="cellrowborder" valign="top" width="15.000000000000002%" headers="mcps1.3.7.9.1.5.1.1 "><p id="ZH-CN_TOPIC_0186217386__p2094861011133">A公司</p>
          </td>
            <td class="cellrowborder" valign="top" width="15.000000000000002%" headers="mcps1.3.7.9.1.5.1.2 "><p id="ZH-CN_TOPIC_0186217386__p3948171018139">A公司</p>
            </td>
            <td class="cellrowborder" valign="top" width="35%" headers="mcps1.3.7.9.1.5.1.3 "><p id="ZH-CN_TOPIC_0186217386__p494810104134">A公司的营业执照正本或副本复印件（要加盖企业公章）</p>
            </td>
            <td class="cellrowborder" valign="top" width="35%" headers="mcps1.3.7.9.1.5.1.4 "><p id="ZH-CN_TOPIC_0186217386__p10948131010137">不需要</p>
            </td>
          </tr>
          <tr id="ZH-CN_TOPIC_0186217386__row189486107139"><td class="cellrowborder" valign="top" width="15.000000000000002%" headers="mcps1.3.7.9.1.5.1.1 "><p id="ZH-CN_TOPIC_0186217386__p1594891011315">A公司</p>
          </td>
            <td class="cellrowborder" valign="top" width="15.000000000000002%" headers="mcps1.3.7.9.1.5.1.2 "><p id="ZH-CN_TOPIC_0186217386__p1994901019139">B公司</p>
            </td>
            <td class="cellrowborder" valign="top" width="35%" headers="mcps1.3.7.9.1.5.1.3 "><p id="ZH-CN_TOPIC_0186217386__p59491102131">B公司的营业执照正本或副本复印件（要加盖企业公章）</p>
            </td>
            <td class="cellrowborder" valign="top" width="35%" headers="mcps1.3.7.9.1.5.1.4 "><p id="ZH-CN_TOPIC_0186217386__p139493103139">B公司给予A公司的授权委托书</p>
            </td>
          </tr>
          </tbody>
        </table>
        </div>
      </div>
      <div class="section" id="ZH-CN_TOPIC_0186217386__zh-cn_topic_0147149881_zh-cn_topic_0141091023_section155744331202"><a name="ZH-CN_TOPIC_0186217386__zh-cn_topic_0147149881_zh-cn_topic_0141091023_section155744331202" style="margin: 0px;"></a><a name="zh-cn_topic_0147149881_zh-cn_topic_0141091023_section155744331202" style="margin: 0px;"></a><h4 class="sectiontitle" id="section3">签名申请材料</h4><p id="ZH-CN_TOPIC_0186217386__p8849185723911">注：<strong id="ZH-CN_TOPIC_0186217386__b1931074410419">营业执照</strong>和<strong id="ZH-CN_TOPIC_0186217386__b931119447417">授权委托书</strong>支持jpg、png、gif、jpeg格式的图片，每张图片不大于2MB。</p>

        <div class="tablenoborder"><table cellpadding="4" cellspacing="0" summary="" id="ZH-CN_TOPIC_0186217386__table899640192216" frame="border" border="1" rules="all"><thead align="left"><tr id="ZH-CN_TOPIC_0186217386__row6380104012227"><th align="left" class="cellrowborder" valign="top" width="20%" id="mcps1.3.8.3.1.3.1.1"><p id="ZH-CN_TOPIC_0186217386__p1938014012217">签名来源</p>
        </th>
          <th align="left" class="cellrowborder" valign="top" width="80%" id="mcps1.3.8.3.1.3.1.2"><p id="ZH-CN_TOPIC_0186217386__p15380134052214">申请要求</p>
          </th>
        </tr>
        </thead>
          <tbody><tr id="ZH-CN_TOPIC_0186217386__row638018406226"><td class="cellrowborder" valign="top" width="20%" headers="mcps1.3.8.3.1.3.1.1 "><p id="ZH-CN_TOPIC_0186217386__p23801240162217">企事业单位的全称或简称</p>
          </td>
            <td class="cellrowborder" valign="top" width="80%" headers="mcps1.3.8.3.1.3.1.2 "><ul id="ZH-CN_TOPIC_0186217386__ul16129742161718"><li id="ZH-CN_TOPIC_0186217386__li012919421179">需上传签名归属实体的<strong id="ZH-CN_TOPIC_0186217386__b6339750702">三证合一</strong>、<strong id="ZH-CN_TOPIC_0186217386__b5497105320018">五证合一</strong>、<strong id="ZH-CN_TOPIC_0186217386__b234625719019">企业营业执照</strong>、<strong id="ZH-CN_TOPIC_0186217386__b19687109111">事业单位法人证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b599454119">社会团体法人登记证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b4550131413117">组织机构代码证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b855713191119">行政执法主体资格证</strong>或<strong id="ZH-CN_TOPIC_0186217386__b1766762319120">统一社会信用代码证书</strong>。<p id="ZH-CN_TOPIC_0186217386__p4683417135720">注：根据实际情况，选择其中一种证书文件上传即可。</p>
            </li><li id="ZH-CN_TOPIC_0186217386__li14129154281717">若涉及第三方权益，还需上传<strong id="ZH-CN_TOPIC_0186217386__b20483182911118">授权委托书</strong>。</li></ul>
            </td>
          </tr>
          <tr id="ZH-CN_TOPIC_0186217386__row5381540102212"><td class="cellrowborder" valign="top" width="20%" headers="mcps1.3.8.3.1.3.1.1 "><p id="ZH-CN_TOPIC_0186217386__p1438154012220">工信部备案网站的全称或简称</p>
          </td>
            <td class="cellrowborder" valign="top" width="80%" headers="mcps1.3.8.3.1.3.1.2 "><ul id="ZH-CN_TOPIC_0186217386__ul107846377189"><li id="ZH-CN_TOPIC_0186217386__li9784143791818">需上传签名归属实体的<strong id="ZH-CN_TOPIC_0186217386__b15616124615315">三证合一</strong>、<strong id="ZH-CN_TOPIC_0186217386__b1461664614319">五证合一</strong>、<strong id="ZH-CN_TOPIC_0186217386__b166166464317">企业营业执照</strong>、<strong id="ZH-CN_TOPIC_0186217386__b1617144614314">事业单位法人证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b2061754616314">社会团体法人登记证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b1761734612313">组织机构代码证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b156175461633">行政执法主体资格证</strong>或<strong id="ZH-CN_TOPIC_0186217386__b26171246934">统一社会信用代码证书</strong>。<p id="ZH-CN_TOPIC_0186217386__p124257321901">注：根据实际情况，选择其中一种证书文件上传即可。</p>
            </li><li id="ZH-CN_TOPIC_0186217386__li87841137111817">若涉及第三方权益，还需上传<strong id="ZH-CN_TOPIC_0186217386__b18617134610316">授权委托书</strong>。</li><li id="ZH-CN_TOPIC_0186217386__li6784173713187">网站域名：输入工信部备案网站域名，如msgsms.console.huawei.com<p id="ZH-CN_TOPIC_0186217386__p7382540102219"><a name="ZH-CN_TOPIC_0186217386__li6784173713187" style="margin: 0px;"></a><a name="li6784173713187" style="margin: 0px;"></a>查询入口：<a href="http://www.beian.miit.gov.cn/" target="_blank" rel="noopener noreferrer">http://www.beian.miit.gov.cn/</a>（选择“公共查询”）</p>
            </li></ul>
            </td>
          </tr>
          <tr id="ZH-CN_TOPIC_0186217386__row9383640182215"><td class="cellrowborder" valign="top" width="20%" headers="mcps1.3.8.3.1.3.1.1 "><p id="ZH-CN_TOPIC_0186217386__p16383340162210">APP应用的全称或简称</p>
          </td>
            <td class="cellrowborder" valign="top" width="80%" headers="mcps1.3.8.3.1.3.1.2 "><ul id="ZH-CN_TOPIC_0186217386__ul925831917194"><li id="ZH-CN_TOPIC_0186217386__li1025820192196">需上传签名归属实体的<strong id="ZH-CN_TOPIC_0186217386__b413815819715">三证合一</strong>、<strong id="ZH-CN_TOPIC_0186217386__b6138158776">五证合一</strong>、<strong id="ZH-CN_TOPIC_0186217386__b1413817581479">企业营业执照</strong>、<strong id="ZH-CN_TOPIC_0186217386__b1213815589712">事业单位法人证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b161380582712">社会团体法人登记证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b1613814581273">组织机构代码证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b101389587720">行政执法主体资格证</strong>或<strong id="ZH-CN_TOPIC_0186217386__b2013814581572">统一社会信用代码证书</strong>。<p id="ZH-CN_TOPIC_0186217386__p5766138701">注：根据实际情况，选择其中一种证书文件上传即可。</p>
            </li><li id="ZH-CN_TOPIC_0186217386__li12259131911913">若涉及第三方权益，还需上传<strong id="ZH-CN_TOPIC_0186217386__b151381158572">授权委托书</strong>。</li><li id="ZH-CN_TOPIC_0186217386__li202591319141911">APP应用下载地址：输入任一应用商店的APP应用下载链接</li></ul>
            </td>
          </tr>
          <tr id="ZH-CN_TOPIC_0186217386__row338454019225"><td class="cellrowborder" valign="top" width="20%" headers="mcps1.3.8.3.1.3.1.1 "><p id="ZH-CN_TOPIC_0186217386__p9384144015220">公众号或小程序的全称或简称</p>
          </td>
            <td class="cellrowborder" valign="top" width="80%" headers="mcps1.3.8.3.1.3.1.2 "><ul id="ZH-CN_TOPIC_0186217386__ul18170124120252"><li id="ZH-CN_TOPIC_0186217386__li6170104162512">需上传签名归属实体的<strong id="ZH-CN_TOPIC_0186217386__b1476155651911">三证合一</strong>、<strong id="ZH-CN_TOPIC_0186217386__b12761185617193">五证合一</strong>、<strong id="ZH-CN_TOPIC_0186217386__b77611056191917">企业营业执照</strong>、<strong id="ZH-CN_TOPIC_0186217386__b1576125613192">事业单位法人证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b187611856161916">社会团体法人登记证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b6761145621910">组织机构代码证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b127611856111910">行政执法主体资格证</strong>或<strong id="ZH-CN_TOPIC_0186217386__b1076115616199">统一社会信用代码证书</strong>。<p id="ZH-CN_TOPIC_0186217386__p1597943900">注：根据实际情况，选择其中一种证书文件上传即可。</p>
            </li><li id="ZH-CN_TOPIC_0186217386__li81718419255">若涉及第三方权益，还需上传<strong id="ZH-CN_TOPIC_0186217386__b454014472012">授权委托书</strong>。</li><li id="ZH-CN_TOPIC_0186217386__li18171341152519">公众号或者小程序的全称：需填写公众号或小程序的全称<p id="ZH-CN_TOPIC_0186217386__p1186554782517"><a name="ZH-CN_TOPIC_0186217386__li18171341152519" style="margin: 0px;"></a><a name="li18171341152519" style="margin: 0px;"></a>要求公众号或小程序已上线且在微信上能搜索到。</p>
            </li></ul>
              <p id="ZH-CN_TOPIC_0186217386__p1384540102210">如需查看公众号或小程序签名归属与账号主体是否一致，请打开微信 - 搜索 - 公众号/小程序 - 点击右上角更多资料查看相关信息。</p>
            </td>
          </tr>
          <tr id="ZH-CN_TOPIC_0186217386__row638515400226"><td class="cellrowborder" valign="top" width="20%" headers="mcps1.3.8.3.1.3.1.1 "><p id="ZH-CN_TOPIC_0186217386__p1238584022214">电商平台店铺名的全称或简称</p>
          </td>
            <td class="cellrowborder" valign="top" width="80%" headers="mcps1.3.8.3.1.3.1.2 "><ul id="ZH-CN_TOPIC_0186217386__ul1718416264114"><li id="ZH-CN_TOPIC_0186217386__li7184182194117">需上传签名归属实体的<strong id="ZH-CN_TOPIC_0186217386__b1266821733012">三证合一</strong>、<strong id="ZH-CN_TOPIC_0186217386__b1366816176304">五证合一</strong>、<strong id="ZH-CN_TOPIC_0186217386__b1966813173308">企业营业执照</strong>、<strong id="ZH-CN_TOPIC_0186217386__b2066810172300">事业单位法人证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b8668141715303">社会团体法人登记证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b136685177308">组织机构代码证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b966891783016">行政执法主体资格证</strong>或<strong id="ZH-CN_TOPIC_0186217386__b8668181733013">统一社会信用代码证书</strong>。<p id="ZH-CN_TOPIC_0186217386__p1423615503016">注：根据实际情况，选择其中一种证书文件上传即可。</p>
            </li><li id="ZH-CN_TOPIC_0186217386__li111841023415">若涉及第三方权益，还需上传<strong id="ZH-CN_TOPIC_0186217386__b1390043319302">授权委托书</strong>。</li><li id="ZH-CN_TOPIC_0186217386__li318562144114">电商平台店铺地址：输入电商平台店铺的链接地址</li></ul>
              <p id="ZH-CN_TOPIC_0186217386__p438624017225">如需查看电商平台店铺签名归属与账号主体是否一致，请打开电商平台 - 搜索店铺 - 查看店铺详情 - 营业执照查看信息真实性。</p>
            </td>
          </tr>
          <tr id="ZH-CN_TOPIC_0186217386__row10386140122219"><td class="cellrowborder" valign="top" width="20%" headers="mcps1.3.8.3.1.3.1.1 "><p id="ZH-CN_TOPIC_0186217386__p1838664010226">商标名的全称或简称</p>
          </td>
            <td class="cellrowborder" valign="top" width="80%" headers="mcps1.3.8.3.1.3.1.2 "><ul id="ZH-CN_TOPIC_0186217386__ul15393135764510"><li id="ZH-CN_TOPIC_0186217386__li9393195724512">需上传签名归属实体的<strong id="ZH-CN_TOPIC_0186217386__b1832514249301">三证合一</strong>、<strong id="ZH-CN_TOPIC_0186217386__b032572416305">五证合一</strong>、<strong id="ZH-CN_TOPIC_0186217386__b17325162411301">企业营业执照</strong>、<strong id="ZH-CN_TOPIC_0186217386__b332516241303">事业单位法人证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b12325102433018">社会团体法人登记证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b14326122453015">组织机构代码证书</strong>、<strong id="ZH-CN_TOPIC_0186217386__b2326152443014">行政执法主体资格证</strong>或<strong id="ZH-CN_TOPIC_0186217386__b5326824193013">统一社会信用代码证书</strong>。<p id="ZH-CN_TOPIC_0186217386__p1837155818012">注：根据实际情况，选择其中一种证书文件上传即可。</p>
            </li><li id="ZH-CN_TOPIC_0186217386__li1539395794512">若涉及第三方权益，还需上传<strong id="ZH-CN_TOPIC_0186217386__b15277937143012">授权委托书</strong>。</li></ul>
              <p id="ZH-CN_TOPIC_0186217386__p3387104013229">如需查看签名归属商标申请人与账号主体是否一致，请前往<strong id="ZH-CN_TOPIC_0186217386__b199121608519">中国商标网</strong>查看相关信息真实性。</p>
            </td>
          </tr>
          </tbody>
        </table>
        </div>
      </div>
    </div>
    <div></div>
  </div>
</template>

<script>
  export default {
    name: "SignStandard"
  }
</script>

<style scoped>

</style>
