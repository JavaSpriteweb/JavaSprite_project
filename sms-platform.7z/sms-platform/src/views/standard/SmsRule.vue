<template>
  <div class="help-content" bi_parent_name="content">
  <div id="body8662426"><div class="section" id="ZH-CN_TOPIC_0186217385__zh-cn_topic_0141090982_section14214529115710"><a name="ZH-CN_TOPIC_0186217385__zh-cn_topic_0141090982_section14214529115710" style="margin: 0px;"></a><a name="zh-cn_topic_0141090982_section14214529115710" style="margin: 0px;"></a><h4 class="sectiontitle" id="section0">短信内容长度计算规则</h4>
    <ul id="ZH-CN_TOPIC_0186217385__ul1961643021315"><li id="ZH-CN_TOPIC_0186217385__li36801651113518"><p id="ZH-CN_TOPIC_0186217385__p1078815524718">ASCII编码字符按照134个字数拆分计算短信条数。</p>
    </li></ul>

    <div class="tablenoborder"><table cellpadding="4" cellspacing="0" summary="" id="ZH-CN_TOPIC_0186217385__table1045541110550" frame="border" border="1" rules="all"><caption><b>表1 </b>统计细则（“√”指规则适用于该类短信，“-”指不适用）</caption><thead align="left"><tr id="ZH-CN_TOPIC_0186217385__row1654014110321"><th align="left" class="cellrowborder" valign="top" width="22.05%" id="mcps1.3.1.4.2.5.1.1"><p id="ZH-CN_TOPIC_0186217385__p854174115325">短信内容</p>
    </th>
      <th align="left" class="cellrowborder" valign="top" width="55.95%" id="mcps1.3.1.4.2.5.1.2"><p id="ZH-CN_TOPIC_0186217385__p195411417326">字数</p>
      </th>
      <th align="left" class="cellrowborder" valign="top" width="11%" id="mcps1.3.1.4.2.5.1.3"><p id="ZH-CN_TOPIC_0186217385__p65411241173214">国内</p>
      </th>
      <th align="left" class="cellrowborder" valign="top" width="11%" id="mcps1.3.1.4.2.5.1.4"><p id="ZH-CN_TOPIC_0186217385__p55411341113211">国际/港澳台</p>
      </th>
    </tr>
    </thead>
      <tbody><tr id="ZH-CN_TOPIC_0186217385__row645791195520"><td class="cellrowborder" valign="top" width="22.05%" headers="mcps1.3.1.4.2.5.1.1 "><p id="ZH-CN_TOPIC_0186217385__p1245791135515">签名</p>
      </td>
        <td class="cellrowborder" valign="top" width="55.95%" headers="mcps1.3.1.4.2.5.1.2 "><p id="ZH-CN_TOPIC_0186217385__p124581115554">示例：短信签名为“【华为云】”，按5个字数计算</p>
        </td>
        <td class="cellrowborder" valign="top" width="11%" headers="mcps1.3.1.4.2.5.1.3 "><p id="ZH-CN_TOPIC_0186217385__p37715312328">√</p>
        </td>
        <td class="cellrowborder" valign="top" width="11%" headers="mcps1.3.1.4.2.5.1.4 "><p id="ZH-CN_TOPIC_0186217385__p15188128143216">-</p>
        </td>
      </tr>
      <tr id="ZH-CN_TOPIC_0186217385__row945821119554"><td class="cellrowborder" valign="top" width="22.05%" headers="mcps1.3.1.4.2.5.1.1 "><p id="ZH-CN_TOPIC_0186217385__p144584111553">模板变量</p>
      </td>
        <td class="cellrowborder" valign="top" width="55.95%" headers="mcps1.3.1.4.2.5.1.2 "><p id="ZH-CN_TOPIC_0186217385__p753718461235">示例：一个模板变量“${1}”（其他号码），取值为“123456”，按6个字数计算；</p>
          <p id="ZH-CN_TOPIC_0186217385__p1445914112554"><span id="ZH-CN_TOPIC_0186217385__ph2529271634">申请模板时默认以最大值计算变量，最终以实际发送的变量值为准</span></p>
        </td>
        <td class="cellrowborder" valign="top" width="11%" headers="mcps1.3.1.4.2.5.1.3 "><p id="ZH-CN_TOPIC_0186217385__p157818315324">√</p>
        </td>
        <td class="cellrowborder" valign="top" width="11%" headers="mcps1.3.1.4.2.5.1.4 "><p id="ZH-CN_TOPIC_0186217385__p318819289320">√</p>
        </td>
      </tr>
      <tr id="ZH-CN_TOPIC_0186217385__row174593117553"><td class="cellrowborder" valign="top" width="22.05%" headers="mcps1.3.1.4.2.5.1.1 "><p id="ZH-CN_TOPIC_0186217385__p14599117550">小数点、字母、汉字、空格以及其他符号</p>
      </td>
        <td class="cellrowborder" valign="top" width="55.95%" headers="mcps1.3.1.4.2.5.1.2 "><p id="ZH-CN_TOPIC_0186217385__p24597118558">汉字按两个字数计算，其它按1个字数计算</p>
        </td>
        <td class="cellrowborder" valign="top" width="11%" headers="mcps1.3.1.4.2.5.1.3 "><p id="ZH-CN_TOPIC_0186217385__p197893117326">√</p>
        </td>
        <td class="cellrowborder" valign="top" width="11%" headers="mcps1.3.1.4.2.5.1.4 "><p id="ZH-CN_TOPIC_0186217385__p61883282321">√</p>
        </td>
      </tr>
      <tr id="ZH-CN_TOPIC_0186217385__row0641104073417"><td class="cellrowborder" valign="top" width="22.05%" headers="mcps1.3.1.4.2.5.1.1 "><p id="ZH-CN_TOPIC_0186217385__p147381745103414">非英文字符（含标点符号）</p>
      </td>
        <td class="cellrowborder" valign="top" width="55.95%" headers="mcps1.3.1.4.2.5.1.2 "><p id="ZH-CN_TOPIC_0186217385__p1473811455347">该条短信按照其他语种短信计算长度，请注意选择文字格式</p>
        </td>
        <td class="cellrowborder" valign="top" width="11%" headers="mcps1.3.1.4.2.5.1.3 "><p id="ZH-CN_TOPIC_0186217385__p164234018348">-</p>
        </td>
        <td class="cellrowborder" valign="top" width="11%" headers="mcps1.3.1.4.2.5.1.4 "><p id="ZH-CN_TOPIC_0186217385__p56432406346">√</p>
        </td>
      </tr>
      </tbody>
    </table>
    </div>
    <p id="ZH-CN_TOPIC_0186217385__p12827185101911">注：</p>
    <ul id="ZH-CN_TOPIC_0186217385__ul253135521811"><li id="ZH-CN_TOPIC_0186217385__li152411711193">短信模板字数上限为500个字，即单条长短信最大长度=短信签名+500个字。</li><li id="ZH-CN_TOPIC_0186217385__li952416710197">发送长短信时，用户侧最终会收到一条长短信，但短信业务平台会按照长短信拆分后短信条数进行业务统计和计费。</li></ul>
  </div>
    <div class="section" id="ZH-CN_TOPIC_0186217385__zh-cn_topic_0141090982_section17611229165418"><a name="ZH-CN_TOPIC_0186217385__zh-cn_topic_0141090982_section17611229165418" style="margin: 0px;"></a><a name="zh-cn_topic_0141090982_section17611229165418" style="margin: 0px;"></a><h4 class="sectiontitle" id="section1">短信发送频率限制</h4><p id="ZH-CN_TOPIC_0186217385__p4230101144814">在实际业务场景中，例如登录APP、网站或通过短信方式找回密码时，可能会有用户频繁获取短信验证码，为了限制平台短信被恶意调用、在短时间内大量发起短信发送请求，也为了避免向同一手机号发送过多短信，可能引起用户投诉，华为云对短信发送行为进行以下流控限制：</p>

      <div class="tablenoborder"><table cellpadding="4" cellspacing="0" summary="" id="ZH-CN_TOPIC_0186217385__table455912302480" frame="border" border="1" rules="all"><thead align="left"><tr id="ZH-CN_TOPIC_0186217385__row20560203013489"><th align="left" class="cellrowborder" valign="top" width="16.14%" id="mcps1.3.2.3.1.5.1.1"><p id="ZH-CN_TOPIC_0186217385__p15560103014488">限制项</p>
      </th>
        <th align="left" class="cellrowborder" valign="top" width="11.58%" id="mcps1.3.2.3.1.5.1.2"><p id="ZH-CN_TOPIC_0186217385__p5950155784612">短信类型</p>
        </th>
        <th align="left" class="cellrowborder" valign="top" width="20%" id="mcps1.3.2.3.1.5.1.3"><p id="ZH-CN_TOPIC_0186217385__p1956053013481">限制频率</p>
        </th>
        <th align="left" class="cellrowborder" valign="top" width="52.28%" id="mcps1.3.2.3.1.5.1.4"><p id="ZH-CN_TOPIC_0186217385__p1353115145816">说明</p>
        </th>
      </tr>
      </thead>
        <tbody><tr id="ZH-CN_TOPIC_0186217385__row156193064816"><td class="cellrowborder" rowspan="4" valign="top" width="16.14%" headers="mcps1.3.2.3.1.5.1.1 "><p id="ZH-CN_TOPIC_0186217385__p16561143013481">号码频次</p>
        </td>
          <td class="cellrowborder" rowspan="2" valign="top" width="11.58%" headers="mcps1.3.2.3.1.5.1.2 "><p id="ZH-CN_TOPIC_0186217385__p19318643575">验证码</p>
            <p id="ZH-CN_TOPIC_0186217385__p173511525195617">通知</p>
          </td>
          <td class="cellrowborder" valign="top" width="20%" headers="mcps1.3.2.3.1.5.1.3 "><p id="ZH-CN_TOPIC_0186217385__p1428945617211"><strong id="ZH-CN_TOPIC_0186217385__b15656510142210">15次/1分钟</strong></p>
          </td>
          <td class="cellrowborder" valign="top" width="52.28%" headers="mcps1.3.2.3.1.5.1.4 "><p id="ZH-CN_TOPIC_0186217385__p1551013202719">任意1分钟内，对同一个手机号码发送短信最多15次，超出次数会被限制。</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217385__row3951940165515"><td class="cellrowborder" valign="top" headers="mcps1.3.2.3.1.5.1.1 "><p id="ZH-CN_TOPIC_0186217385__p65746521616"><strong id="ZH-CN_TOPIC_0186217385__b13576156132211">50次/24小时</strong></p>
        </td>
          <td class="cellrowborder" valign="top" headers="mcps1.3.2.3.1.5.1.2 "><p id="ZH-CN_TOPIC_0186217385__p5313142216327">任意24小时内，对同一个手机号码发送短信最多50次，超出次数会被限制。</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217385__row10364418144719"><td class="cellrowborder" rowspan="2" valign="top" headers="mcps1.3.2.3.1.5.1.1 "><p id="ZH-CN_TOPIC_0186217385__p10297118484">推广</p>
        </td>
          <td class="cellrowborder" valign="top" headers="mcps1.3.2.3.1.5.1.2 "><p id="ZH-CN_TOPIC_0186217385__p19365121817472"><strong id="ZH-CN_TOPIC_0186217385__b17182124614500"><span id="ZH-CN_TOPIC_0186217385__ph12388331350">1</span>次/1<span id="ZH-CN_TOPIC_0186217385__ph91311537173513">小时</span></strong></p>
          </td>
          <td class="cellrowborder" valign="top" headers="mcps1.3.2.3.1.5.1.3 "><p id="ZH-CN_TOPIC_0186217385__p14101544509">任意1<span id="ZH-CN_TOPIC_0186217385__ph12206746143517">小时</span>内，对同一个手机号码发送短信最多<span id="ZH-CN_TOPIC_0186217385__ph7520255103510">1</span>次，超出次数会被限制。</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217385__row74833264811"><td class="cellrowborder" valign="top" headers="mcps1.3.2.3.1.5.1.1 "><p id="ZH-CN_TOPIC_0186217385__p248418217480"><strong id="ZH-CN_TOPIC_0186217385__b3216194614507"><span id="ZH-CN_TOPIC_0186217385__ph5488114093519">3</span>次/24小时</strong></p>
        </td>
          <td class="cellrowborder" valign="top" headers="mcps1.3.2.3.1.5.1.2 "><p id="ZH-CN_TOPIC_0186217385__p12111413502">任意24小时内，对同一个手机号码发送短信最多<span id="ZH-CN_TOPIC_0186217385__ph2999723615">3</span>次，超出次数会被限制。</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217385__row5562173004811"><td class="cellrowborder" rowspan="2" valign="top" width="16.14%" headers="mcps1.3.2.3.1.5.1.1 "><p id="ZH-CN_TOPIC_0186217385__p7562193010488">同号同内容管控</p>
        </td>
          <td class="cellrowborder" rowspan="2" valign="top" width="11.58%" headers="mcps1.3.2.3.1.5.1.2 "><p id="ZH-CN_TOPIC_0186217385__p4695195712">验证码</p>
            <p id="ZH-CN_TOPIC_0186217385__p1544822125713">通知</p>
          </td>
          <td class="cellrowborder" valign="top" width="20%" headers="mcps1.3.2.3.1.5.1.3 "><p id="ZH-CN_TOPIC_0186217385__p16596647162215"><strong id="ZH-CN_TOPIC_0186217385__b8751654162210">2次/59秒</strong></p>
          </td>
          <td class="cellrowborder" valign="top" width="52.28%" headers="mcps1.3.2.3.1.5.1.4 "><p id="ZH-CN_TOPIC_0186217385__p7785194519197">任意59秒内，对同一个手机号码发送同一短信（内容完全相同）最多2次，超出次数会被限制。</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217385__row6471246145513"><td class="cellrowborder" valign="top" headers="mcps1.3.2.3.1.5.1.1 "><p id="ZH-CN_TOPIC_0186217385__p1956211305487"><strong id="ZH-CN_TOPIC_0186217385__b6681165952212">5次/59分钟</strong></p>
        </td>
          <td class="cellrowborder" valign="top" headers="mcps1.3.2.3.1.5.1.2 "><p id="ZH-CN_TOPIC_0186217385__p84727463553">任意59分钟内，对同一个手机号码发送同一短信（内容完全相同）最多5次，超出次数会被限制。</p>
          </td>
        </tr>
        </tbody>
      </table>
      </div>
      <p id="ZH-CN_TOPIC_0186217385__p574152012319"><strong id="ZH-CN_TOPIC_0186217385__b18411058105018">注：推广短信发送时间为每日8:00 - 21:00，夜间无法发送，避免用户投诉。</strong></p>
    </div>
    <div class="section" id="ZH-CN_TOPIC_0186217385__section225873614613"><h4 class="sectiontitle" id="section2">短信轰炸及预防建议</h4><ul id="ZH-CN_TOPIC_0186217385__ul1313463920535"><li id="ZH-CN_TOPIC_0186217385__li3973232593">短信轰炸指在短时间内，给相同手机号码发送大量无效短信，造成用户骚扰，降低产品体验及业务方品牌形象。</li><li id="ZH-CN_TOPIC_0186217385__li6423131416">预防建议：可加上图形验证码，当用户进行短信发送操作前，要求用户输入图形验证码，可防范短信轰炸攻击问题。</li></ul>
    </div>
  </div>


  </div>
</template>

<script>
  export default {
    name: "SmsRule"
  }
</script>

<style scoped>

</style>
