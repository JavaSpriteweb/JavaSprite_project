<template>
  <div class="help-content" bi_parent_name="content">

  <div id="body8662426"><p id="ZH-CN_TOPIC_0186217388__p186121337404"></p>
    <p id="ZH-CN_TOPIC_0186217388__p864511081410">发送短信前需申请短信模板，验证码短信和通知短信的模板样例请参考下表。</p>
    <p id="ZH-CN_TOPIC_0186217388__p153518589460">推广短信无模板样例，请您根据企业业务需求，参考模板和变量规范编辑您的模板。</p>
    <div class="section" id="ZH-CN_TOPIC_0186217388__section105212016111319"><h4 class="sectiontitle" id="section0">验证码短信</h4>
      <div class="tablenoborder"><table cellpadding="4" cellspacing="0" summary="" id="ZH-CN_TOPIC_0186217388__table1860219279187" frame="border" border="1" rules="all"><thead align="left"><tr id="ZH-CN_TOPIC_0186217388__row14603132710182"><th align="left" class="cellrowborder" valign="top" width="15%" id="mcps1.3.4.2.1.4.1.1"><p id="ZH-CN_TOPIC_0186217388__p186031227191811">应用场景</p>
      </th>
        <th align="left" class="cellrowborder" valign="top" width="70%" id="mcps1.3.4.2.1.4.1.2"><p id="ZH-CN_TOPIC_0186217388__p46030276187">模板示例</p>
        </th>
        <th align="left" class="cellrowborder" valign="top" width="15%" id="mcps1.3.4.2.1.4.1.3"><p id="ZH-CN_TOPIC_0186217388__p4716128145517"><span id="ZH-CN_TOPIC_0186217388__ph103617114565">变量属性</span></p>
        </th>
      </tr>
      </thead>
        <tbody><tr id="ZH-CN_TOPIC_0186217388__row1960312719187"><td class="cellrowborder" rowspan="4" valign="top" width="15%" headers="mcps1.3.4.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p26041927131817">登录/验证</p>
        </td>
          <td class="cellrowborder" valign="top" width="70%" headers="mcps1.3.4.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p19812538101812">您的动态码为：${<span id="ZH-CN_TOPIC_0186217388__ph166071958175417">1</span>}，5分钟内有效！请勿泄漏！</p>
          </td>
          <td class="cellrowborder" rowspan="10" valign="top" width="15%" headers="mcps1.3.4.2.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217388__p146611756165614"><span id="ZH-CN_TOPIC_0186217388__ph19665205144918">${1}</span><span id="ZH-CN_TOPIC_0186217388__ph101399724912">：</span><span id="ZH-CN_TOPIC_0186217388__ph09891357165613">其他号码</span></p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row0605142771813"><td class="cellrowborder" valign="top" headers="mcps1.3.4.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p7813133811816">您的校验码为：${<span id="ZH-CN_TOPIC_0186217388__ph186340210554">1</span>}，您正在使用移动服务平台，请勿泄漏验证码。</p>
        </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row86052271183"><td class="cellrowborder" valign="top" headers="mcps1.3.4.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p0813138181816">您的验证码为：${<span id="ZH-CN_TOPIC_0186217388__ph10268184165516">1</span>}，该验证码5分钟内有效，请勿泄漏于他人！</p>
        </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row126050279188"><td class="cellrowborder" valign="top" headers="mcps1.3.4.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p108132387185">您的验证码为：${<span id="ZH-CN_TOPIC_0186217388__ph1772385125514">1</span>}，请尽快完成验证。祝您生活愉快！</p>
        </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row1569518182511"><td class="cellrowborder" valign="top" headers="mcps1.3.4.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p217715108256">注册</p>
        </td>
          <td class="cellrowborder" valign="top" headers="mcps1.3.4.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p6177210142514">您的注册码为：${<span id="ZH-CN_TOPIC_0186217388__ph1191456175515">1</span>}，您正在注册成为会员，感谢您的支持！</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row1445210662512"><td class="cellrowborder" valign="top" headers="mcps1.3.4.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p21773109251">修改密码</p>
        </td>
          <td class="cellrowborder" valign="top" headers="mcps1.3.4.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p11178151010259">您的检验码为：${<span id="ZH-CN_TOPIC_0186217388__ph1522514815555">1</span>}，您正在进行密码重置操作，如非本人操作，请忽略本短信！</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row11606112771819"><td class="cellrowborder" valign="top" headers="mcps1.3.4.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p1606827151812">修改手机号</p>
        </td>
          <td class="cellrowborder" valign="top" headers="mcps1.3.4.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p168132038161811">您正在修改注册手机号码，验证码为：${<span id="ZH-CN_TOPIC_0186217388__ph1764531118559">1</span>}（5分钟有效），为保障帐户安全，请勿向任何人提供此验证码。</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row166060272186"><td class="cellrowborder" valign="top" headers="mcps1.3.4.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p860662713188">找回密码</p>
        </td>
          <td class="cellrowborder" valign="top" headers="mcps1.3.4.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p9814138161815">您正在进行密码找回，验证码为：${<span id="ZH-CN_TOPIC_0186217388__ph968791412553">1</span>} （10分钟内有效），请勿向任何人提供此验证码</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row6606162751813"><td class="cellrowborder" valign="top" headers="mcps1.3.4.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p560618277181">登录</p>
        </td>
          <td class="cellrowborder" valign="top" headers="mcps1.3.4.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p1181410383187">验证码：${<span id="ZH-CN_TOPIC_0186217388__ph616001615554">1</span>}，您正在登录平台帐号，如非本人操作，请勿泄漏 。</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row18607172717183"><td class="cellrowborder" valign="top" headers="mcps1.3.4.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p19607102751816">变更信息</p>
        </td>
          <td class="cellrowborder" valign="top" headers="mcps1.3.4.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p8814143817181">验证码：${<span id="ZH-CN_TOPIC_0186217388__ph03191017105514">1</span>}，您正在变更重要信息，请妥善保管账户信息。</p>
          </td>
        </tr>
        </tbody>
      </table>
      </div>
    </div>
    <div class="section" id="ZH-CN_TOPIC_0186217388__section47152741915"><h4 class="sectiontitle" id="section1">通知短信</h4>
      <div class="tablenoborder"><table cellpadding="4" cellspacing="0" summary="" id="ZH-CN_TOPIC_0186217388__table9596105216192" frame="border" border="1" rules="all"><thead align="left"><tr id="ZH-CN_TOPIC_0186217388__row559614521195"><th align="left" class="cellrowborder" valign="top" width="15%" id="mcps1.3.5.2.1.4.1.1"><p id="ZH-CN_TOPIC_0186217388__p359620523194">应用场景</p>
      </th>
        <th align="left" class="cellrowborder" valign="top" width="64.86%" id="mcps1.3.5.2.1.4.1.2"><p id="ZH-CN_TOPIC_0186217388__p4597125231916">模板示例</p>
        </th>
        <th align="left" class="cellrowborder" valign="top" width="20.14%" id="mcps1.3.5.2.1.4.1.3"><p id="ZH-CN_TOPIC_0186217388__p1369785412115"><span id="ZH-CN_TOPIC_0186217388__ph35001718329">变量属性</span></p>
        </th>
      </tr>
      </thead>
        <tbody><tr id="ZH-CN_TOPIC_0186217388__row959795271910"><td class="cellrowborder" valign="top" width="15%" headers="mcps1.3.5.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p8597852141919">会议</p>
        </td>
          <td class="cellrowborder" valign="top" width="64.86%" headers="mcps1.3.5.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p10617820142213">温馨提醒：${<span id="ZH-CN_TOPIC_0186217388__ph14889155614119">1</span>} ${<span id="ZH-CN_TOPIC_0186217388__ph1063384101215">2</span>} - ${<span id="ZH-CN_TOPIC_0186217388__ph1020912262120">3</span>} 的会议即将开始，请您准时参加。</p>
          </td>
          <td class="cellrowborder" valign="top" width="20.14%" headers="mcps1.3.5.2.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217388__p11511616205411">${1}${2}${3}：时间</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row759714527197"><td class="cellrowborder" valign="top" width="15%" headers="mcps1.3.5.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p16597115271915">消费</p>
        </td>
          <td class="cellrowborder" valign="top" width="64.86%" headers="mcps1.3.5.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p1761752014225">尊敬的客户：您${<span id="ZH-CN_TOPIC_0186217388__ph291310479127">1</span>} ${<span id="ZH-CN_TOPIC_0186217388__ph8667134916128">2</span>}消费${<span id="ZH-CN_TOPIC_0186217388__ph978583141313">3</span>}元，当前帐号余额${<span id="ZH-CN_TOPIC_0186217388__ph1075091112134">4</span>}元。</p>
          </td>
          <td class="cellrowborder" valign="top" width="20.14%" headers="mcps1.3.5.2.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217388__p158211327111814">${1}${2}：时间</p>
            <p id="ZH-CN_TOPIC_0186217388__p1039531011476">${3}${4}：金额</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row9598115213191"><td class="cellrowborder" valign="top" width="15%" headers="mcps1.3.5.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p15598185251910">审核</p>
        </td>
          <td class="cellrowborder" valign="top" width="64.86%" headers="mcps1.3.5.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p19617102011226">您的申请已于${<span id="ZH-CN_TOPIC_0186217388__ph13395153211132">1</span>} ${<span id="ZH-CN_TOPIC_0186217388__ph13957183313130">2</span>}审批通过，请登录平台确认。</p>
          </td>
          <td class="cellrowborder" valign="top" width="20.14%" headers="mcps1.3.5.2.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217388__p5712645101811">${1}${2}：时间</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row0598652151916"><td class="cellrowborder" rowspan="2" valign="top" width="15%" headers="mcps1.3.5.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p17598852171916">注册</p>
        </td>
          <td class="cellrowborder" valign="top" width="64.86%" headers="mcps1.3.5.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p9618620122212">您申请的用户名为：${<span id="ZH-CN_TOPIC_0186217388__ph9304411018">1</span>}，密码：${<span id="ZH-CN_TOPIC_0186217388__ph489716517015">2</span>}，请登录并修改密码。</p>
          </td>
          <td class="cellrowborder" valign="top" width="20.14%" headers="mcps1.3.5.2.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217388__p106981354716"><span id="ZH-CN_TOPIC_0186217388__ph574919364810">${1}</span><span id="ZH-CN_TOPIC_0186217388__ph1271824204814">：</span><span id="ZH-CN_TOPIC_0186217388__ph210953720481">其他</span></p>
            <p id="ZH-CN_TOPIC_0186217388__p181141350485">${2}：其他号码</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row2059919528192"><td class="cellrowborder" valign="top" headers="mcps1.3.5.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p13618112014225">欢迎您的加入！请用注册的手机号码及初始密码（${<span id="ZH-CN_TOPIC_0186217388__ph128946191707">1</span>}）登录。</p>
        </td>
          <td class="cellrowborder" valign="top" headers="mcps1.3.5.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p106988541514"><span id="ZH-CN_TOPIC_0186217388__ph1723415712489">${1}</span><span id="ZH-CN_TOPIC_0186217388__ph20186827174911">：其他号码</span></p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row7599135216191"><td class="cellrowborder" valign="top" width="15%" headers="mcps1.3.5.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p1959995215196">修改密码</p>
        </td>
          <td class="cellrowborder" valign="top" width="64.86%" headers="mcps1.3.5.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p11618132042214">尊敬的用户，您的密码已经重置为${<span id="ZH-CN_TOPIC_0186217388__ph1043032714016">1</span>}，请尽快登录并修改密码。</p>
          </td>
          <td class="cellrowborder" valign="top" width="20.14%" headers="mcps1.3.5.2.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217388__p196981854917"><span id="ZH-CN_TOPIC_0186217388__ph167411744164916">${1}</span><span id="ZH-CN_TOPIC_0186217388__ph92951846124913">：其他号码</span></p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row16001452121912"><td class="cellrowborder" rowspan="2" valign="top" width="15%" headers="mcps1.3.5.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p4600115291917">快递</p>
        </td>
          <td class="cellrowborder" valign="top" width="64.86%" headers="mcps1.3.5.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p3618152017227">您的订单${<span id="ZH-CN_TOPIC_0186217388__ph197780341604">1</span>}已打包发送，快递单号${<span id="ZH-CN_TOPIC_0186217388__ph729918381704">2</span>}，请注意查收。</p>
          </td>
          <td class="cellrowborder" valign="top" width="20.14%" headers="mcps1.3.5.2.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217388__p47218224197">${1}${2}：其他号码</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row146001852171911"><td class="cellrowborder" valign="top" headers="mcps1.3.5.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p106197203224">您的快递${<span id="ZH-CN_TOPIC_0186217388__ph206147401404">1</span>}正在配送中，请注意查收。</p>
        </td>
          <td class="cellrowborder" valign="top" headers="mcps1.3.5.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p17699954518"><span id="ZH-CN_TOPIC_0186217388__ph424813256508">${1}</span><span id="ZH-CN_TOPIC_0186217388__ph20414152645017">：其他号码</span></p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row16600952131912"><td class="cellrowborder" valign="top" width="15%" headers="mcps1.3.5.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p12601135219196">取票</p>
        </td>
          <td class="cellrowborder" valign="top" width="64.86%" headers="mcps1.3.5.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p1761914204229">您已成功预订${<span id="ZH-CN_TOPIC_0186217388__ph1162184710020">1</span>}张门票，取票密码：${<span id="ZH-CN_TOPIC_0186217388__ph31075511501">2</span>}，请提前到达并兑换门票。</p>
          </td>
          <td class="cellrowborder" valign="top" width="20.14%" headers="mcps1.3.5.2.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217388__p10204144012191">${1}${2}：其他号码</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row360145216197"><td class="cellrowborder" valign="top" width="15%" headers="mcps1.3.5.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p13601152141919">预约</p>
        </td>
          <td class="cellrowborder" valign="top" width="64.86%" headers="mcps1.3.5.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p9619820132211">您已成功预约 ${<span id="ZH-CN_TOPIC_0186217388__ph109701124121414">1</span>} ${<span id="ZH-CN_TOPIC_0186217388__ph1454917260143">2</span>}-${<span id="ZH-CN_TOPIC_0186217388__ph41491633111410">3</span>}，预约号${<span id="ZH-CN_TOPIC_0186217388__ph1265319571512">4</span>}，请提前到达等候叫号。</p>
          </td>
          <td class="cellrowborder" valign="top" width="20.14%" headers="mcps1.3.5.2.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217388__p7100176172012">${1}${2}${3}：时间</p>
            <p id="ZH-CN_TOPIC_0186217388__p794711455511">${4}：其他号码</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row860119522193"><td class="cellrowborder" valign="top" width="15%" headers="mcps1.3.5.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p3602115213193">排队</p>
        </td>
          <td class="cellrowborder" valign="top" width="64.86%" headers="mcps1.3.5.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p15619112015228">您的排队号${<span id="ZH-CN_TOPIC_0186217388__ph49852188118">1</span>}，您前面还有${<span id="ZH-CN_TOPIC_0186217388__ph1629752113110">2</span>}人等待，请在现场等候叫号。</p>
          </td>
          <td class="cellrowborder" valign="top" width="20.14%" headers="mcps1.3.5.2.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217388__p15191726112015">${1}${2}：其他号码</p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row17602105212199"><td class="cellrowborder" valign="top" width="15%" headers="mcps1.3.5.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p4602165210196">售后咨询</p>
        </td>
          <td class="cellrowborder" valign="top" width="64.86%" headers="mcps1.3.5.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p1961914200225">已安排售后人员和您联系，请您保持电话畅通耐心等待，谢谢！</p>
          </td>
          <td class="cellrowborder" valign="top" width="20.14%" headers="mcps1.3.5.2.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217388__p1369935415116"><span id="ZH-CN_TOPIC_0186217388__ph19297203710534">-</span></p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row2603195213196"><td class="cellrowborder" valign="top" width="15%" headers="mcps1.3.5.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p166031452101911">客服评价</p>
        </td>
          <td class="cellrowborder" valign="top" width="64.86%" headers="mcps1.3.5.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p20621152012218">您好！请用数字回复对服务人员的评价：1满意；2一般；3差</p>
          </td>
          <td class="cellrowborder" valign="top" width="20.14%" headers="mcps1.3.5.2.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217388__p146991654711"><span id="ZH-CN_TOPIC_0186217388__ph1526884117534">-</span></p>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217388__row1960305221916"><td class="cellrowborder" valign="top" width="15%" headers="mcps1.3.5.2.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217388__p136034522192">兑换码</p>
        </td>
          <td class="cellrowborder" valign="top" width="64.86%" headers="mcps1.3.5.2.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217388__p106221220162210">您的兑换申请已经通过，兑换码为${<span id="ZH-CN_TOPIC_0186217388__ph1699214017114">1</span>}，请勿泄漏。</p>
          </td>
          <td class="cellrowborder" valign="top" width="20.14%" headers="mcps1.3.5.2.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217388__p10346139182016">${1}：其他号码</p>
          </td>
        </tr>
        </tbody>
      </table>
      </div>
    </div>
  </div>
  <div>
  </div>
  </div>
</template>

<script>
  export default {
    name: "TempExp"
  }
</script>

<style scoped>

</style>
