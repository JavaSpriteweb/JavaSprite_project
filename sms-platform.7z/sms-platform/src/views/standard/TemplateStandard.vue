<template>
  <div class="help-content" bi_parent_name="content">

    <a name="ZH-CN_TOPIC_0186217387" style="margin: 0px;"></a><a name="ZH-CN_TOPIC_0186217387" style="margin: 0px;"></a>

<!--    <h1 class="topictitle1"></h1>-->
    <div id="body8662426"><p id="ZH-CN_TOPIC_0186217387__p1286828509"></p>
      <p id="ZH-CN_TOPIC_0186217387__p9966155351017">短信内容需申请成模板后发送，短信模板=固定文本+变量，或短信模板=固定文本。变量为每次发送短信时的可变内容。</p>
      <p id="ZH-CN_TOPIC_0186217387__p16225613114710">请根据企业业务需要，提前申请多个短信模板，避免因审核时长（仅支持工作日审核）造成业务损失。</p>
      <p id="ZH-CN_TOPIC_0186217387__p91321288461">请阅读以下规范，确保您的短信模板符合<span id="ZH-CN_TOPIC_0186217387__ph17333103632620">内容</span>规范<span id="ZH-CN_TOPIC_0186217387__ph580612406265">、变量规范</span>和各模板类型特定规范。</p>
      <div class="section" id="ZH-CN_TOPIC_0186217387__section98443337558"><h4 class="sectiontitle" id="section0"><span id="ZH-CN_TOPIC_0186217387__ph967303622518">内容规范</span></h4>
        <div class="tablenoborder"><table cellpadding="4" cellspacing="0" summary="" id="ZH-CN_TOPIC_0186217387__table1144616713444" frame="border" border="1" rules="all"><tbody><tr id="ZH-CN_TOPIC_0186217387__row8448147144417"><th class="firstcol" valign="top" width="15.43%" id="mcps1.3.5.2.1.3.1.1"><p id="ZH-CN_TOPIC_0186217387__p8448117194420"><strong id="ZH-CN_TOPIC_0186217387__b75131312154812">模板格式规范</strong></p>
        </th>
          <td class="cellrowborder" valign="top" width="84.57000000000001%" headers="mcps1.3.5.2.1.3.1.1 "><p id="ZH-CN_TOPIC_0186217387__p1026173319291">500字以内。</p>
            <ul id="ZH-CN_TOPIC_0186217387__ul339173319295"><li id="ZH-CN_TOPIC_0186217387__li12391335294">不支持【】，可能会与签名混淆，导致发送失败。</li><li id="ZH-CN_TOPIC_0186217387__li1539163311297">不支持如￥、★、^_^、&amp;、√、※等特殊符号，可能会导致短信出现乱码。</li></ul>
          </td>
        </tr>
        <tr id="ZH-CN_TOPIC_0186217387__row13448579449"><th class="firstcol" valign="top" width="15.43%" id="mcps1.3.5.2.1.3.2.1"><p id="ZH-CN_TOPIC_0186217387__p14448677449"><strong id="ZH-CN_TOPIC_0186217387__b1618881574819">内容规范</strong></p>
        </th>
          <td class="cellrowborder" valign="top" width="84.57000000000001%" headers="mcps1.3.5.2.1.3.2.1 "><p id="ZH-CN_TOPIC_0186217387__p444810719447">模板必须体现实际公司业务，除变量以外的文本内容必须可判读短信含义和使用场景，请尽可能多的使用固定文字描述。</p>
            <ul id="ZH-CN_TOPIC_0186217387__ul14201140992"><li id="ZH-CN_TOPIC_0186217387__li273311941018">不允许发送未经许可的邀请，主要指邀请注册、邀请成为会员等行为。</li><li id="ZH-CN_TOPIC_0186217387__li1323732213154">房地产、教育、游戏行业暂只支持验证码短信。</li><li id="ZH-CN_TOPIC_0186217387__li6382132634014">禁止发送涉及以下信息的短信：股票、移民、面试招聘、彩票、返利、贷款、催款、投资理财、中奖、一元夺宝、一元秒杀、A货、医疗、整形、美容、会所、酒吧、足浴、带有威胁性质、皮草、助考、商标注册、加群、加QQ或者加微信、贩卖个人信息、<span id="ZH-CN_TOPIC_0186217387__ph01872483917">APP下载链接、</span><span id="ZH-CN_TOPIC_0186217387__ph5439114332117">申请好评返现</span><span id="ZH-CN_TOPIC_0186217387__ph1054714454219">、</span>宣传短信通道、用户拉新、用户召回、运营商相关（营业厅，移动，联通，电信，大王卡，短信群发等）及其他违反法律法规的内容。</li></ul>
          </td>
        </tr>
        </tbody>
        </table>
        </div>
        <div class="note" id="ZH-CN_TOPIC_0186217387__note61861635135512"><img src="//res-img3.huaweicloud.com/content/dam/cloudbu-site/archive/china/zh-cn/support/resource/framework/v3/images/support-doc-new-note.svg">说明：<span class="notetitle"> </span><div class="notebody"><ul id="ZH-CN_TOPIC_0186217387__ul149571335135513"><li id="ZH-CN_TOPIC_0186217387__li169571435175515">模板内容不需要填写短信签名，发送短信时系统会自动添加。</li><li id="ZH-CN_TOPIC_0186217387__li2958135155517">群发助手使用的模板不支持变量。</li></ul>
        </div></div>
      </div>
      <div class="section" id="ZH-CN_TOPIC_0186217387__section844681252917"><h4 class="sectiontitle" id="section1"><strong id="ZH-CN_TOPIC_0186217387__b11215441519">变量规范</strong></h4><p id="ZH-CN_TOPIC_0186217387__p124421340134113">每个模板中最多包含20个变量，不支持连续变量。（变量间包含文字则为不连续变量）</p>
        <p id="ZH-CN_TOPIC_0186217387__p38961128131819"><strong id="ZH-CN_TOPIC_0186217387__b9934173974214">注</strong><span id="ZH-CN_TOPIC_0186217387__ph656073094118">：如果需要扩展变量长度，请在申请短信模板时，详细备注说明业务使用场景。</span></p>
        <p id="ZH-CN_TOPIC_0186217387__p38761512010">模板内容中的变量格式规范如下：</p>
        <div class="note" id="ZH-CN_TOPIC_0186217387__note179105611510"><img src="//res-img3.huaweicloud.com/content/dam/cloudbu-site/archive/china/zh-cn/support/resource/framework/v3/images/support-doc-new-note.svg">说明：<span class="notetitle"> </span><div class="notebody"><p id="ZH-CN_TOPIC_0186217387__p12955661512">两种变量格式等效，系统按${}解析识别变量，大括号中的序号标识/类型标识只是方便查阅，并无实际作用。需要为各变量设置变量属性，才能让相应变量规范生效。</p>
        </div></div>

        <div class="tablenoborder"><table cellpadding="4" cellspacing="0" summary="" id="ZH-CN_TOPIC_0186217387__table457216241641" frame="border" border="1" rules="all"><thead align="left"><tr id="ZH-CN_TOPIC_0186217387__row16573024749"><th align="left" class="cellrowborder" valign="top" width="20%" id="mcps1.3.6.6.1.4.1.1"><p id="ZH-CN_TOPIC_0186217387__p125742241246"><span id="ZH-CN_TOPIC_0186217387__ph118451951102417">变量格式</span></p>
        </th>
          <th align="left" class="cellrowborder" valign="top" width="20%" id="mcps1.3.6.6.1.4.1.2"><p id="ZH-CN_TOPIC_0186217387__p02191050191612">填写示例</p>
          </th>
          <th align="left" class="cellrowborder" valign="top" width="60%" id="mcps1.3.6.6.1.4.1.3"><p id="ZH-CN_TOPIC_0186217387__p357418244418">说明</p>
          </th>
        </tr>
        </thead>
          <tbody><tr id="ZH-CN_TOPIC_0186217387__row165749241949"><td class="cellrowborder" valign="top" width="20%" headers="mcps1.3.6.6.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217387__p757452414418">按序号标识</p>
          </td>
            <td class="cellrowborder" valign="top" width="20%" headers="mcps1.3.6.6.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217387__p14219175020161">${1}、${2}、...、${20}</p>
            </td>
            <td class="cellrowborder" valign="top" width="60%" headers="mcps1.3.6.6.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217387__p557517241147">中间数字应代表变量在模板内容中的位置顺序。即${1}表示模板内容中的第一个变量，${2}表示模板内容中的第二个变量，以此类推。</p>
              <div class="note" id="ZH-CN_TOPIC_0186217387__note192421630105416"><span class="notetitle"> 说明： </span><div class="notebody"><p id="ZH-CN_TOPIC_0186217387__p524233011546"><span id="ZH-CN_TOPIC_0186217387__ph1072315472152">特殊内容（<span id="ZH-CN_TOPIC_0186217387__ph19616191071611">如网址、手机号等</span>）</span>不允许设置局部变量，如www.${1}.cn、186${2}1234等。</p>
              </div></div>
            </td>
          </tr>
          <tr id="ZH-CN_TOPIC_0186217387__row16224179193410"><td class="cellrowborder" valign="top" width="20%" headers="mcps1.3.6.6.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217387__p19225596344">按类型标识</p>
          </td>
            <td class="cellrowborder" valign="top" width="20%" headers="mcps1.3.6.6.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217387__p122267912342">${PHONE}、${CHARDIGIT}、${DATETIME}、${MONEY}、${TEXT}</p>
            </td>
            <td class="cellrowborder" valign="top" width="60%" headers="mcps1.3.6.6.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217387__p162261395342">中间字符表示变量类型，各变量有默认长度限制，不支持自定义设置。</p>
            </td>
          </tr>
          </tbody>
        </table>
        </div>
        <p id="ZH-CN_TOPIC_0186217387__p17577105945216">当模板内容中设置了变量时，必须指定变量属性。变量属性的设置规范如下，<span id="ZH-CN_TOPIC_0186217387__ph1392992918210">小数点、字母、汉字、空格以及其他符号按1个变量长度计算。</span></p>

        <div class="tablenoborder"><table cellpadding="4" cellspacing="0" summary="" id="ZH-CN_TOPIC_0186217387__table1275114475582" frame="border" border="1" rules="all"><thead align="left"><tr id="ZH-CN_TOPIC_0186217387__row11751947125819"><th align="left" class="cellrowborder" valign="top" width="22.57%" id="mcps1.3.6.8.1.4.1.1"><p id="ZH-CN_TOPIC_0186217387__p975114720587">变量属性</p>
        </th>
          <th align="left" class="cellrowborder" valign="top" width="17.549999999999997%" id="mcps1.3.6.8.1.4.1.2"><p id="ZH-CN_TOPIC_0186217387__p3751747105817">变量类型</p>
          </th>
          <th align="left" class="cellrowborder" valign="top" width="59.88%" id="mcps1.3.6.8.1.4.1.3"><p id="ZH-CN_TOPIC_0186217387__p187521247205816">规范</p>
          </th>
        </tr>
        </thead>
          <tbody><tr id="ZH-CN_TOPIC_0186217387__row10752104714586"><td class="cellrowborder" valign="top" width="22.57%" headers="mcps1.3.6.8.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217387__p8499145135812">电话号码</p>
          </td>
            <td class="cellrowborder" valign="top" width="17.549999999999997%" headers="mcps1.3.6.8.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217387__p1299477141117">PHONE</p>
            </td>
            <td class="cellrowborder" valign="top" width="59.88%" headers="mcps1.3.6.8.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217387__p1294541211219">长度限制：1-15个字符。</p>
              <p id="ZH-CN_TOPIC_0186217387__p594518123218">可以传入手机号、座机号、95或400、800电话等。</p>
            </td>
          </tr>
          <tr id="ZH-CN_TOPIC_0186217387__row698452213597"><td class="cellrowborder" valign="top" width="22.57%" headers="mcps1.3.6.8.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217387__p16985162213598">其他号码<span id="ZH-CN_TOPIC_0186217387__ph16973112393615">（如验证码、订单号、密码等）</span></p>
          </td>
            <td class="cellrowborder" valign="top" width="17.549999999999997%" headers="mcps1.3.6.8.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217387__p9985182255920">CHARDIGIT</p>
            </td>
            <td class="cellrowborder" valign="top" width="59.88%" headers="mcps1.3.6.8.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217387__p29459124213">长度限制：1-20个字符。</p>
              <p id="ZH-CN_TOPIC_0186217387__p7431104913302">主要用途为<span id="ZH-CN_TOPIC_0186217387__ph553643173618">验证码、</span>订单号，密码、随机秘钥等。</p>
              <ul id="ZH-CN_TOPIC_0186217387__ul8936452183014"><li id="ZH-CN_TOPIC_0186217387__li7337201314311">不允许出现手机号、QQ号、微信号、URL等联系方式。</li><li id="ZH-CN_TOPIC_0186217387__li1793619526301">仅支持大小写字母和数字组合。</li></ul>
            </td>
          </tr>
          <tr id="ZH-CN_TOPIC_0186217387__row20133526105910"><td class="cellrowborder" valign="top" width="22.57%" headers="mcps1.3.6.8.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217387__p1113342685911">时间</p>
          </td>
            <td class="cellrowborder" valign="top" width="17.549999999999997%" headers="mcps1.3.6.8.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217387__p41334260598">DATETIME</p>
            </td>
            <td class="cellrowborder" valign="top" width="59.88%" headers="mcps1.3.6.8.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217387__p89461312620">长度限制：1-20个字符。</p>
              <p id="ZH-CN_TOPIC_0186217387__p37962541115">需要符合时间的表达方式，格式示例如下：</p>
              <ul id="ZH-CN_TOPIC_0186217387__ul716812121334"><li id="ZH-CN_TOPIC_0186217387__li1121412915585">日期：yyyyMMdd、yyyy-MM-dd、yyyy/MM/dd、yyyy年mm月dd日。</li><li id="ZH-CN_TOPIC_0186217387__li13809181395816">时间：HH:mm:ss、HH:mm、HH点mm分、HH点mm。</li></ul>
              <p id="ZH-CN_TOPIC_0186217387__p1960912301506">如果需要同时指定日期和时间，请在模板中填充两个变量，一个变量传入日期，另一个变量传入时间。</p>
              <ul id="ZH-CN_TOPIC_0186217387__ul1577312199810"><li id="ZH-CN_TOPIC_0186217387__li68173251386">短信内容示例：<p id="ZH-CN_TOPIC_0186217387__p1897710308813"><a name="ZH-CN_TOPIC_0186217387__li68173251386" style="margin: 0px;"></a><a name="li68173251386" style="margin: 0px;"></a>温馨提醒：2020-01-10 19:00-21:00的会议即将开始，请您准时参加。</p>
              </li><li id="ZH-CN_TOPIC_0186217387__li17773101913817">模板示例：<p id="ZH-CN_TOPIC_0186217387__p9821358871"><a name="ZH-CN_TOPIC_0186217387__li17773101913817" style="margin: 0px;"></a><a name="li17773101913817" style="margin: 0px;"></a>温馨提醒：${1} ${2}-${3}的会议即将开始，请您准时参加。</p>
              </li></ul>
            </td>
          </tr>
          <tr id="ZH-CN_TOPIC_0186217387__row11276203017595"><td class="cellrowborder" valign="top" width="22.57%" headers="mcps1.3.6.8.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217387__p12762030185914">金额</p>
          </td>
            <td class="cellrowborder" valign="top" width="17.549999999999997%" headers="mcps1.3.6.8.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217387__p827643019591">MONEY</p>
            </td>
            <td class="cellrowborder" valign="top" width="59.88%" headers="mcps1.3.6.8.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217387__p1394612121220">长度限制：1-20个字符。</p>
              <ul id="ZH-CN_TOPIC_0186217387__ul84291536185419"><li id="ZH-CN_TOPIC_0186217387__li14429936105417">仅支持传入能够正常表达金额的数字、小数点或中文，例如壹、贰、叁、肆等。</li><li id="ZH-CN_TOPIC_0186217387__li18429636105410">支持传入IP地址，例如：10.1.1.10。</li><li id="ZH-CN_TOPIC_0186217387__li6430113614549">变量属性为“其他”时，不允许在传入值中携带“.”，即不支持传入IP地址。</li></ul>
              <div class="note" id="ZH-CN_TOPIC_0186217387__note41203310548"><span class="notetitle"> 说明： </span><div class="notebody"><p id="ZH-CN_TOPIC_0186217387__p1212083145420"><strong id="ZH-CN_TOPIC_0186217387__b1380631316423">￥$等货币符号需要放在模板中，不支持变量传入。</strong></p>
              </div></div>
            </td>
          </tr>
          <tr id="ZH-CN_TOPIC_0186217387__row83202033185910"><td class="cellrowborder" valign="top" width="22.57%" headers="mcps1.3.6.8.1.4.1.1 "><p id="ZH-CN_TOPIC_0186217387__p132011335599">其他（如名称、账号、地址等）</p>
          </td>
            <td class="cellrowborder" valign="top" width="17.549999999999997%" headers="mcps1.3.6.8.1.4.1.2 "><p id="ZH-CN_TOPIC_0186217387__p113201433195914">TEXT</p>
            </td>
            <td class="cellrowborder" valign="top" width="59.88%" headers="mcps1.3.6.8.1.4.1.3 "><p id="ZH-CN_TOPIC_0186217387__p1394611218214">长度限制：1-20个字符。</p>
              <ul id="ZH-CN_TOPIC_0186217387__ul1610185313457"><li id="ZH-CN_TOPIC_0186217387__li1366620569459">可以设置为公司/产品/地址/姓名/内容/账号/会员名等。</li><li id="ZH-CN_TOPIC_0186217387__li382215198486">不允许出现QQ号/微信号（公众号）/手机号/网址/座机号等联系方式。如果确有需要，请将联系方式放入模板中。</li><li id="ZH-CN_TOPIC_0186217387__li17102165314515">不允许在传入值中携带“.”、“。”、“{”或“}”。否则，可能导致模板变量解析异常。</li></ul>
            </td>
          </tr>
          </tbody>
        </table>
        </div>
      </div>
      <div class="section" id="ZH-CN_TOPIC_0186217387__section1989218490559"><h4 class="sectiontitle" id="section2">模板类型特定规范</h4><p id="ZH-CN_TOPIC_0186217387__p193546454233">除<span id="ZH-CN_TOPIC_0186217387__ph1286162604413">以上</span>规范外，短信的每种模板类型还有以下特定规范：</p>

        <div class="tablenoborder"><table cellpadding="4" cellspacing="0" summary="" id="ZH-CN_TOPIC_0186217387__table3847858175214" frame="border" border="1" rules="all"><thead align="left"><tr id="ZH-CN_TOPIC_0186217387__row138480584523"><th align="left" class="cellrowborder" valign="top" width="9.76%" id="mcps1.3.7.3.1.5.1.1"><p id="ZH-CN_TOPIC_0186217387__p684818583527">类别</p>
        </th>
          <th align="left" class="cellrowborder" valign="top" width="31.230000000000004%" id="mcps1.3.7.3.1.5.1.2"><p id="ZH-CN_TOPIC_0186217387__p8848165810524">变量规范</p>
          </th>
          <th align="left" class="cellrowborder" valign="top" width="44.29%" id="mcps1.3.7.3.1.5.1.3"><p id="ZH-CN_TOPIC_0186217387__p1184865885212">内容规范</p>
          </th>
          <th align="left" class="cellrowborder" valign="top" width="14.719999999999999%" id="mcps1.3.7.3.1.5.1.4"><p id="ZH-CN_TOPIC_0186217387__p10977192094819"><span id="ZH-CN_TOPIC_0186217387__ph12715832154817">模板示例</span></p>
          </th>
        </tr>
        </thead>
          <tbody><tr id="ZH-CN_TOPIC_0186217387__row15848258185213"><td class="cellrowborder" valign="top" width="9.76%" headers="mcps1.3.7.3.1.5.1.1 "><p id="ZH-CN_TOPIC_0186217387__p1784995865210"><strong id="ZH-CN_TOPIC_0186217387__b1811301874714">验证码短信</strong></p>
          </td>
            <td class="cellrowborder" valign="top" width="31.230000000000004%" headers="mcps1.3.7.3.1.5.1.2 "><ul id="ZH-CN_TOPIC_0186217387__ul15594143914168"><li id="ZH-CN_TOPIC_0186217387__li1759410397163">仅支持一个变量，用于填写数字验证码。</li><li id="ZH-CN_TOPIC_0186217387__li176091543121619">验证码变量的“最大长度”只能为6位及以下。</li></ul>
            </td>
            <td class="cellrowborder" valign="top" width="44.29%" headers="mcps1.3.7.3.1.5.1.3 "><p id="ZH-CN_TOPIC_0186217387__p14326171961714">国内短信必须含有验证码，注册码，校验码，动态码这4个词其中之一。</p>
            </td>
            <td class="cellrowborder" valign="top" width="14.719999999999999%" headers="mcps1.3.7.3.1.5.1.4 "><p id="ZH-CN_TOPIC_0186217387__p1597819203487"><span id="ZH-CN_TOPIC_0186217387__ph866761074913">请参考模板示例</span></p>
            </td>
          </tr>
          <tr id="ZH-CN_TOPIC_0186217387__row58494580529"><td class="cellrowborder" valign="top" width="9.76%" headers="mcps1.3.7.3.1.5.1.1 "><p id="ZH-CN_TOPIC_0186217387__p15849195845211"><strong id="ZH-CN_TOPIC_0186217387__b18755172044713">通知短信</strong></p>
          </td>
            <td class="cellrowborder" valign="top" width="31.230000000000004%" headers="mcps1.3.7.3.1.5.1.2 "><p id="ZH-CN_TOPIC_0186217387__p102791876224">链接和联系方式不支持使用变量发送，请填写在模板的固定文本中。</p>
            </td>
            <td class="cellrowborder" valign="top" width="44.29%" headers="mcps1.3.7.3.1.5.1.3 "><ul id="ZH-CN_TOPIC_0186217387__ul950117139487"><li id="ZH-CN_TOPIC_0186217387__li126851115144810">不支持带营销推广的内容。</li><li id="ZH-CN_TOPIC_0186217387__li715942152313">链接只能为固定网址，不能是跳转链接或短网址。</li></ul>
            </td>
            <td class="cellrowborder" valign="top" width="14.719999999999999%" headers="mcps1.3.7.3.1.5.1.4 "><p id="ZH-CN_TOPIC_0186217387__p597812019480"><span id="ZH-CN_TOPIC_0186217387__ph185561267506">请参考模板示例</span></p>
            </td>
          </tr>
          <tr id="ZH-CN_TOPIC_0186217387__row4850125805217"><td class="cellrowborder" valign="top" width="9.76%" headers="mcps1.3.7.3.1.5.1.1 "><p id="ZH-CN_TOPIC_0186217387__p1085055855211"><strong id="ZH-CN_TOPIC_0186217387__b131371523104720">推广短信</strong></p>
          </td>
            <td class="cellrowborder" valign="top" width="31.230000000000004%" headers="mcps1.3.7.3.1.5.1.2 "><p id="ZH-CN_TOPIC_0186217387__p18360131495717">不支持变量，模板只能为纯固定文本。</p>
            </td>
            <td class="cellrowborder" valign="top" width="44.29%" headers="mcps1.3.7.3.1.5.1.3 "><ul id="ZH-CN_TOPIC_0186217387__ul818964945611"><li id="ZH-CN_TOPIC_0186217387__li18776142364417">推广短信除公共规范外，另禁止发送涉及以下信息的短信：培训、招商加盟类、团购会、装修（含建材，家私）、烟、酒、茶、捐款献血、迷信色彩、人工或软件刷单、做任务、虚拟货币、人民币收藏、钱币买卖、沙发翻新、工商代办、代开发票、买卖黑车、非法钓鱼、会展、网站、优惠券类推广、卡类、保险、税票、APP推广、办证、回收、医疗保健、POS机相关、信用卡、交友、猎头、直播及其他违反法律法规的内容。</li><li id="ZH-CN_TOPIC_0186217387__li693142118134">只支持发送给有订购关系的会员用户，模板必须体现是发送给会员。</li><li id="ZH-CN_TOPIC_0186217387__li8987205711411">必须添加退订方式，支持“TD、T、N”进行短信退订回复。</li><li id="ZH-CN_TOPIC_0186217387__li922916199246">联系方式仅支持固话或400电话，不支持手机号。</li><li id="ZH-CN_TOPIC_0186217387__li1574012232304">不支持发送给国际/港澳台地区。</li><li id="ZH-CN_TOPIC_0186217387__li73487473563">不支持携带<span id="ZH-CN_TOPIC_0186217387__ph582312528592">变量</span>链接<span id="ZH-CN_TOPIC_0186217387__ph32868317017">，</span><span id="ZH-CN_TOPIC_0186217387__ph3272432907">请将链接作为固定文本；</span><span id="ZH-CN_TOPIC_0186217387__ph588933215248">链接只能为固定网址，不能是跳转链接或短网址</span>。</li></ul>
            </td>
            <td class="cellrowborder" valign="top" width="14.719999999999999%" headers="mcps1.3.7.3.1.5.1.4 "><p id="ZH-CN_TOPIC_0186217387__p9978102017488"><span id="ZH-CN_TOPIC_0186217387__ph162337310513">-</span></p>
            </td>
          </tr>
          </tbody>
        </table>
        </div>
        <div class="caution" id="ZH-CN_TOPIC_0186217387__note66244075216"><span class="cautiontitle"><img src="//res-img3.huaweicloud.com/content/dam/cloudbu-site/archive/china/zh-cn/support/resource/framework/v3/images/support-doc-new-caution.svg">注意： </span><div class="cautionbody"><ul id="ZH-CN_TOPIC_0186217387__ul127217820534"><li id="ZH-CN_TOPIC_0186217387__li6729835311">模板规范可能随运营商规则变化实时调整，最终以模板审核结果为准。</li><li id="ZH-CN_TOPIC_0186217387__li27212810533">如遇到违反规范并造成恶劣影响的，将严肃处理并进行封号！请严格遵守规范要求，加强自身业务安全，健康发送短信。</li></ul>
        </div></div>
      </div>
    </div>

  </div>
</template>

<script>
  export default {
    name: "TemplateStandard"
  }
</script>

<style scoped>

</style>
