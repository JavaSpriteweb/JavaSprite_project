<template>
  <div :class="className" :style="{ height: height, width: width }" />
</template>

<script>
import echarts from "echarts";
require("echarts/theme/macarons"); // echarts theme
import resize from "./mixins/resize";

const animationDuration = 1500;

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: "chart",
    },
    width: {
      type: String,
      default: "100%",
    },
    height: {
      type: String,
      default: "350px",
    },
    chartData: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  data() {
    return {
      chart: null,
    };
  },
  computed: {
    xAxisData() {
      return this.chartData.reduce((acc, cur) => acc.concat(cur.startTime), []);
    },
    series() {
      return this.chartData.reduce(
        (acc, cur) => {
          const { total, success, fail, sending } = cur;
          acc[0].data.push(total);
          acc[1].data.push(success);
          acc[2].data.push(fail);
          acc[3].data.push(sending);
          return acc;
        },
        [
          {
            name: "发送总数（条）",
            type: "bar",
            data: [],
            animationDuration,
          },
          {
            name: "发送成功数（条）",
            type: "bar",
            data: [],
            animationDuration,
          },
          {
            name: "发送失败数（条）",
            type: "bar",
            data: [],
            animationDuration,
          },
          {
            name: "发送中（条）",
            type: "bar",
            data: [],
            animationDuration,
          },
        ]
      );
    },
  },
  watch: {
    chartData() {
      this.$nextTick(() => {
        this.initChart();
      });
    },
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart();
    });
  },
  beforeDestroy() {
    if (!this.chart) {
      return;
    }
    this.chart.dispose();
    this.chart = null;
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, "macarons");
      this.chart.setOption({
        tooltip: {
          trigger: "axis",
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: "shadow", // 默认为直线，可选为：'line' | 'shadow'
          },
        },
        toolbox: {
          show: true,
          right: '2%',
          feature: {
            // dataView: {
            //   readOnly: true
            // },
            // magicType: {
            //   type: ["line", "bar"]
            // },
            saveAsImage: {}
          }
        },
        legend: {
          top: 10,
          left: "40%",
        },
        grid: {
          top: 35,
          left: "2%",
          right: "2%",
          bottom: "3%",
          containLabel: true,
        },
        xAxis: [
          {
            type: "category",
            data: this.xAxisData,
            axisTick: {
              alignWithLabel: true,
            },
          },
        ],
        yAxis: [
          {
            type: "value",
            axisTick: {
              show: false,
            },
          },
        ],
        series: this.series,
      });
    },
  },
};
</script>
