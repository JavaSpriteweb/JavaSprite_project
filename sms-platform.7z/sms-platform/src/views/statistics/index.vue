<template>
  <div class="app-container" id="appContainer">
    <div class="header" ref="header">
      <a-form-model ref="form" :model="searchForm" layout="inline" @submit.prevent="getSummaryData">
        <a-form-model-item label="地区：">
          <a-radio-group v-model="searchForm.isDomestic" button-style="solid" @change="getSummaryData">
            <a-radio-button :value="1">
              国内短信
            </a-radio-button>
            <a-radio-button :value="0">
              国际/港澳台短信
            </a-radio-button>
          </a-radio-group>
        </a-form-model-item>

        <a-form-model-item v-if="searchForm.isDomestic === 1" label="短信类型：">
          <a-select placeholder="请选择短信类型" allowClear v-model="searchForm.smsType" @change="getSingList">
            <a-select-option v-for="ele in smsTypeOptions" :key="ele.value">
              {{ ele.label }}
            </a-select-option>
          </a-select>
        </a-form-model-item>

        <a-form-model-item v-if="searchForm.isDomestic === 1" label="签名名称：">
          <a-select allowClear show-search placeholder="请选择签名名称" v-model="searchForm.smsSignName">
            <a-select-option v-for="(signItem, index) in signList" :key="index" :value="signItem">
              {{ signItem }}
            </a-select-option>
          </a-select>
        </a-form-model-item>

        <a-form-model-item label="起止日期:">
          <a-range-picker
            format="YYYY-MM-DD"
            :placeholder="['开始', '截至']"
            :ranges="ranges"
            v-model="searchForm.dateTimeRange"
            @change="hanleDateRangeChange"
          />
        </a-form-model-item>

        <a-form-model-item>
          <a-button type="primary" html-type="submit" style="margin-right: 15px;">查询</a-button>
          <a-button style="margin-right: 15px;" @click="handleReset">重置</a-button>
          <a-button @click="capture">导出</a-button>
        </a-form-model-item>
      </a-form-model>
    </div>
    <div id="captureContent" class="content">
      <a-row>
        <a-col :span="24">
          <bar-chart v-if="detailData.length" :width="chartWidth" :chartData="detailData" />
        </a-col>
        <a-col :span="24">
          <a-table
            row-key="total"
            class="summaryTable"
            :columns="summaryColumns"
            :loading="loading"
            :data-source="summaryData"
            :pagination="false"
            :defaultExpandAllRows="true"
            :expandedRowKeys="expandKeys"
            @expand="handleExpandRowEvent"
          >
            <a-table
              size="small"
              bordered
              slot="expandedRowRender"
              row-key="startTime"
              :columns="detailColumns"
              :data-source="detailData"
              :pagination="false"
            >
              <template slot="errorDetail" slot-scope="text, record">
                <a-button :disabled="!record.fail" type="link" size="small" @click="handleClickFailInfo(record)"
                  >查看详情</a-button
                >
              </template>
            </a-table>
          </a-table>
        </a-col>
      </a-row>
    </div>
    <a-modal width="75%" :visible="isShowFailModal" title="发送失败详情" :destroyOnClose="true" :closable="false">
      <template slot="footer">
        <a-button key="back" @click="handleCancel">
          返回
        </a-button>
      </template>
      <a-table :scroll="{ x: 'max-content' }" row-key="smsId" :columns="failColumns" :data-source="failData" />
    </a-modal>
  </div>
</template>

<script>
// import { saveAs } from 'file-saver'
import moment from 'moment'
import BarChart from './components/BarChart'
// import html2canvas from 'html2canvas'
import { mapState } from 'vuex'
import { getSummaryData, getAllSignNames, getFailBusinessInfo } from '@/services/statistics'
import { TYPE_OPTIONS } from '@/config/default/sms.config'
export default {
  name: 'index',
  components: { BarChart },
  data() {
    return {
      loading: false,
      isShowFailModal: false,
      searchForm: {
        isDomestic: 1,
        smsType: '',
        smsSignName: '',
        dateTimeRange: [moment({ hour: 0, minute: 0 }), moment({ hour: 0, minute: 0 })]
      },
      ranges: {
        昨天: [moment({ hour: 0, minute: 0 }).subtract(1, 'day'), moment({ hour: 0, minute: 0 }).subtract(1, 'day')],
        当月: [moment({ hour: 0, minute: 0 }).startOf('month'), moment({ hour: 0, minute: 0 }).endOf('month')],
        上月: [
          moment({ hour: 0, minute: 0 })
            .startOf('month')
            .subtract(1, 'month'),
          moment({ hour: 0, minute: 0 })
            .endOf('month')
            .subtract(1, 'month')
        ]
      },
      chartWidth: '',
      smsTypeOptions: TYPE_OPTIONS,
      expandKeys: [],
      signList: [],
      failData: [],
      detailData: [],
      summaryData: [],
      failColumns: [
        { title: '手机号码', align: 'center', dataIndex: 'receiveNumber' },
        { title: '短信签名', align: 'center', dataIndex: 'signName' },
        { title: '短信ID', align: 'center', dataIndex: 'smsId' },
        { title: '短信类型', align: 'center', dataIndex: 'smsType' },
        { title: '发送时间', align: 'center', dataIndex: 'sendTime' },
        { title: '接收时间', align: 'center', dataIndex: 'receiveTime' },
        { title: '发送结果', align: 'center', dataIndex: 'sendResult' },
        { title: '状态码', align: 'center', dataIndex: 'statusCode' }
      ],
      detailColumns: [
        { title: '发送时间', align: 'center', dataIndex: 'startTime' },
        { title: '发送总数（条）', align: 'center', dataIndex: 'total' },
        { title: '发送成功数（条）', align: 'center', dataIndex: 'success' },
        { title: '发送失败数（条）', align: 'center', dataIndex: 'fail' },
        { title: '发送中（条）', align: 'center', dataIndex: 'sending' },
        { title: '发送成功率(%)', align: 'center', dataIndex: 'successRate' },
        {
          title: '失败详情',
          width: 100,
          align: 'center',
          scopedSlots: { customRender: 'errorDetail' }
        }
      ],
      summaryColumns: [
        { title: '合计发送总数（条）', align: 'center', dataIndex: 'total' },
        {
          title: '合计发送成功数（条）',
          align: 'center',
          dataIndex: 'success'
        },
        { title: '合计发送失败数（条）', align: 'center', dataIndex: 'fail' },
        { title: '合计发送中数（条）', align: 'center', dataIndex: 'sending' },
        { title: '合计发送成功率(%)', align: 'center', dataIndex: 'successRate' }
      ]
    }
  },
  computed: {
    ...mapState('account', ['user'])
  },
  methods: {
    getSummaryData() {
      this.loading = true
      this.summaryData = []
      this.expandKeys = []
      this.detailData = []
      const { isDomestic, smsType, smsSignName, dateTimeRange } = this.searchForm
      // const startTime = moment(dateTimeRange[0]).format('YYYY-MM-DD HH:mm:ss')
      // const endTime = moment(dateTimeRange[1]).format('YYYY-MM-DD HH:mm:ss')
      const startTime = moment(dateTimeRange[0]).format('YYYYMMDDHHmmss')
      const endTime = moment(dateTimeRange[1]).format('YYYYMMDDHHmmss')
      const params = {
        accountId: this.user.accountId,
        isDomestic,
        smsType,
        smsSignName,
        startTime,
        endTime
      }
      getSummaryData(params).then(({ errorCode, errorMsg, result = {} }) => {
        if (+errorCode === 0) {
          if (result.total) {
            this.summaryData = [ result ]
            this.expandKeys = [ result.total ]
          }
          const { sendDetails = [] } = result
          this.detailData = sendDetails.map(item => {
            const { startTime, endTime } = item;
            if (startTime.includes(':')) {
              item.startTime =`${startTime}-${endTime}`
            }
            return item
          })
        } else {
          this.$message.error(errorMsg)
        }
      }).finally(() => {
        this.loading = false 
      })
    },
    handleReset() {
      // this.$refs['form'].resetFields()
      this.searchForm = {
        isDomestic: 1,
        smsType: '',
        smsSignName: '',
        dateTimeRange: [moment({ hour: 0, minute: 0 }), moment({ hour: 0, minute: 0 })]
      }
      this.getSummaryData()
    },
    handleClickFailInfo(record) {
      const { completeEndTime: endTime, completeStartTime: startTime } = record
      const { isDomestic, smsType, smsSignName } = this.searchForm
      const params = { accountId: this.user.accountId, isDomestic, smsType, smsSignName, startTime, endTime }
      getFailBusinessInfo(params).then(({ errorCode, errorMsg, result }) => {
        if (+errorCode === 0) {
          const { failDetails = [] } = result || {}
          this.failData = failDetails.map((item) => {
            const typeOption = this.smsTypeOptions.find(typeItem => typeItem.value === item.smsType)
            item.smsType = typeOption ? typeOption.label : item.smsType
            item.sendTime = this.formatDateTime(item.sendTime)
            item.receiveTime = this.formatDateTime(item.receiveTime)
            return item
          })
          this.isShowFailModal = true
        } else {
          this.$message.error(errorMsg)
        }
      })
    },
    formatDateTime(dateStr) {
      if (!dateStr) {
        return ''
      }
      const year = dateStr.slice(0, 4)
      const month = dateStr.slice(4, 6)
      const day = dateStr.slice(6, 8)
      const hour = dateStr.slice(8, 10)
      const minute = dateStr.slice(10, 12)
      const second = dateStr.slice(12, 14)
      return `${year}-${month}-${day} ${hour}:${minute}:${second}`
    },
    handleExpandRowEvent(expanded, record) {
      const { total } = record
      this.expandKeys = expanded ? [ total ] : []
    },
    handleCancel() {
      this.isShowFailModal = false
    },
    hanleDateRangeChange(dates) {
      const [ start, end ] = dates
      const diff = moment(end).diff(moment(start), 'days')
      if (diff > 365) {
        this.$message.warning('连续时间范围不能超过一年')
        this.searchForm.dateTimeRange = [ start, moment(start).add(365, 'day') ]
      }
    },
    capture() {
      const last = this.detailColumns.pop()
      const table = document.querySelector('.summaryTable .ant-table-body table')
      table.setAttribute('id', 'exportTable')
      import('@/utils/Export2Excel').then(excel => {
        excel.export_table_to_excel('exportTable', '统计数据')
        table.removeAttribute('id')
        this.detailColumns.push(last)
      })
      // const rect = document.querySelector('#captureContent').getBoundingClientRect()
      // let scrollTop = document.documentElement.scrollTop || document.body.scrollTop // 获取滚动轴滚动的长度
      // console.log(document.querySelector('#captureContent').getBoundingClientRect()) //eslint-disable-line
      // html2canvas(document.querySelector('#captureContent'), {
      //   scale: 2,
      //   width: rect.width,
      //   height: rect.height,
      //   scrollY: -scrollTop // 页面存在滚动时，需要设置此属性，解决绘图偏移问题
      // }).then(function(canvas) {
      //   canvas.toBlob(function(blob) {
      //     saveAs(blob, '数据统计.png')
      //   })
      // })
    },
    getSingList(value) {
      this.searchForm.smsSignName = ''
      getAllSignNames({ accountId: this.user.accountId, smsType: value }).then(res => {
        const { errorCode, errorMsg, result = [] } = res
        if (+errorCode === 0) {
          this.signList = result
        } else {
          this.$message.error(errorMsg)
        }
      })
    }
  },
  mounted() {
    setTimeout(() => this.chartWidth = this.$refs['header'].offsetWidth + 'px')
    this.getSingList()
    this.getSummaryData()
  }
}
</script>

<style lang="less" scoped>
.app-container {
  background: #ffffff;
  width: 100%;
  height: 100%;
  .header {
    padding: 10px 20px;
    /deep/ .ant-select-selection {
      width: 160px;
    }
  }
  .app-table {
    span {
      i {
        margin-right: 5px;
      }
    }
  }
}
</style>
