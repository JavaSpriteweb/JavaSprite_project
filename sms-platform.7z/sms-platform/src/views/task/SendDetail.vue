<template>
  <div class="send-detail-container">
    <div class="header">
      <a-form layout="inline" @submit="handleSearch">
        <a-form-item label="短信签名">
          <a-select
            placeholder="请选择短信签名"
            show-search
            allowClear
            v-model="formData.signId"
            :filter-option="false"
            :getPopupContainer="(triggerNode) => triggerNode.parentNode || document.body"
            @search="handleSignSearch"
            @change="handleSignChange"
          >
            <a-spin v-if="signFetching" slot="notFoundContent" size="small" />
            <a-select-option v-for="item in signOptions" :key="item.signId" :title="item.signName">
              {{item.signName}}
            </a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="模板">
          <a-select
            placeholder="请选择模板"
            show-search
            allowClear
            v-model="formData.templateId"
            :filter-option="false"
            :getPopupContainer="(triggerNode) => triggerNode.parentNode || document.body"
            @search="handleTemplateSearch"
            @change="handleTemplateChange"
          >
            <a-spin v-if="templateFetching" slot="notFoundContent" size="small" />
            <a-select-option v-for="item in templateOptions" :key="item.templateId" :title="item.templateName">
              {{item.templateName}}
            </a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="手机号码">
          <a-input v-model="formData.phoneNumber" allowClear></a-input>
        </a-form-item>
        <a-form-item label="发送结果">
          <a-select
            placeholder="请选择发送结果"
            allowClear
            v-model="formData.sendResult"
            :getPopupContainer="(triggerNode) => triggerNode.parentNode || document.body"
            @change="getSmsList"
          >
            <a-select-option v-for="ele in sendResultOptions" :key="ele.value">
              {{ele.label}}
            </a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="发送时间">
          <a-range-picker
            :show-time="{ format: 'HH:mm' }"
            format="YYYY-MM-DD HH:mm"
            :disabled-date="disabledDate"
            v-model="sendDate"
            :placeholder="['开始时间', '结束时间']"
            :getCalendarContainer="(triggerNode) => triggerNode.parentNode || document.body"
            @calendarChange="calendarPriceRangeChange"
            @change="onDateChange"
            @ok="submitTime"
            @openChange="triggerDate"
          ></a-range-picker>
        </a-form-item>
        <a-form-item>
          <a @click="searchByTime('hour')" style="margin-right: 20px">最近一小时</a>
          <a @click="searchByTime('day')">最近24小时</a>
        </a-form-item>
        <a-form-item>
          <a-button v-if="hasPermission('smsDetailList')" type="primary" html-type="submit">查询</a-button>
          <a-button  @click="reset" style="margin-left: 10px">重置</a-button>
        </a-form-item>
      </a-form>
    </div>
    <div class="sms-table">
      <a-table
        :columns="tableColumns"
        :data-source="tableData"
        rowKey="smsId"
        :scroll="{x: 1400}"
        :loading="loading"
        :pagination="tablePagination"
      >
        <template slot="smsType" slot-scope="text">
          {{text | parseType}}
        </template>
        <template slot="sendResult" slot-scope="text">
          {{text | parseResult}}
        </template>
      </a-table>
    </div>
  </div>
</template>

<script>
import { getSignList, getTempListByAcct, getTempListBySign, getSendSmsList } from '@/services/task'
import AFormItem from "ant-design-vue/es/form/FormItem"
import { TEMPLATE_TYPE, SEND_RESULT_STATUS, SEND_RESULT_OPTIONS } from '@/config/default/sms.config'
import {mapState} from 'vuex'
import debounce from 'lodash/debounce'
import moment from 'moment'

export default {
  name: "SendDetail",
  components: {AFormItem},
  data() {
    this.tableColumns = [
      { title: '手机号码', dataIndex: 'phoneNumber', width: 160 },
      { title: '短信签名', dataIndex: 'signName' },
      { title: '短信ID', dataIndex: 'smsId' },
      { title: '短信类型', dataIndex: 'smsType', scopedSlots: { customRender: 'smsType' }},
      { title: '模板ID', dataIndex: 'templateId' },
      { title: '发送时间', dataIndex: 'sendTiming', width: 160 },
      { title: '接收时间', dataIndex: 'receiveTiming', width: 160 },
      { title: '发送结果', dataIndex: 'sendResult', scopedSlots: { customRender: 'sendResult' }},
      { title: '状态码', dataIndex: 'statusCode' },
      { title: '状态描述', dataIndex: 'statusDescription', width: 180, ellipsis: true }
    ]
    this.lastSignFetchId = 0
    this.lastTempFetchId = 0
    this.handleSignSearch = debounce(this.handleSignSearch, 800)
    this.handleTemplateSearch = debounce(this.handleTemplateSearch, 800)
    return {
      formData: {},
      signOptions: [{ signId: -1, signName: '未知签名'}],
      templateOptions: [],
      tableData: [],
      loading: false,
      total: 0,
      signFetching: false,
      templateFetching: false,
      templateValue: '',
      sendDate: [],
      selectPriceDate: '',
      checkedDate: []
    }
  },
  computed: {
    ...mapState('account', ['user']),
    accountId() {
      return this.$store.state.account.user.accountId
    },
    sendResultOptions() {
      return this.$store.state.account.user.accountType === 0 ? SEND_RESULT_OPTIONS : SEND_RESULT_OPTIONS.slice(0, 5)
    }
  },
  mounted() {
    if (this.$route.params) {
     this.formData =  this.$route.params
    }
    this.handleSignSearch()
    this.getTemplates()
    this.getSmsList()
  },
  methods: {
    moment,
    async handleSignSearch(val) {
      this.lastSignFetchId += 1;
      const fetchId = this.lastSignFetchId
      this.signFetching = true
      getSignList({ accountId: this.user.accountId, signName: val }).then((res) => {
        if (fetchId !== this.lastSignFetchId) {
          return;
        }
        const { errorCode, result }  = res
        if (errorCode === '0') {
          this.signOptions = result ? [{ signId: -1, signName: '未知签名'}].concat(result) : [{ signId: -1, signName: '未知签名'}]
        }
        this.signFetching = false
      }).catch(() => {
        this.signFetching = false
      })
    },
    handleSignChange(val) {
      this.formData.templateId = null
      if (!val) {
        this.handleSignSearch()
        this.templateOptions = []
      } else {
        this.handleTemplateSearch()
      }
      this.getSmsList()
    },
    async getTemplates() {
      this.templateFetching = true
      try {
        const data = this.formData.signId ? await getTempListBySign({ signId: this.formData.signId, templateName: this.templateValue }) :
         await getTempListByAcct({ accountId: this.accountId, templateName: this.templateValue })
        this.templateFetching = false
        const { errorCode, result }  = data
        if (errorCode === '0') {
          this.templateOptions = result || []
        }
      } catch (err) {
        console.log(err)
        this.templateFetching = false
      }
    },
    // 根据签名获取模板列表
    async handleTemplateSearch(val) {
      this.lastTempFetchId += 1;
      const fetchId = this.lastTempFetchId
      this.templateValue = val
      this.templateFetching = true
      try {
        const data = await this.getTemplates()
        if (fetchId !== this.lastTempFetchId) {
          return;
        }
        const { errorCode, result }  = data
        if (errorCode === '0') {
          this.templateOptions = result || []
        }
        this.templateFetching = false
      } catch (e) {
        console.log(e)
        this.templateFetching = false
      }
    },
    handleTemplateChange(val) {
      if (!val) {
        this.handleTemplateSearch()
      }
      this.getSmsList()
    },
    handleTableChange(pagination) {
      const { current, pageSize } = pagination
      this.myPagination = { ...this.myPagination, current, pageSize };
      this.getSmsList();
    },
    handleSearch(e) {
      e.preventDefault();
      this.myPagination.current = 1
      this.formData.recentBeginTiming = ''
      this.formData.recentEndTiming = ''
      this.getSmsList();
    },
    searchByTime(type) {
      if (type === 'hour') {
        this.formData.recentBeginTiming = moment().subtract(1, "hours").format("YYYY-MM-DD HH:mm:ss")
      } else {
        this.formData.recentBeginTiming = moment().subtract(1, "days").format("YYYY-MM-DD HH:mm:ss")
      }
      this.formData.recentEndTiming = moment().format("YYYY-MM-DD HH:mm:ss")
      this.myPagination.current = 1
      this.getSmsList();

    },
    getSmsList() {
      if (!this.hasPermission('smsDetailList')) {
        return this.$message.error('当前用户无查看发送详情权限')
      }
      this.loading = true
      const params = this.handleParams()
      getSendSmsList(params).then((res) => {
        const { errorCode, errorMsg, result }  = res
        if (errorCode === '0') {
          if (result) {
            this.tableData = result.result
            this.myPagination.total = result.pagination?.total || 0
          } else {
            this.tableData = []
            this.myPagination.total = 0
          }
        } else {
          this.$message.error(errorMsg)
        }
        this.loading = false
      }).catch(() => {
        this.loading = false
      })
    },
    handleParams() {
      const { current, pageSize } = this.myPagination
      const { taskId, signId, templateId, phoneNumber, sendResult, beginTiming, endTiming, recentBeginTiming, recentEndTiming } = this.formData
      const begin = beginTiming ? beginTiming + ':00' : ''
      const end = endTiming ? endTiming + ':00' : ''
      const params = { accountId: this.accountId,taskId, signId, templateId, phoneNumber, sendResult, recentBeginTiming, recentEndTiming,
        beginTiming: begin, endTiming: end, pagination: { page: current, size: pageSize }}
      return params
    },
    calendarPriceRangeChange(date) {
      this.selectPriceDate = date[0]
    },
    onDateChange(val) {
      if (!val || val?.length === 0) {
        this.sendDate = []
        this.checkedDate = []
        this.formData.beginTiming = ''
        this.formData.endTiming = ''
        this.selectPriceDate = ''
      }
    },
    submitTime() {
      this.checkedDate = this.$_.cloneDeep(this.sendDate)
      if (this.checkedDate.length > 0) {
        this.formData.beginTiming = moment(this.checkedDate[0]).format("YYYY-MM-DD HH:mm")
        this.formData.endTiming = moment(this.checkedDate[1]).format("YYYY-MM-DD HH:mm")
      }
    },
    triggerDate(isOpen){
      if (!isOpen) {
        this.sendDate = this.$_.cloneDeep(this.checkedDate)
        if (this.checkedDate?.length === 0) {
          this.selectPriceDate = ''
        }
      }
    },
    disabledDate(current) {
      if (this.selectPriceDate) {
        return current < moment().subtract(60, 'days') || current > moment() || current > moment(this.selectPriceDate).add(24, "hours") ||
          current < moment(this.selectPriceDate).subtract(24, "hours")
      } else {
        return current < moment().subtract(60, 'days') || current > moment()
      }
    },
    reset() {
      this.formData = {}
      this.sendDate = []
      this.checkedDate = []
      this.selectPriceDate = ''
      this.getSmsList()
    }
  },
  filters: {
    parseType(value) {
      const map = new Map(TEMPLATE_TYPE)
      return map.get(value)
    },
    parseResult(value) {
      const map = new Map(SEND_RESULT_STATUS)
      return map.get(value)
    }
  }
}
</script>

<style lang="less" scoped>
.send-detail-container{
  background: #ffffff;
  .header{
    padding: 10px 20px;
    /deep/ .ant-select-selection{
      width: 160px;
    }
  }
}
</style>
