<template>
  <div class="task-form">
    <a-form
      :form="form"
      :label-col="{ span: 5 }"
      :wrapper-col="{ span: 12 }"
      @submit="handleSubmit"
    >
      <a-form-item label="任务名称">
        <a-input
          v-decorator="['taskName',{
          rules: [
          { message: '任务名称不能超过30个字', max: 30 },
          { required: true, message: '请输入任务名称'},
          ]}]"
          placeholder="请输入任务名称"
        ></a-input>
      </a-form-item>
      <a-form-item label="短信应用">
        <a-select
          v-decorator="['appId', { rules: [{ required: true, message: '请选择应用' }] }]"
          placeholder="请选择应用"
          show-search
          allowClear
          :filter-option="false"
          :getPopupContainer="(triggerNode) => triggerNode.parentNode || document.body"
          @search="handleAppSearch"
          @change="handleAppChange"
        >
          <a-spin v-if="appFetching" slot="notFoundContent" size="small" />
          <a-select-option v-for="item in appOptions" :key="item.appId" :title="item.appName">
            {{item.appName}}
          </a-select-option>
        </a-select>
        <template slot="extra">
          <span class="ant-form-text">还没有应用？<a @click="jumpToApp">马上去添加</a></span>
        </template>
      </a-form-item>
      <a-form-item v-if="isDomestic" label="短信签名">
        <a-select
          v-decorator="['signId',{ rules: [{ required: true, message: '请选择签名' }]}]"
          placeholder="请选择签名"
          show-search
          allowClear
          :filter-option="false"
          :getPopupContainer="(triggerNode) => triggerNode.parentNode || document.body"
          @search="(e)=>handleSearch(e, 'sign')"
          @change="handleSignChange"
        >
          <a-spin v-if="lastFetching" slot="notFoundContent" size="small" />
          <a-select-option v-for="item in signOptions" :key="item.signId" :title="item.signName">
            {{item.signName}}
          </a-select-option>
        </a-select>
        <template slot="extra">
          <span>不支持使用验证码类短信签名；</span><br/>
          <span>还没有签名？<a @click="jumpToSign">马上去添加</a></span>
        </template>
      </a-form-item>
      <a-form-item label="短信模板">
        <a-select
          v-decorator="['templateId',{ rules: [{ required: true, message: '请选择模板' }]}]"
          placeholder="请选择模板"
          show-search
          allowClear
          :filter-option="false"
          :getPopupContainer="(triggerNode) => triggerNode.parentNode || document.body"
          @search="(e)=>handleBothTempSearch(e, 'template')"
          @change="handleTemplateChange"
        >
          <a-spin v-if="lastFetching" slot="notFoundContent" size="small" />
          <a-select-option v-for="item in templateOptions" :key="item.templateId" :title="item.templateName">
            {{item.templateName}}
          </a-select-option>
        </a-select>
        <template slot="extra">
          <p v-if="templateContent" class="temp-cont">{{templateContent}}</p>
<!--          <a-textarea disabled :value="templateContent"></a-textarea>-->
<!--          <span>短信字数：{{smsLength}}，拆分条数：{{smsNumber}}</span><br/>-->
          <span>选择模板时，显示为空？当前您所选签名下的模板全是变量模板，群发助手不支持有变量模板；</span><br/>
          <span>还没有模板？<a @click="jumpToTemplate">马上去添加</a></span>
        </template>
      </a-form-item>
      <a-form-item label="导入接收号码文件">
        <a-upload
          v-decorator="['receiveFile',{ rules: [{ required: true, message: '请上传文件' }]}]"
          name="file"
          accept=".txt"
          :multiple="false"
          :file-list="fileList"
          :showUploadList="{showRemoveIcon: false}"
          :headers="headers"
          :before-upload="beforeUpload"
        >
          <a-button><a-icon type="upload" />点击上传扫描件</a-button>
        </a-upload>
        <template slot="extra">
          <p>导入txt文件，存放的手机号码不超过5万个，且文件名只能包含数字字母中文<br/>
            下载示例文件（<a href="./static/home.txt" target="_blank" download="国内.txt" style="margin-right: 10px">国内示例</a>
            <a href="./static/internal.txt" target="_blank" download="国际.txt">国际示例</a>）
          </p>
        </template>
      </a-form-item>
      <a-form-item label="定时发送">
        <a-radio-group name="radioGroup" v-decorator="['ifTiming']" @change="changeTimeSend">
          <a-radio :value="0">否</a-radio>
          <a-radio :value="1">是</a-radio>
        </a-radio-group>
      </a-form-item>
      <a-form-item v-if="formData.ifTiming" label="定时发送时间">
        <a-date-picker
          show-time
          class="date-box"
          placeholder="选择时间"
          v-decorator="['timingDate',{ rules: [{ required: true, message: '请选择时间' }]}]"
          :getCalendarContainer="(triggerNode) => triggerNode.parentNode || document.body"
          :disabled-date="disabledDate"
          @ok="submitTime"
          @openChange="triggerDate"
          @change="onDateChange"></a-date-picker>
      </a-form-item>
      <p style="text-align: center">提交发送任务成功后，请前往发送详情页面查询</p>
      <a-form-item :wrapper-col="{ span: 24 }" style="text-align: center">
        <a-button @click="goBack" style="margin-right: 20px">返回</a-button>
        <a-button :loading="submitLoading" type="primary"  html-type="submit">确定</a-button>
      </a-form-item>
    </a-form>
    <a-modal title="新增任务成功" :visible="visible" @cancel="goBack">
      <p>{{taskResult}}</p>
      <template slot="footer">
        <a-button key="submit" type="primary" @click="goBack">确认</a-button>
      </template>
    </a-modal>
  </div>
</template>

<script>
import AFormItem from "ant-design-vue/es/form/FormItem"
import debounce from 'lodash/debounce'
import { getAppOptions } from '@/services/application'
import { getOptions, getTemplates, addTask } from '@/services/task'
import { VAR_PROPS_OPTIONS } from '@/config/default/sms.config'
// import ATextarea from "ant-design-vue/es/input/TextArea"
import { bytesLength } from '@/utils/util'
import moment from 'moment';
export default {
  name: "TaskForm",
  components: { AFormItem},
  props: {
    type: {
      type: String,
      default: 'home'
    }
  },
  data() {
    this.lastFetchId = 0
    this.lastAppFetchId = 0
    this.lastTempFetchId = 0
    this.handleAppSearch = debounce(this.handleAppSearch, 800)
    this.handleSearch = debounce(this.handleSearch, 800)
    this.handleTemplateSearch = debounce(this.handleTemplateSearch, 800)
    this.propOptions = VAR_PROPS_OPTIONS
    return{
      form: this.$form.createForm(this),
      headers: {
        authorization: 'authorization-text',
      },
      appOptions: [],
      signOptions: [],
      templateOptions: [],
      formData: {},
      isDomestic: true, // 是否国内应用
      attrTypes: [],
      varColumns: [],
      submitLoading: false,
      appValue: '',
      signValue: '',
      templateValue: '',
      appFetching: false,
      lastFetching: false,
      templateFetching: false,
      isTxt: false,
      txtFile: null,
      receiveFile: null,
      templateContent: '', // 所选模板内容
      signLen: 0,
      templateLen: 0,
      fileList: [],
      checkedTime: '',
      showTime: '',
      checkedShowTime: '',
      taskResult: '',
      visible: false
    }
  },
  computed: {
    isHome() {
      return this.type === 'home'
    },
    accountId() {
      return this.$store.state.account.user.accountId
    },
    // 短信字数
    smsLength() {
      return this.signLen + this.templateLen
    },
    // 拆分条数
    smsNumber() {
      if (this.smsLength > 134) {
        return this.smsLength%134 > 0 ? Math.floor(this.smsLength/134)+1 : this.smsLength/134
      } else {
        return this.smsLength > 0 ? 1 : 0
      }
    }
  },
  async mounted() {
    this.form.setFieldsValue({ ifTiming: 1})
    this.formData.ifTiming = 1
    this.handleAppSearch()
  },
  methods: {
    moment,
    // 查询应用
    async handleAppSearch(val) {
      this.lastAppFetchId += 1;
      const fetchId = this.lastAppFetchId
      this.appValue = val
      this.appFetching = true
      try {
        const data = await this.getAppList()
        if (fetchId !== this.lastAppFetchId) {
          return;
        }
        const { errorCode, result }  = data
        if (errorCode === '0' && result) {
          this.appOptions = result.smsAppsPos || []
        } else {
          this.appOptions = []
        }
        this.appFetching = false
      } catch (e) {
        console.log(e)
        this.appFetching = false
      }
    },
    getAppList() {
      const params = { accountId: this.accountId, appName: this.appValue, queryType: 1}
      this.appFetching = true
      return getAppOptions({ ...params, pagination: { page:1, size: 100 } })
    },
    // 选择应用
    handleAppChange(val) {
      this.form.setFieldsValue({ signId: null })
      this.form.setFieldsValue({ templateId: null })
      this.formData.appId = val
      // 获取当前选中应用是国内/国际类型
      this.isDomestic = this.appOptions.filter((item) => item.appId === val)[0]?.isDomestic
      if (!val) {
        this.handleAppSearch()
        this.signOptions = []
        this.templateOptions = []
      } else {
        this.handleSearch()
      }
      this.clearLength()
    },
    // 根据国际/国内进行不同模板查询
    handleBothTempSearch(val, type) {
      if (this.isDomestic) {
        this.handleTemplateSearch(val)
      } else {
        this.handleSearch(val, type)
      }
    },
    async handleSearch(val, type) {
      // type: sign/template
      this.lastFetchId += 1;
      const fetchId = this.lastFetchId
      this[`${type}Value`] = val
      this.lastFetching = true
      try {
        const data = await this.getOptions(type)
        if (fetchId !== this.lastFetchId) {
          return;
        }
        const { errorCode, result }  = data
        if (errorCode === '0') {
          this.signOptions = result?.signList || []
          this.templateOptions = result?.templateList || []
        }
        this.lastFetching = false
      } catch (e) {
        console.log(e)
        this.lastFetching = false
      }
    },
    // 根据应用ID和国内外标识查询短信签名或短信模板。当是国内的时候返回签名数据，当是国外的时候返回模板数据
    getOptions(type) {
      let params = { appId: this.formData.appId, isDomestic: this.isDomestic }
      params[`${type}Name`] = this[`${type}Value`]
      this.lastFetching = true
      return getOptions(params)
    },
    // 选择签名
    handleSignChange(val) {
      this.form.setFieldsValue({ templateId: null })
      this.formData.signId = val
      if (!val) {
        this.clearLength()
        this.handleSearch('', 'sign')
        this.templateOptions = []
      } else {
        const signValue = this.signOptions.filter((ele)=>ele.signId === val)[0]?.signName
        this.signLen = bytesLength(signValue)
        this.templateLen = 0
        this.templateContent = ''
        this.handleTemplateSearch()
      }
    },
    // 根据签名获取模板列表
    async handleTemplateSearch(val) {
      this.lastTempFetchId += 1;
      const fetchId = this.lastTempFetchId
      this.templateValue = val
      this.templateFetching = true
      try {
        const data = await this.getTemplates()
        if (fetchId !== this.lastTempFetchId) {
          return;
        }
        const { errorCode, result }  = data
        if (errorCode === '0') {
          this.templateOptions = result || []
        }
        this.templateFetching = false
      } catch (e) {
        console.log(e)
        this.templateFetching = false
      }
    },
    // 根据签名获取模板
    getTemplates() {
      let params = { signId: this.formData.signId, templateName: this.templateValue }
      this.templateFetching = true
      return getTemplates(params)
    },
    handleTemplateChange(val) {
      if (val) {
        this.templateContent = this.templateOptions.filter((ele) => ele.templateId === val)[0]?.templateContent
        this.templateLen = bytesLength(this.templateContent)
      } else {
        if (this.isDomestic) {
          this.handleTemplateSearch('')
        } else {
          this.handleSearch('', 'template')
        }
        this.templateLen = 0
        this.templateContent = ''
      }
      this.formData.templateId = val
    },
    handleSubmit(e) {
      e.preventDefault();
      if (!this.isTxt) {
        return this.$message.error('仅支持.txt的文件')
      }
      this.submitLoading = true
      this.form.validateFields((err, values) => {
        if (!err) {
          const params = this.handleParams(values)
          this.addTask(params)
        } else {
          this.submitLoading = false
        }
      });
    },
    addTask(params) {
      this.submitLoading = true
      addTask(params).then((data) => {
        if (data.errorCode === '0') {
          this.taskResult = data.errorMsg
          this.visible = true
          // this.$router.push('/task/list')
        } else {
          this.$message.error(data.errorMsg)
        }
        this.submitLoading = false
      }).catch(() => {
        this.submitLoading = false
      })
    },
    handleParams(values) {
      const { taskName, appId, signId, templateId, ifTiming } = values
      let formData = new FormData()
      formData.append('taskName', taskName)
      formData.append('appId', appId)
      if (signId) formData.append('signId', signId)
      formData.append('templateId', templateId)
      formData.append('ifTiming', ifTiming)
      formData.append('timingDate', this.checkedTime)
      formData.append('receiveFile', this.txtFile)
      formData.append('isDomestic', this.isDomestic)
      formData.append('accountId', this.accountId,)
      return formData
    },
    changeTimeSend(e) {
      this.formData.ifTiming = e.target.value
    },
    onDateChange(value, dateString) {
      this.showTime = value
      this.formData.timingDate = dateString
    },
    submitTime() {
      this.checkedTime = this.formData.timingDate
      this.checkedShowTime = this.showTime
    },
    triggerDate(isOpen) {
      if (!isOpen) {
        this.form.setFieldsValue({timingDate: this.checkedShowTime})
      }
    },
    beforeUpload(file) {
      this.isTxt = file.type === 'text/plain'
      if (this.isTxt) {
        this.txtFile = file
        this.fileList = [file]
      } else {
        this.$message.error('仅支持.txt的文件')
        this.fileList = []
      }
      return false
    },
    disabledDate(current) {
      return current < moment().subtract(1, 'minutes') || current > moment().add(1, 'month')
    },
    clearLength() {
      this.templateContent = ''
      this.templateLen = 0
      this.signLen = 0
    },
    jumpToApp() {
      this.$router.push('/application/create')
    },
    jumpToSign() {
      this.$router.push('/sign/create')
    },
    jumpToTemplate() {
      this.$router.push('/template/create')
    },
    goBack() {
      this.$router.go(-1)
    }
  }
}
</script>

<style lang="less" scoped>
.task-form{
    background: #ffffff;
    padding: 20px;
    .tips{
      padding-left: 21%;
    }
    .var-table{
      width: 100%;
      tr td{
        text-align: center;
        width: 50%;
      }
      /deep/ .ant-select{
        width: 80%;
      }
    }
  .date-box{
    /deep/ .ant-calendar-today-btn{
      display: none;
    }
  }
  .temp-cont{
    border: 1px solid #d9d9d9;
    border-radius: 4px;
    padding: 10px;
    word-break: break-all;
  }
}
</style>
