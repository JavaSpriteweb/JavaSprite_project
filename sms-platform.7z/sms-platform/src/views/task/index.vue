<template>
  <div class="task-container">
    <div class="header">
      <a-form layout="inline" @submit="handleSubmit">
        <a-form-item label="任务名称">
          <a-select
            placeholder="请选择任务"
            v-model="form.taskName"
            show-search
            allowClear
            :filter-option="false"
            :getPopupContainer="(triggerNode) => triggerNode.parentNode || document.body"
            @search="handleTaskSearch"
            @change="handleTaskChange"
          >
            <a-spin v-if="taskFetching" slot="notFoundContent" size="small" />
            <a-select-option v-for="item in taskOptions" :key="item.taskName" :title="item.taskName">
              {{item.taskName}}
            </a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="状态">
          <a-select
            placeholder="请选择状态"
            allowClear
            v-model="form.taskStatus"
            :getPopupContainer="(triggerNode) => triggerNode.parentNode || document.body"
            @change="getTaskList"
          >
            <a-select-option v-for="ele in statusOptions" :key="ele.value">
              {{ele.label}}
            </a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item>
          <a-button v-if="hasPermission('taskList')" type="primary" html-type="submit">查询</a-button>
          <a-button v-if="hasPermission('createTask')" type="primary" @click="jumpToCreate" style="margin-left: 10px">添加任务</a-button>
        </a-form-item>
      </a-form>
    </div>
    <div class="task-table">
      <a-table
        :columns="tableColumns"
        :data-source="tableData"
        rowKey="taskId"
        :scroll="{x: 1200}"
        :loading="loading"
        :pagination="tablePagination"
      >
        <template slot="taskStatus" slot-scope="text">
          {{text | parseStatus}}
        </template>
        <template slot="operation" slot-scope="text, record">
          <a-button v-if="hasPermission('smsDetailList')" :disabled="record.taskStatus===1" type="link" size="small" @click="jumpToDetail(record)">详情</a-button>
          <a-divider v-if="hasPermission('deleteTask')" type="vertical" />
          <a-button v-if="hasPermission('deleteTask')" :disabled="record.taskStatus!==1" type="link" size="small" @click="deleteTask(record)">删除</a-button>
          <a-divider v-if="hasPermission('revokeTask')" type="vertical" />
          <a-button v-if="hasPermission('revokeTask')" :disabled="record.taskStatus!==0" type="link" size="small" @click="revokeTask(record)">撤销任务</a-button>
        </template>
      </a-table>
    </div>
  </div>
</template>

<script>
import AFormItem from "ant-design-vue/es/form/FormItem"
import { getTaskOptions, getTaskList, deleteTask, revokeTask } from '@/services/task'
import { TASK_STATUS_OPTIONS, TASK_STATUS } from '@/config/default/sms.config'
import debounce from 'lodash/debounce'

export default {
  name: "index",
  components: {AFormItem },
  data() {
    // this.tableColumns = [
    //   { title: '任务名称', dataIndex: 'taskName' },
    //   { title: '号码数量', dataIndex: 'phoneCount' },
    //   { title: '发送总数（条）', dataIndex: 'sendCount' },
    //   { title: '发送成功数（条）', dataIndex: 'successCount' },
    //   { title: '定时发送时间', dataIndex: 'timingDate', width: 180 },
    //   { title: '任务状态', dataIndex: 'taskStatus', scopedSlots: { customRender: 'taskStatus' } },
    //   { title: '创建时间', dataIndex: 'createDate', width: 180 },
    //   { title: '操作', dataIndex: 'operation', scopedSlots: { customRender: 'operation' }, fixed: 'right', align: 'center' },
    // ];
    this.lastTaskFetchId = 0;
    this.handleTaskSearch = debounce(this.handleTaskSearch, 800);
    return {
      form: {},
      taskOptions: [],
      tableData: [],
      total: 0,
      loading: false,
      taskFetching: false,
    }
  },
  computed: {
    tableColumns() {
      return [
        { title: '任务名称', dataIndex: 'taskName' },
        { title: '号码数量', dataIndex: 'phoneCount' },
        { title: '发送总数（条）', dataIndex: 'sendCount' },
        { title: '发送成功数（条）', dataIndex: 'successCount' },
        { title: '定时发送时间', dataIndex: 'timingDate', width: 180 },
        { title: '任务状态', dataIndex: 'taskStatus', scopedSlots: { customRender: 'taskStatus' } },
        { title: '创建时间', dataIndex: 'createDate', width: 180 },
        { title: '操作', dataIndex: 'operation', scopedSlots: { customRender: 'operation' },
          width: this.$store.state.account.user.accountType === 0 ? 100 : 180, fixed: 'right', align: 'center' },
      ]
    },
    accountId() {
      return this.$store.state.account.user.accountId
    },
    statusOptions() {
      return this.$store.state.account.user.accountType === 0 ? TASK_STATUS_OPTIONS : TASK_STATUS_OPTIONS.slice(0, 4)
    }
  },
  mounted() {
    this.handleTaskSearch()
    this.getTaskList()
  },
  methods: {
    // 查询所有任务名称
    handleTaskSearch(val) {
      this.lastTaskFetchId += 1
      const fetchId = this.lastTaskFetchId
      const params = { accountId: this.accountId, taskName: val }
      this.taskFetching = true
      getTaskOptions({ ...params }).then((data) => {
        if (fetchId !== this.lastTaskFetchId) {
          return;
        }
        const { errorCode, result }  = data
        if (errorCode === '0') {
          this.taskOptions = result || []
        } else {
          this.taskOptions = []
        }
        this.taskFetching = false
      }).catch(() => {
        this.taskFetching = false
        this.taskOptions = []
      })
    },
    handleTaskChange(val) {
      if (!val) {
        this.handleTaskSearch()
      }
      this.getTaskList()
    },
    getTaskList() {
      if (!this.hasPermission('taskList')) {
        return this.$message.error('该用户暂无查看任务权限')
      }
      const { current, pageSize } = this.myPagination
      this.loading = true
      const params = { accountId: this.accountId, taskName: this.form.taskName, taskStatus: this.form.taskStatus,
        pagination: { page: current, size: pageSize }}
      getTaskList(params).then((res) => {
        const { errorCode, errorMsg, result }  = res
        if (errorCode === '0') {
          if (result) {
            this.tableData = result.result
            this.myPagination.total = result.pagination?.total || 0
          } else {
            this.tableData = []
            this.total = 0
          }
        } else {
          this.$message.error(errorMsg)
        }
        this.loading = false
      }).catch(() => {
        this.loading = false
      })
    },
    handleTableChange(pagination) {
      const { current, pageSize } = pagination
      this.myPagination = { ...this.myPagination, current, pageSize };
      this.getTaskList();
    },
    handleSubmit(e) {
      e.preventDefault();
      this.myPagination.current = 1
      this.getTaskList();
    },
    deleteTask(row) {
      this.$confirm({
        okText: '确认',
        content: '是否删除任务',
        cancelText: '取消',
        onOk: () => {
          this.loading = true
          deleteTask({ accountId: this.accountId, taskId: row.taskId }).then((data) => {
            const { errorCode, errorMsg } = data
            if (errorCode === '0') {
              this.$message.success(errorMsg)
            } else {
              this.$message.error(errorMsg)
            }
            this.loading = false
            this.getTaskList()
          }).catch(() => {
            this.loading = false
          })
        },
        onCancel() {
          console.log('Cancel');
        },
      });
    },
    revokeTask(row) {
      this.$confirm({
        okText: '确认',
        content: '是否撤销任务',
        cancelText: '取消',
        onOk: () => {
          this.loading = true
          revokeTask({ accountId: this.accountId, taskId: row.taskId }).then((data) => {
            const { errorCode, errorMsg } = data
            if (errorCode === '0') {
              this.$message.success(errorMsg)
            } else {
              this.$message.error(errorMsg)
            }
            this.loading = false
            this.getTaskList()
          }).catch(() => {
            this.loading = false
          })
        },
        onCancel() {
          console.log('Cancel');
        },
      });
    },
    jumpToCreate() {
      this.$router.push({path: '/task/create'})
    },
    // 跳转至发送短信详情
    jumpToDetail(row) {
      this.$router.push({ name: '发送详情列表', params: row })
    },
  },
  filters: {
    parseStatus(value) {
      const map = new Map(TASK_STATUS)
      return map.get(value)
    }
  }
}
</script>

<style lang="less" scoped>
  .task-container{
    background: #ffffff;
    width: 100%;
    height: 100%;
    .header{
      padding: 10px 20px;
      /deep/ .ant-select-selection{
        width: 160px;
      }
    }
    .task-table{
      /deep/ .ant-table-fixed-right{
        .ant-table-fixed{
          tr td{
            padding: 0 10px;
            .ant-divider{
              margin: 0;
            }
          }
        }
      }
    }
    .batch-box{
    }
  }
</style>
