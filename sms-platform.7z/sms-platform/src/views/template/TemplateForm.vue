<template>
  <div :class="['template-form', {'detail': !canEdit}]">
    <a-form
      :form="form"
      :label-col="{ span: 5 }"
      :wrapper-col="{ span: canEdit?12:19 }"
      @submit="handleSubmit"
    >
      <a-form-item label="模板名称">
        <a-input
          v-if="canEdit"
          v-decorator="['templateName',{
          rules: [
          { message: '模板名称不能超过30个字', max: 30 },
          { required: true, message: '请输入模板名称'},
          { validator: validTemplateName }
          ], trigger: 'blur'}]"
          placeholder="请输入模板名称"
        ></a-input>
        <span v-else>{{tempData.templateName}}</span>
      </a-form-item>
      <a-form-item v-if="isHome" label="模板类型">
        <a-select
          v-if="canEdit"
          :getPopupContainer="(triggerNode) => triggerNode.parentNode || document.body"
          v-decorator="['templateType', { rules: [{ required: true, message: '请选择模板类型' }] }]"
          placeholder="请选择模板类型"
          @change="handleTypeChange"
        >
          <a-select-option v-for="item in typeOptions" :key="item.value">
            {{item.label}}
          </a-select-option>
        </a-select>
        <span v-else>{{tempData.templateType | filterType}}</span>
      </a-form-item>
      <a-form-item label="所属应用">
        <a-select
          v-if="canEdit"
          v-decorator="['appId', { rules: [{ required: true, message: '请选择应用' }] }]"
          placeholder="请选择应用"
          :getPopupContainer="(triggerNode) => triggerNode.parentNode || document.body"
          show-search
          allowClear
          :filter-option="false"
          @search="handleAppSearch"
          @change="handleAppChange"
        >
          <a-spin v-if="appFetching" slot="notFoundContent" size="small" />
          <a-select-option v-for="item in appOptions" :key="item.appId" :title="item.appName">
            {{item.appName}}
          </a-select-option>
        </a-select>
        <span v-else>{{tempData.appName}}</span>
        <template slot="extra" v-if="canEdit">
          <span class="ant-form-text">还没有应用？<a @click="jumpToApp">马上去添加</a></span>
        </template>
      </a-form-item>
      <a-form-item v-if="isHome" label="所属签名">
        <a-select
          v-if="canEdit"
          v-decorator="['signId',{ rules: [{ required: true, message: '请选择签名' }]}]"
          :getPopupContainer="(triggerNode) => triggerNode.parentNode || document.body"
          label-in-value
          placeholder="请选择签名"
          show-search
          allowClear
          :filter-option="false"
          @search="handleSignSearch"
          @change="handleSignChange"
        >
          <a-spin v-if="signFetching" slot="notFoundContent" size="small" />
          <a-select-option v-for="item in signOptions" :key="item.signId" :title="item.signName">{{item.signName}}</a-select-option>
        </a-select>
        <span v-else>{{tempData.signName}}</span>
        <template v-if="canEdit" slot="extra">
          <span>还没有签名？<a @click="jumpToSign">马上去添加</a></span>
        </template>
      </a-form-item>
      <a-form-item label="模板内容" class="temp-content">
        <a-textarea
          v-if="canEdit"
          placeholder="变量格式:${1}、${2}、...、${20} 示例:您的验证码为:s{1}，该验证码5分钟内有效，请勿泄漏于他人!"
          :rows="4"
          v-decorator="['templateContent',
          { rules: [{ required: true, message: '请输入模板内容' },{validator: checkContext}], trigger: 'blur' }]"
        ></a-textarea>
        <span v-else>{{tempData.templateContent}}</span>
        <template slot="extra">
          <span style="padding-left: 15px">短信字数：{{smsLength}}，拆分条数：{{smsNumber}} <a v-if="canEdit" @click="isRuleVisible=true">变量规则</a></span>
          <ul v-if="canEdit" style="padding-left: 15px">
            <li>验证码模板仅支持验证码作为变量，内容必须包含验证码，注册码，校验码，动态码4个词之一</li>
            <li>推广类模板必须包含退订方式，支持“TD、T、N"进行短信退订回复</li>
            <li>为避免模板审核不通过，请务必详细阅读 <a @click="isTmpVisible=true">模板和变量规范</a>，查看<a @click="isExampVisible=true">模板示例</a>后再填写</li>
          </ul>
        </template>
      </a-form-item>
      <a-form-item label="变量属性">
        <template v-if="canEdit" slot="extra">
          <ul style="padding-left: 15px">
            <li>变量内容不支持QQ号、微信号(公众号)、网址信息</li>
            <li>变量属性为其他号码、其他的变量内容，不支持电话号码</li>
            <li>精准选择对应的变量届性将提高审核效率，<a @click="isTmpVisible=true">变量规范</a></li></ul>
        </template>
        <a-form :form="attrForm" layout="inline" class="attr-form">
          <a-form-item v-for="(item, index) in attrTypes" :key="index" :label="item.attrKey">
            <a-select
              placeholder="请选择属性"
              v-if="canEdit"
              v-decorator="[`attrValue${index}`,{ rules: [{ required: true, message: '请选择变量属性' }]}]"
              :getPopupContainer="(triggerNode) => triggerNode.parentNode || document.body"
              :disabled="!canEdit">
              <a-select-option v-for="ele in propOptions" :key="ele.value" :title="ele.label">
                {{ele.label}}
              </a-select-option>
            </a-select>
            <span v-else>{{item.attrValue | filterVar}}</span>
          </a-form-item>
        </a-form>
      </a-form-item>
      <a-form-item v-if="!isHome" label="发送国家">
        <a-select
          v-if="canEdit"
          placeholder="请选择发送国家"
          :getPopupContainer="(triggerNode) => triggerNode.parentNode || document.body"
          v-decorator="['sendCountries', { rules: [{ required: true, message: '请选择发送国家' }] }]"
          :filter-option="filterOption"
          mode="multiple">
          <a-select-option v-for="item in countryOptions" :key="item.valueCode">
            {{item.valueName}}
          </a-select-option>
        </a-select>
        <span v-else>{{sendCountries}}</span>
      </a-form-item>
      <a-form-item label="申请说明">
        <a-textarea
          v-if="canEdit"
          placeholder="请描述您的业务场景"
          :rows="4"
          v-decorator="['applyInstructions',{ rules: [{ message: '申请说明不能超过500个字', max: 500 }] }]">
        </a-textarea>
        <span v-else>{{tempData.applyInstructions}}</span>
        <template v-if="canEdit" slot="extra">
          <p>预计2小时内完成审核<br>
          审核时间:工作日09:00-18:00(GMT+08:00)(法定节假日顺延)</p>
        </template>
      </a-form-item>
      <a-form-item :wrapper-col="{ span: 24 }" style="text-align: center" v-if="canEdit">
        <a-button @click="goBack" style="margin-right: 20px">返回</a-button>
        <a-button :loading="submitLoading" type="primary"  html-type="submit">确定</a-button>
      </a-form-item>
    </a-form>
    <a-modal :visible="isTmpVisible" width="700px" class="tpm-modal" title="模板和变量规范" @cancel="isTmpVisible=false" :footer="null">
      <TmpStandard></TmpStandard>
    </a-modal>
    <a-modal :visible="isExampVisible" width="700px" class="tpm-modal" title="模板示例" @cancel="isExampVisible=false" :footer="null">
      <TempExp></TempExp>
    </a-modal>
    <a-modal :visible="isRuleVisible" width="700px" class="tpm-modal" title="短信发送规则" @cancel="isRuleVisible=false" :footer="null">
      <SmsRule></SmsRule>
    </a-modal>
  </div>
</template>

<script>
import AFormItem from "ant-design-vue/es/form/FormItem"
import ATextarea from "ant-design-vue/es/input/TextArea"
import TmpStandard from '../standard/TemplateStandard'
import TempExp from '../standard/TempExp'
import SmsRule from '../standard/SmsRule'
import debounce from 'lodash/debounce'
import { addTemplate, updateTemplate, isExist, getDomainData } from '@/services/template'
import { getSignOptions } from '@/services/sign'
import { getAppOptions } from '@/services/application'
import { bytesLength } from '@/utils/util'
import { VAR_PROPS_OPTIONS, TYPE_OPTIONS, TEMPLATE_TYPE, VAR_PROPS } from '@/config/default/sms.config'

export default {
  name: "AppForm",
  components: {ATextarea, AFormItem, TmpStandard, TempExp, SmsRule},
  props: {
    isHome: {
      type: Boolean,
      default: true
    },
    tempData: {
      type: Object,
      default: () => {}
    },
    countryList: { // 模板审核界面传入国家列表
      type: Array,
      default: () => []
    }
  },
  data() {
    this.lastSignFetchId = 0
    this.lastAppFetchId = 0
    this.handleAppSearch = debounce(this.handleAppSearch, 800)
    this.handleSignSearch = debounce(this.handleSignSearch, 800)
    this.propOptions = VAR_PROPS_OPTIONS
    this.typeOptions = TYPE_OPTIONS
    return{
      isCreate: true,
      form: this.$form.createForm(this),
      attrForm: this.$form.createForm(this),
      appOptions: [],
      signOptions: [],
      countryOptions: [],
      formData: {},
      attrTypes: [],
      varColumns: [],
      submitLoading: false,
      appValue: '',
      signValue: '',
      appFetching: false,
      signFetching: false,
      smsLength: 0, // 短信字数
      templateLen: 0, // 模板字数
      sendCountries: '',
      isTmpVisible: false,
      isExampVisible: false,
      isRuleVisible: false,
      originSignId: null
    }
  },
  computed: {
    canEdit() {
      // 模板审核详情
      return !(this.tempData && this.tempData.templateId)
    },
    accountId() {
      return this.$store.state.account.user.accountId
    },
    // 拆分条数
    smsNumber() {
      // ascii码计算，134个字符为一条短信
      const totalLength = this.templateLen
      if (totalLength > 134) {
        return totalLength%134 > 0 ? Math.floor(totalLength/134)+1 : totalLength/134
      } else {
        return totalLength > 0 ? 1 : 0
      }
    }
  },
  async mounted() {
    if (!this.isHome && this.canEdit){
      this.getCountryList()
    }
    if (this.$route.params.templateId || this.tempData) {
      this.isCreate = false;
      this.initData();
    }
    if (!this.tempData) {
      this.handleAppSearch()
    }
  },
  methods: {
    initData() {
      const data = this.canEdit ? this.$route.params : this.tempData
      this.formData = data
      this.originSignId = data.signId
      this.attrTypes = data.attrTypes
      if (this.canEdit) {
        // 路由跳转修改界面回显数据
        this.form.setFieldsValue(this.$_.pick(data, 'templateName', 'templateType', 'appId', 'templateContent', 'applyInstructions', 'sendCountries'))
        this.handleSignSearch()
        this.form.setFieldsValue({ signId: { key: data.signId, label: data.signName}})
        // 变量表单赋值
        if (data.attrTypes?.length > 0){
          data.attrTypes.forEach((ele, index) => {
            this.$nextTick(() => {
              this.attrForm.setFieldsValue({ [`attrValue${index}`]: ele.attrValue })
            })
          })
        }
      } else if(!this.isHome) {
        // 审核详情：国际短信拼接发送国家
        const sendCountries = this.countryList.filter((ele) => data.sendCountries.some(item => item === ele.valueCode))
        this.sendCountries = this.$_.map(sendCountries, 'valueName').join('，')
      }
      this.parseTempCont(data.templateContent)
    },
    handleTypeChange() {
      this.handleSignSearch()
      this.form.resetFields(['signId'])
    },
    getAppList() {
      const params = { accountId: this.accountId, appName: this.appValue, queryType: 1, isDomestic: this.isHome ? 1 : 0}
      this.appFetching = true
      return getAppOptions({ ...params, pagination: { page: 1, size: 100 } })
    },
    getSignOptions() {
      const signType = this.form.getFieldValue('templateType')
      const params = { appId: this.formData.appId, signName: this.signValue, signType, signStatus: 1 }
      this.signFetching = true
      return getSignOptions(params)
    },
    async handleAppSearch(val) {
      this.lastAppFetchId += 1;
      const fetchId = this.lastAppFetchId
      this.appValue = val
      this.appFetching = true
      try {
        const data = await this.getAppList()
        if (fetchId !== this.lastAppFetchId) {
          return;
        }
        const { errorCode, result }  = data
        if (errorCode === '0') {
          if (result) {
            this.appOptions = result.smsAppsPos || []
          } else {
            this.appOptions = []
          }
        }
        this.appFetching = false
      } catch (e) {
        console.log(e)
        this.appFetching = false
      }
    },
    handleAppChange(val) {
      this.form.resetFields(['signId'])
      this.formData.appId = val
      if (!val) {
        this.handleAppSearch()
        this.signOptions = []
      } else {
        this.handleSignSearch()
      }
    },
    async handleSignSearch(val) {
      this.lastSignFetchId += 1;
      const fetchId = this.lastSignFetchId
      this.signValue = val
      this.signFetching = true
      try {
        const data = await this.getSignOptions()
        if (fetchId !== this.lastSignFetchId) {
          return;
        }
        const { errorCode, result }  = data
        if (errorCode === '0') {
          this.signOptions = result || []
        }
        this.signFetching = false
      } catch (e) {
        console.log(e)
        this.signFetching = false
      }
    },
    handleSignChange(val) {
      this.formData.signId = val?.key || null
      if (!val) {
        this.handleSignSearch()
      }
    },
    getCountryList() {
      getDomainData({ code: 'SMS-0001' }).then((data) => {
        const { errorCode, result } = data
        if (errorCode === '0' && result) {
          this.countryOptions = result.smsDomainVos
        }
      }).catch((err) => {
        console.log(err)
      })
    },
    filterOption(input, option) {
      return (
        option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0
      );
    },
    handleSubmit(e) {
      e.preventDefault();
      this.submitLoading = true
      this.form.validateFields((err, values) => {
        if (!err) {
          // 验证变量表单
          this.attrForm.validateFields((error, attrValues) => {
            if (!error) {
              const params = this.handleParams(values, attrValues)
              if (this.isCreate) {
                this.addTemplate(params)
              } else {
                this.updateTemplate(params)
              }
            } else {
              this.submitLoading = false
            }
          })
        } else {
          this.submitLoading = false
        }
      });
    },
    addTemplate(params) {
      this.submitLoading = true
      addTemplate(params).then((data) => {
        if (data.errorCode === '0') {
          this.$message.success('新增成功')
          this.$router.push('/template')
        } else {
          this.$message.error(data.errorMsg)
        }
        this.submitLoading = false
      }).catch(() => {
        this.submitLoading = false
      })
    },
    updateTemplate(params) {
      this.submitLoading = true
      updateTemplate(params).then((data) => {
        if (data.errorCode === '0') {
          this.$message.success('更新成功')
          this.$router.push('/template')
        } else {
          this.$message.error(data.errorMsg)
        }
        this.submitLoading = false
      }).catch(() => {
        this.submitLoading = false
      })
    },
    handleParams(values, attrValues) {
      const templateCountry = this.isHome ? 1 : 2
      const attrTypes = []
      // 处理变量数据
      for(const key in attrValues) {
        if (Object.prototype.hasOwnProperty.call(attrValues, key)) {
          const index = key.substr(key.length-1,1)
          attrTypes.push({ attrKey: this.attrTypes[index].attrKey, attrValue: attrValues[key] })
        }
      }
      let params =  { ...values, attrTypes, templateCountry }
      if (values.signId) {
        params = { ...params, signId: values.signId.key }
      }
      if (!this.isCreate) {
        params = {...params, templateId: this.formData.templateId }
      }
      return { templateObjects: params, templateCountry }
    },
    parseTempCont(value){
      let reg = /\$\{(.*?)\}/g
      const variableArr = value.match(reg) || [];
      const filterVarValue = value.replace(reg, '')
      let varList = []
      if (variableArr.length > 0) {
        variableArr.forEach((item) => {
          varList.push({ attrKey: item, attrValue: ''})
        })
      }
      let varLength = variableArr.length * 20 // 一个模板变量占20个字符
      this.templateLen = varLength + bytesLength(filterVarValue)
      this.smsLength = varLength + filterVarValue?.length
      return { variableArr, varLength, filterVarValue, varList }
    },
    checkContext(rule, value, callback) {
      if (value) {
        const { variableArr, varLength, filterVarValue, varList } = this.parseTempCont(value)
        this.attrTypes = varList
        variableArr.forEach((item) => {
          if (item.length > 23) {
            return callback('单个变量最多包含20个字符')
          }
        })
        if (variableArr.length > 20) {
          callback('每个模板中最多包含20个变量')
        } else if (varLength + filterVarValue.length > 500){
          callback('模板最多包含500个字')
        } else {
          callback()
        }
      } else {
        this.attrTypes = []
        this.templateLen = 0
        callback()
      }
    },
    validTemplateName(rule, value, callback) {
      const signId = this.form.getFieldValue('signId')?.key
      const appId = this.form.getFieldValue('appId')
      const templateType = this.form.getFieldValue('templateType')
      if (signId && (signId !== this.originSignId && value || value !== this.formData.templateName)){
        isExist({ accountId: this.accountId, templateName: value, signId, appId, templateType }).then((res) => {
          if (res.errorCode !== '0') {
            callback('存在重名模板')
          } else {
            callback()
          }
        })
      } else {
        callback()
      }
    },
    jumpToApp() {
      this.$router.push('/application/create')
    },
    jumpToSign() {
      this.$router.push('/sign/create')
    },
    goBack() {
      this.$router.go(-1)
    }
  },
  filters: {
    filterType(value) {
      const map = new Map(TEMPLATE_TYPE)
      return map.get(value)
    },
    filterVar(value) {
      const map = new Map(VAR_PROPS)
      return map.get(value)
    }
  }
}
</script>

<style lang="less" scoped>
.template-form{
  background: #ffffff;
  &.detail{
    /deep/ .ant-form-item{
      margin-bottom: 0;
      label{
        margin-right: 10px;
      }
      &.temp-content{
        margin-bottom: 10px;
        .ant-form-extra{
          padding-top: 0;
          margin-top: -4px;
        }
      }
    }
  }
  .tips{
    padding-left: 21%;
  }
  .attr-form{
    width: 100%;
    /deep/ .ant-form-item{
      width: 100%;
      margin-right: 0;
      margin-bottom: 0;
      height: 50px;
      &:last-of-type{
        border-bottom: 1px solid #ececec;
      }
      .ant-form-item-label,.ant-form-item-control-wrapper{
        display: inline-block;
        border-color: #ececec;
        border-style: solid;
      }
      .ant-form-item-label{
        width: 40%;
        border-width: 1px;
        border-bottom: 0;
        line-height: 50px;
        overflow: hidden;
        text-overflow:ellipsis;
        white-space:nowrap;
        padding: 0 10px;
        text-align: center;
        label:after{
          display: none;
        }
      }
      .ant-form-item-control-wrapper{
        border-width: 1px 1px 0 0;
        padding: 4px 6px;
        width: 60%;
        position: relative;
        .has-error .ant-form-explain{
          position: absolute;
          right: -110px;
          top: 40%;
        }
      }
    }
  }
}
.tpm-modal{
  /deep/ .ant-modal-body{
    height: 600px;
    overflow-y: auto;
  }
}
</style>
