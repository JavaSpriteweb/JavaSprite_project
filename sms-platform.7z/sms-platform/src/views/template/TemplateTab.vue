<template>
  <div class="template-tab">
    <a-tabs type="card" v-model="activeTab">
      <a-tab-pane key="home" tab="国内短信" v-if="!isEdit || isHome">
        <TemplateForm isHome></TemplateForm>
      </a-tab-pane>
      <a-tab-pane key="internal" tab="国际短信" v-if="!isHome">
        <TemplateForm :isHome="false"></TemplateForm>
      </a-tab-pane>
    </a-tabs>
  </div>
</template>

<script>
import TemplateForm from './TemplateForm'

export default {
  name: "TemplateTab",
  components: { TemplateForm },
  data() {
    return {
      templateData: {},
      activeTab: 'home'
    }
  },
  computed: {
    isEdit() {
      return this.$route.params?.templateId
    },
    isHome() {
      return this.$route.params?.templateCountry === 1
    }
  },
  mounted() {
    if (this.$route.params?.templateCountry === 2) {
      this.activeTab = 'internal'
    }
  }
}
</script>

<style lang="less" scoped>
.template-tab{
  padding: 20px;
  background: #ffffff;
}
</style>
