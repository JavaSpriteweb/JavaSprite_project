<template>
  <div class="temp-container">
    <div class="header">
      <a-form layout="inline" @submit="handleSubmit">
        <a-form-item label="应用">
          <a-select
            placeholder="请选择应用"
            show-search
            allowClear
            :filter-option="false"
            @search="handleAppSearch"
            @change="handleAppChange"
          >
            <a-spin v-if="appFetching" slot="notFoundContent" size="small" />
            <a-select-option
              v-for="item in appOptions"
              :key="item.appId"
              :title="item.appName"
            >
              {{ item.appName }}
            </a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="签名">
          <a-select
            placeholder="请选择签名"
            show-search
            allowClear
            v-model="formData.signId"
            :filter-option="false"
            @search="handleSignSearch"
            @change="handleSignChange"
          >
            <a-spin v-if="signFetching" slot="notFoundContent" size="small" />
            <a-select-option
              v-for="item in signOptions"
              :key="item.signId"
              :title="item.signName"
            >
              {{ item.signName }}
            </a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="模板类型">
          <a-select
            placeholder="请选择模板类型"
            allowClear
            v-model="formData.templateType"
            @change="handleSubmit()"
          >
            <a-select-option v-for="ele in templateOptions" :key="ele.value">
              {{ ele.label }}
            </a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item>
          <a-button
            v-if="hasPermission('templateList')"
            type="primary"
            html-type="submit"
            >查询</a-button
          >
          <a-button
            v-if="hasPermission('createTemplate')"
            type="primary"
            @click="jumpToCreate"
            style="margin-left: 10px"
            >新建模板</a-button
          >
        </a-form-item>
      </a-form>
    </div>
    <div class="template-table" :class="{ active: isCheckbox }">
      <a-table
        :columns="tableColumns"
        :data-source="tableData"
        :loading="loading"
        :scroll="{ x: 1600 }"
        :row-selection="rowSelection"
        rowKey="templateId"
        :pagination="tablePagination"
      >
        <template slot="templateType" slot-scope="text">
          {{ text | parseType }}
        </template>
        <template slot="templateStatus" slot-scope="text">
          {{ text | parseStatus(statusMap) }}
        </template>
        <template slot="auditUrgedStatus" slot-scope="text">
          <span>{{ text === 1 ? "已催审" : "未催审" }}</span>
        </template>
        <template slot="operation" slot-scope="text, record">
          <a-button type="link" size="small" @click="openDetail(record)"
            >详情</a-button
          >
          <template v-if="!hasPermission('templateAuditList')">
            <a-divider type="vertical" />
            <a-button
              v-if="hasPermission('templateDetail')"
              :disabled="
                record.templateStatus !== 0 && record.templateStatus !== 4
              "
              type="link"
              size="small"
              @click="jumpToEdit(record)"
              >修改</a-button
            >
            <a-divider type="vertical" />
            <a-button
              v-if="hasPermission('deleteTemplate')"
              :disabled="record.templateStatus === 1"
              type="link"
              size="small"
              @click="deleteTemplate(record)"
              >删除
            </a-button>
            <a-divider type="vertical" />
            <a-button
              v-if="hasPermission('templateUrgeAudit')"
              :disabled="
                record.templateStatus !== 1 || record.auditUrgedStatus === 1
              "
              type="link"
              size="small"
              @click="pushOnTemplate(record)"
              >催审
            </a-button>
            <a-divider type="vertical" />
            <a-button
              v-if="hasPermission('templateMentionAudit')"
              :disabled="record.templateStatus !== 0"
              type="link"
              size="small"
              @click="submitTemplate(record)"
              >提审
            </a-button>
          </template>
        </template>
        <!--        <div slot="expandedRowRender" slot-scope="{record, text}" style="width: 800px">-->
        <!--          <a-row>-->
        <!--            <a-col :span="12" v-for="item in expandColumns" :key="item.dataIndex">-->
        <!--              <label style="margin-right: 10px">{{item.title}}：</label>-->
        <!--              <span>{{text[item.dataIndex]}}</span>-->
        <!--            </a-col>-->
        <!--          </a-row>-->
        <!--        </div>-->
      </a-table>
      <a-modal
        title="模板详情"
        :visible="visible"
        @cancel="visible = false"
        class="detail-modal"
        destroyOnClose
        width="650px"
      >
        <TemplateForm
          :tempData="activeData"
          :isHome="activeData && activeData.templateCountry === 1"
          :countryList="countryOptions"
        ></TemplateForm>
        <template slot="footer">
          <a-button key="back" @click="visible = false">取消</a-button>
        </template>
      </a-modal>
    </div>
    <footer-tool-bar v-if="selectedRowKeys.length > 0" class="footer">
      <a-button
        v-if="hasPermission('deleteTemplate')"
        type="primary"
        @click="deleteTemplate()"
        >批量删除</a-button
      >
      <a-button
        v-if="hasPermission('templateMentionAudit')"
        type="primary"
        @click="submitTemplate()"
        >批量提交审核</a-button
      >
      <a-button
        v-if="hasPermission('templateUrgeAudit')"
        type="primary"
        @click="pushOnTemplate()"
        >批量催审</a-button
      >
    </footer-tool-bar>
  </div>
</template>

<script>
import AFormItem from "ant-design-vue/es/form/FormItem";
import FooterToolBar from "@/components/tool/FooterToolBar";
import {
  getTemplates,
  deleteTemplate,
  submitTemplate,
  pushOnTemplate,
  getDomainData,
} from "@/services/template";
import { getAppOptions } from "@/services/application";
import { getSignOptions } from "@/services/sign";
import { TEMPLATE_TYPE, TYPE_OPTIONS } from "@/config/default/sms.config";
import debounce from "lodash/debounce";
import TemplateForm from "../template/TemplateForm";
import { mapState } from "vuex";
// import ARow from "ant-design-vue/es/grid/Row"

export default {
  name: "index",
  components: { AFormItem, FooterToolBar, TemplateForm },
  data() {
    this.expandColumns = [
      { title: "模板内容", dataIndex: "templateContent" },
      { title: "所属签名", dataIndex: "signName" },
      { title: "申请说明", dataIndex: "applyInstructions" },
      { title: "模板类型", dataIndex: "templateType" },
      // { title: '字数', dataIndex: 'wordCount' },
      // { title: '拆分条数', dataIndex: 'splitNumber' },
      // { title: '拆分条数', dataIndex: 'splitNumber' }
    ];
    this.templateOptions = TYPE_OPTIONS;
    this.lastAppFetchId = 0;
    this.lastSignFetchId = 0;
    this.handleAppSearch = debounce(this.handleAppSearch, 800);
    this.handleSignSearch = debounce(this.handleSignSearch, 800);
    return {
      formData: {},
      appOptions: [],
      signOptions: [],
      tableData: [],
      total: 0,
      loading: false,
      selectedRowKeys: [],
      selectedRowData: [],
      appFetching: false,
      signFetching: false,
      activeData: {},
      visible: false,
      countryOptions: [],
      statusMap: [],
    };
  },
  computed: {
    ...mapState("account", ["user"]),
    isCheckbox() {
      return this.selectedRowKeys.length > 0 ? "active" : "";
    },
    tableColumns() {
      return [
        { title: "模板名称", dataIndex: "templateName" },
        { title: "模板标识", dataIndex: "templateId" },
        { title: "所属应用", dataIndex: "appName" },
        { title: "所属签名", dataIndex: "signName" },
        {
          title: "模板类型",
          dataIndex: "templateType",
          scopedSlots: { customRender: "templateType" },
        },
        {
          title: "模板状态",
          dataIndex: "templateStatus",
          scopedSlots: { customRender: "templateStatus" },
        },
        {
          title: "催审状态",
          dataIndex: "auditUrgedStatus",
          scopedSlots: { customRender: "auditUrgedStatus" },
        },
        {
          title: "催审时间",
          dataIndex: "auditUrgedDate",
          ellipsis: true,
          width: 160,
        },
        {
          title: "创建时间",
          dataIndex: "createDate",
          ellipsis: true,
          width: 160,
        },
        {
          title: "审核说明",
          dataIndex: "auditInstructions",
          ellipsis: true,
          width: 150,
        },
        {
          title: "操作",
          dataIndex: "operation",
          scopedSlots: { customRender: "operation" },
          fixed: "right",
          width: this.user.accountType === 0 ? 100 : 220,
          align: "center",
        },
      ];
    },
    rowSelection() {
      if (!this.hasPermission("templateAuditList")) {
        return {
          selectedRowKeys: this.selectedRowKeys,
          onChange: this.onSelectChange,
        };
      } else {
        return null;
      }
    },
  },
  mounted() {
    this.handleAppSearch();
    this.handleSubmit();
    this.getCountryList();
    this.getTemplateStatus();
  },
  methods: {
    getTemplates() {
      if (!this.hasPermission("templateList")) {
        return this.$message.error("当前用户无查看模板列表的权限");
      }
      const { appId, signId, templateType } = this.formData;
      const { current, pageSize } = this.myPagination;
      this.loading = true;
      getTemplates({
        accountId: this.user.accountId,
        appId,
        signId,
        templateType,
        pagination: { page: current, size: pageSize },
      })
        .then((res) => {
          const { errorCode, errorMsg, result, pagination } = res;
          if (errorCode === "0") {
            if (result?.templateObjects) {
              this.tableData = result.templateObjects || [];
            } else {
              this.tableData = [];
            }
            this.myPagination.total = pagination?.total || 0;

          } else {
            this.$message.error(errorMsg);
          }
          this.loading = false;
        })
        .catch(() => {
          this.loading = false;
        });
    },
    handleAppSearch(val) {
      this.lastAppFetchId += 1;
      const fetchId = this.lastAppFetchId;
      const params = {
        accountId: this.user.accountId,
        appName: val,
        queryType: 1,
        accountType: this.user.accountType,
      };
      this.appFetching = true;
      getAppOptions({ ...params, pagination: { page: 1, size: 100 } })
        .then((res) => {
          if (fetchId !== this.lastAppFetchId) {
            return;
          }
          const { errorCode, result } = res;
          if (errorCode === "0") {
            this.appOptions = result?.smsAppsPos || [];
          }
          this.appFetching = false;
        })
        .catch(() => {
          this.appFetching = false;
        });
    },
    async handleSignSearch(val) {
      this.lastSignFetchId += 1;
      const fetchId = this.lastSignFetchId;
      this.signFetching = true;
      getSignOptions({ appId: this.formData.appId, signName: val })
        .then((res) => {
          if (fetchId !== this.lastSignFetchId) {
            return;
          }
          const { errorCode, result } = res;
          if (errorCode === "0") {
            this.signOptions = result || [];
          }
          this.signFetching = false;
        })
        .catch(() => {
          this.signFetching = false;
        });
    },
    handleTableChange(pagination) {
      const { current, pageSize } = pagination;
      this.myPagination = { ...this.myPagination, current, pageSize };
      this.getTemplates();
    },
    handleSubmit(e) {
      this.selectedRowData = [];
      this.selectedRowKeys = [];
      if(e) e.preventDefault();
      this.myPagination.current = 1;
      this.getTemplates();
    },
    handleAppChange(val) {
      this.formData.appId = val;
      this.formData.signId = null;
      this.signOptions = []
      if (!val) {
        this.handleAppSearch();
        this.signOptions = [];
      } else {
        this.handleSignSearch();
      }
      this.handleSubmit();
    },
    handleSignChange(val) {
      this.formData.signId = val;
      if (!val) {
        this.handleSignSearch();
      }
      this.handleSubmit();
    },
    openDetail(record) {
      this.activeData = record;
      this.visible = true;
    },
    deleteTemplate(row) {
      const templateIds = row ? [row.templateId] : this.selectedRowKeys;
      if (!row) {
        const submitDisabled = this.selectedRowData.some(
          (ele) => ele.templateStatus === 1
        );
        if (submitDisabled)
          return this.$message.error("选中数据包含不可删除模板");
      }
      this.$confirm({
        okText: "确认",
        content: "是否删除短信模板",
        cancelText: "取消",
        onOk: () => {
          this.loading = true;
          deleteTemplate({ templateIds })
            .then((data) => {
              const { errorCode, errorMsg } = data;
              this.loading = false;
              if (errorCode === "0") {
                this.$message.success("删除成功");
                this.selectedRowKeys = [];
                this.handleSubmit();
              } else {
                this.$message.error(errorMsg);
              }
            })
            .catch(() => {
              this.loading = false;
            });
        },
        onCancel() {
          console.log("Cancel");
        },
      });
    },
    // 提审
    submitTemplate(row) {
      const templateIds = row ? [row.templateId] : this.selectedRowKeys;
      if (!row) {
        const submitDisabled = this.selectedRowData.some(
          (ele) => ele.templateStatus !== 0
        );
        if (submitDisabled)
          return this.$message.error("选中数据包含不可提审模板");
      }
      this.loading = true;
      submitTemplate({ templateIds })
        .then((data) => {
          const { errorCode, errorMsg } = data;
          this.loading = false;
          if (errorCode === "0") {
            this.$message.success("提审成功");
            this.handleSubmit();
          } else {
            this.$message.error(errorMsg);
          }
        })
        .catch(() => {
          this.loading = false;
        });
    },
    // 催审
    pushOnTemplate(row) {
      const templateIds = row ? [row.templateId] : this.selectedRowKeys;
      if (!row) {
        const submitDisabled = this.selectedRowData.some(
          (ele) => ele.templateStatus !== 1 || ele.auditUrgedStatus === 1
        );
        if (submitDisabled)
          return this.$message.error("选中数据包含不可催审模板");
      }
      this.loading = true;
      pushOnTemplate({ templateIds })
        .then((data) => {
          const { errorCode, errorMsg } = data;
          this.loading = false;
          if (errorCode === "0") {
            this.$message.success("催审成功");
            this.handleSubmit();
          } else {
            this.$message.error(errorMsg);
          }
        })
        .catch(() => {
          this.loading = false;
        });
    },
    getCountryList() {
      getDomainData({ code: "SMS-0001" })
        .then((data) => {
          const { errorCode, result } = data;
          if (errorCode === "0" && result) {
            this.countryOptions = result.smsDomainVos;
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getTemplateStatus() {
      getDomainData({ code: "SMS-0009" })
        .then((data) => {
          const { errorCode, result } = data;
          if (errorCode === "0" && result) {
            this.statusMap =
              result.smsDomainVos?.map((item) => [
                Number(item.valueCode),
                item.valueName,
              ]) || [];
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    onSelectChange(selectedRowKeys, selectRows) {
      this.selectedRowKeys = selectedRowKeys;
      this.selectedRowData = selectRows;
    },
    jumpToCreate() {
      this.$router.push({ path: "/template/create" });
    },
    jumpToEdit(row) {
      this.$router.push({ name: "模板详情", params: row });
    },
  },
  filters: {
    parseType(value) {
      const map = new Map(TEMPLATE_TYPE);
      return map.get(value);
    },
    parseStatus(value, statusMap) {
      const map = new Map(statusMap);
      return map.get(value);
    },
  },
};
</script>

<style lang="less" scoped>
.temp-container {
  background: #ffffff;
  width: 100%;
  height: 100%;
  .header {
    padding: 10px 20px;
    /deep/ .ant-select-selection {
      width: 160px;
    }
  }
  .active {
    margin-bottom: 30px;
  }
  .footer {
    button {
      margin-right: 10px;
    }
  }
  .template-table {
    /deep/ .ant-table-fixed-right {
      .ant-table-fixed {
        tr td {
          padding: 0 10px;
        }
      }
    }
  }
}
.detail-modal {
  /deep/ .ant-modal-body {
    padding: 5px 15px;
    max-height: 450px;
    overflow-y: auto;
  }
}
</style>
