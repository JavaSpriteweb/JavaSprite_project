<template>
  <div class="audit-container">
    <div class="header">
      <a-form layout="inline" @submit="handleSubmit">
        <a-form-item label="应用">
          <a-select
            placeholder="请选择应用"
            show-search
            v-model="formData.appId"
            allowClear
            :filter-option="false"
            :getPopupContainer="
              (triggerNode) => triggerNode.parentNode || document.body
            "
            @search="handleAppSearch"
            @change="handleAppChange"
          >
            <a-spin v-if="appFetching" slot="notFoundContent" size="small" />
            <a-select-option
              v-for="item in appOptions"
              :key="item.appId"
              :title="item.appName"
            >
              {{ item.appName }}
            </a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="签名">
          <a-select
            placeholder="请选择签名"
            show-search
            v-model="formData.signId"
            allowClear
            :filter-option="false"
            :getPopupContainer="
              (triggerNode) => triggerNode.parentNode || document.body
            "
            @search="handleSignSearch"
            @change="handleSignChange"
          >
            <a-spin v-if="signFetching" slot="notFoundContent" size="small" />
            <a-select-option
              v-for="item in signOptions"
              :key="item.signId"
              :title="item.signName"
            >
              {{ item.signName }}
            </a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="模板类型">
          <a-select
            placeholder="请选择模板类型"
            allowClear
            v-model="formData.templateType"
            :getPopupContainer="
              (triggerNode) => triggerNode.parentNode || document.body
            "
            @change="handleSubmit()"
          >
            <a-select-option v-for="ele in templateOptions" :key="ele.value">
              {{ ele.label }}
            </a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item label="催审状态">
          <a-select
            placeholder="请选择催审状态"
            allowClear
            v-model="formData.auditUrgedStatus"
            @change="handleSubmit()"
            :getPopupContainer="
              (triggerNode) => triggerNode.parentNode || document.body
            "
          >
            <a-select-option v-for="ele in auditTypeOptions" :key="ele.value">
              {{ ele.label }}
            </a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item>
          <a-button
            v-if="hasPermission('templateAuditList')"
            type="primary"
            html-type="submit"
            >查询</a-button
          >
        </a-form-item>
      </a-form>
    </div>
    <div class="template-table" :class="{ active: isCheckbox }">
      <a-table
        :columns="tableColumns"
        :data-source="tableData"
        :loading="loading"
        :scroll="{ x: 1600 }"
        :row-selection="{
          selectedRowKeys: selectedRowKeys,
          onChange: onSelectChange,
        }"
        rowKey="templateId"
        :pagination="tablePagination"
      >
        <template slot="templateType" slot-scope="text">
          {{ text | parseType }}
        </template>
        <template slot="templateStatus" slot-scope="text">
          {{ text | parseStatus(statusMap) }}
        </template>
        <template slot="auditUrgedStatus" slot-scope="text">
          <span>{{ text === 1 ? "已催审" : "未催审" }}</span>
        </template>
        <template slot="operation" slot-scope="text, record">
          <a-button type="link" size="small" @click="openDetail(record)"
            >详情</a-button
          >
          <a-divider type="vertical" />
          <a-button type="link" size="small" @click="openAudit('pass', record)"
            >审核通过</a-button
          >
          <a-divider type="vertical" />
          <a-button
            type="link"
            size="small"
            @click="openAudit('reject', record)"
            >审核不通过</a-button
          >
        </template>
      </a-table>
    </div>
    <footer-tool-bar v-if="selectedRowKeys.length > 0" class="footer">
      <a-button type="primary" @click="openAudit('pass')">批量通过</a-button>
      <a-button type="primary" @click="openAudit('reject')"
        >批量不通过</a-button
      >
    </footer-tool-bar>
    <a-modal
      title="模板详情"
      :visible="visible"
      @cancel="onCancel"
      class="detail-modal"
      destroyOnClose
      width="600px"
    >
      <TemplateForm
        :tempData="activeData"
        :isHome="activeData && activeData.templateCountry === 1"
        :countryList="countryOptions"
      ></TemplateForm>
      <template slot="footer">
        <a-button key="back" @click="onCancel">取消</a-button>
      </template>
    </a-modal>
    <a-modal :title="title" :visible="auditVisible" @cancel="onCancel">
      <div>
        <label>审核说明：</label>
        <a-textarea
          v-model="auditInstructions"
          :maxLength="1000"
          style="width: 80%"
        ></a-textarea>
      </div>
      <template slot="footer">
        <a-button @click="onCancel">取消</a-button>
        <a-button :loading="submitLoading" @click="submitAudit">确定</a-button>
      </template>
    </a-modal>
  </div>
</template>

<script>
import AFormItem from "ant-design-vue/es/form/FormItem";
import FooterToolBar from "@/components/tool/FooterToolBar";
import TemplateForm from "../template/TemplateForm";
import {
  getTemplates,
  passTemplate,
  rejectTemplate,
  getDomainData,
} from "@/services/template";
import { getApplications } from "@/services/application";
import { getSignOptions } from "@/services/sign";
import { TEMPLATE_TYPE } from "@/config/default/sms.config";
import debounce from "lodash/debounce";
import ATextarea from "ant-design-vue/es/input/TextArea";

export default {
  name: "index",
  components: { ATextarea, AFormItem, FooterToolBar, TemplateForm },
  data() {
    this.tableColumns = [
      { title: "模板名称", dataIndex: "templateName", width: 160 },
      { title: "模板标识", dataIndex: "templateId" },
      { title: "所属应用", dataIndex: "appName" },
      { title: "所属签名", dataIndex: "signName" },
      {
        title: "模板类型",
        dataIndex: "templateType",
        scopedSlots: { customRender: "templateType" },
      },
      {
        title: "模板状态",
        dataIndex: "templateStatus",
        scopedSlots: { customRender: "templateStatus" },
        width: 150,
      },
      {
        title: "催审状态",
        dataIndex: "auditUrgedStatus",
        scopedSlots: { customRender: "auditUrgedStatus" },
      },
      {
        title: "催审时间",
        dataIndex: "auditUrgedDate",
        ellipsis: true,
        width: 160,
      },
      {
        title: "创建时间",
        dataIndex: "createDate",
        ellipsis: true,
        width: 160,
      },
      {
        title: "审核说明",
        dataIndex: "auditInstructions",
        ellipsis: true,
        width: 200,
      },
      {
        title: "操作",
        dataIndex: "operation",
        scopedSlots: { customRender: "operation" },
        fixed: "right",
        width: 200,
        align: "center",
      },
    ];
    this.auditTypeOptions = [
      { label: "未催审", value: 0 },
      { label: "已催审", value: 1 },
    ];
    this.lastAppFetchId = 0;
    this.lastSignFetchId = 0;
    this.handleAppSearch = debounce(this.handleAppSearch, 800);
    this.handleSignSearch = debounce(this.handleSignSearch, 800);
    return {
      formData: {},
      appOptions: [],
      signOptions: [],
      templateOptions: [
        { label: "验证码类", value: "1" },
        { label: "推广类", value: "2" },
        { label: "通知类", value: "3" },
      ],
      tableData: [],
      total: 0,
      loading: false,
      selectedRowKeys: [],
      appFetching: false,
      signFetching: false,
      visible: false,
      activeData: {},
      auditVisible: false,
      isPassAudit: true,
      auditInstructions: "",
      submitLoading: false,
      countryOptions: [], // 国家
      statusMap: [],
    };
  },
  computed: {
    accountId() {
      return this.$store.state.account.user.accountId;
    },
    title() {
      return this.isPassAudit ? "审核通过" : "审核不通过";
    },
    isCheckbox() {
      return this.selectedRowKeys.length > 0 ? "active" : "";
    },
  },
  mounted() {
    this.handleAppSearch();
    this.handleSubmit();
    this.getCountryList();
    this.getTemplateStatus();
  },
  methods: {
    getTemplates() {
      if (!this.hasPermission("templateAuditList")) {
        return this.$message.error("该用户暂无查看模板审核权限");
      }
      const { appId, signId, templateType, auditUrgedStatus } = this.formData;
      const { current, pageSize } = this.myPagination;
      this.loading = true;
      getTemplates({
        accountId: this.accountId,
        appId,
        signId,
        templateType,
        auditUrgedStatus,
        templateStatus: 1,
        pagination: { page: current, size: pageSize },
      })
        .then((res) => {
          const { errorCode, errorMsg, result, pagination } = res;
          if (errorCode === "0") {
            if (result) {
              const { templateObjects } = result;
              this.tableData = templateObjects;
            } else {
              this.tableData = [];
            }
            this.myPagination.total = pagination?.total || 0;
          } else {
            this.$message.error(errorMsg);
          }
          this.loading = false;
        })
        .catch(() => {
          this.loading = false;
        });
    },
    handleAppSearch(val) {
      this.lastAppFetchId += 1;
      const fetchId = this.lastAppFetchId;
      const params = { accountId: this.accountId, appName: val, queryType: 1 };
      this.appFetching = true;
      getApplications({ ...params, pagination: { page: 1, size: 100 } })
        .then((res) => {
          if (fetchId !== this.lastAppFetchId) {
            return;
          }
          const { errorCode, result } = res;
          if (errorCode === "0") {
            this.appOptions = result?.smsAppsPos || [];
          }
          this.appFetching = false;
        })
        .catch(() => {
          this.appFetching = false;
        });
    },
    handleAppChange(val) {
      if (!val) {
        this.handleAppSearch();
      } else {
        this.handleSignSearch();
      }
      this.signOptions = [];
      this.formData.signId = null;
      this.handleSubmit();
    },
    handleSignChange(val) {
      if (!val) {
        this.handleSignSearch();
      }
      this.handleSubmit();
    },
    async handleSignSearch(val) {
      this.lastSignFetchId += 1;
      const fetchId = this.lastSignFetchId;
      this.signFetching = true;
      getSignOptions({ appId: this.formData.appId, signName: val })
        .then((res) => {
          if (fetchId !== this.lastSignFetchId) {
            return;
          }
          const { errorCode, result } = res;
          if (errorCode === "0") {
            this.signOptions = result || [];
          }
          this.signFetching = false;
        })
        .catch(() => {
          this.signFetching = false;
        });
    },
    handleTableChange(pagination) {
      const { current, pageSize } = pagination;
      this.myPagination = { ...this.myPagination, current, pageSize };
      this.getTemplates();
    },
    handleSubmit(e) {
      if(e) e.preventDefault();
      this.myPagination.current = 1;
      this.getTemplates();
      this.selectedRowKeys = [];
    },
    getCountryList() {
      getDomainData({ code: "SMS-0001" })
        .then((data) => {
          const { errorCode, result } = data;
          if (errorCode === "0" && result) {
            this.countryOptions = result.smsDomainVos;
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    getTemplateStatus() {
      getDomainData({ code: "SMS-0009" })
        .then((data) => {
          const { errorCode, result } = data;
          if (errorCode === "0" && result) {
            this.statusMap =
              result.smsDomainVos?.map((item) => [
                Number(item.valueCode),
                item.valueName,
              ]) || [];
          }
        })
        .catch((err) => {
          console.log(err);
        });
    },
    openAudit(type, record) {
      this.isPassAudit = type === "pass";
      this.activeData = record;
      this.auditVisible = true;
    },
    submitAudit() {
      if (this.isPassAudit) {
        this.passTemplate();
      } else {
        this.rejectTemplate();
      }
    },
    // 审核通过
    passTemplate() {
      const templateIds = this.activeData
        ? [this.activeData.templateId]
        : this.selectedRowKeys;
      this.submitLoading = true;
      passTemplate({
        operAccountId: this.accountId,
        auditInstructions: this.auditInstructions,
        templateIds,
      })
        .then((data) => {
          const { errorCode, errorMsg } = data;
          if (errorCode === "0") {
            this.$message.success(errorMsg);
            this.selectedRowKeys = [];
            this.onCancel();
            this.handleSubmit();
          } else {
            this.$message.error(errorMsg);
          }
          this.submitLoading = false;
        })
        .catch(() => {
          this.submitLoading = true;
        });
    },
    // 批量不通过
    rejectTemplate() {
      const templateIds = this.activeData
        ? [this.activeData.templateId]
        : this.selectedRowKeys;
      this.submitLoading = true;
      rejectTemplate({
        operAccountId: this.accountId,
        auditInstructions: this.auditInstructions,
        templateIds,
      })
        .then((data) => {
          const { errorCode, errorMsg } = data;
          if (errorCode === "0") {
            this.$message.success(errorMsg);
            this.selectedRowKeys = [];
            this.onCancel();
            this.handleSubmit();
          } else {
            this.$message.error(errorMsg);
          }
          this.submitLoading = false;
        })
        .catch(() => {
          this.submitLoading = false;
        });
    },
    openDetail(record) {
      this.activeData = record;
      this.visible = true;
    },
    onCancel() {
      this.visible = false;
      this.auditVisible = false;
      this.auditInstructions = "";
    },
    onSelectChange(selectedRowKeys) {
      this.selectedRowKeys = selectedRowKeys;
    },
    jumpToCreate() {
      this.$router.push({ path: "/template/create" });
    },
    jumpToEdit(row) {
      this.$router.push({ name: "模板详情", params: row });
    },
  },
  filters: {
    parseType(value) {
      const map = new Map(TEMPLATE_TYPE);
      return map.get(value);
    },
    parseStatus(value, statusMap) {
      const map = new Map(statusMap);
      return map.get(value);
    },
  },
};
</script>

<style lang="less" scoped>
.audit-container {
  background: #ffffff;
  width: 100%;
  height: 100%;
  .header {
    padding: 10px 20px;
    /deep/ .ant-select-selection {
      width: 160px;
    }
  }
  .active {
    margin-bottom: 30px;
  }
  .footer {
    button {
      margin-right: 10px;
    }
  }
}
.detail-modal {
  /deep/ .ant-modal-body {
    padding: 5px 15px;
    max-height: 450px;
    overflow-y: auto;
  }
}
</style>
