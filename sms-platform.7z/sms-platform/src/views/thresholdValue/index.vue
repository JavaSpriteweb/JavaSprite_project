<template>
  <div class="app-container">
    <div class="header">
      <a-form layout="inline" @submit.prevent="handleSearch">
        <a-form-item label="创建时间:">
          <a-range-picker
            format="YYYY-MM-DD"
            :placeholder="['开始', '截至']"
            v-model="searchForm.dateTimeRange"
          />
        </a-form-item>

        <a-form-item label="账号：">
          <a-select
            allowClear
            show-search
            style="width: 200px"
            :disabled="user.accountType !== 0"
            v-model="searchForm.accountId"
          >
            <a-select-option
              v-for="accountItem in accountList"
              :key="accountItem.accountId"
              :value="accountItem.userName"
            >
              {{ accountItem.userName }}
            </a-select-option>
          </a-select>
        </a-form-item>

        <a-form-item>
          <a-button type="primary" html-type="submit">查询</a-button>
        </a-form-item>
      </a-form>
    </div>
    <div class="content">
      <a-table
        row-key="logId"
        :columns="columns"
        :scroll="{ x: 900 }"
        :loading="loading"
        :data-source="dataList"
        :pagination="tablePagination"
      />
    </div>
  </div>
</template>

<script>
import moment from "moment"
import { mapState } from 'vuex'
import { getAccounts } from "@/services/account";
import { getThresholdValue } from "@/services/thresholdValue";
export default {
  name: "index",
  data() {
    return {
      loading: false,
      searchForm: {
        accountId: '',
        dateTimeRange: [
          moment({ hour: 0, minute: 0, second: 0 }),
          moment({ hour: 23, minute: 59, second: 59 }),
        ],
      },
      accountList: [],
      dataList: [],
      columns: [
        { title: "日志ID", width: '80px', dataIndex: "logId" },
        { title: "账户", width: '80px', dataIndex: "accountId" },
        { title: "内容日志", ellipsis: true, dataIndex: "logInfo" },
        { title: "起始时间", width: '175px', dataIndex: "beginDate" },
        { title: "结束时间", width: '175px', dataIndex: "endDate" },
        { title: "创建时间", width: '175px', dataIndex: "creatDate" }
      ],
    };
  },
  computed: {
    ...mapState('account', ['user'])
  },
  methods: {
    handleTableChange(pagination) {
      this.myPagination = {
        ...this.myPagination,
        current: pagination.current,
        pageSize: pagination.pageSize
      }
      this.getThreshold()
    },
    handleSearch() {
      this.myPagination.current = 1
      this.getThreshold()
    },
    getThreshold() {
      this.loading = true;
      const { current: page, pageSize: size } = this.myPagination
      let { accountId, dateTimeRange } = this.searchForm;
      const account = this.accountList.find(item => !this._isNull(item.userName) && (item.userName === accountId)) || {}
      accountId = account.accountId
      const beginDate = moment(dateTimeRange[0]).format("YYYYMMDDHHmmss");
      const endDate = moment(dateTimeRange[1]).format("YYYYMMDDHHmmss");
      const params = { accountId, beginDate, endDate, pagination: { page, size } }
      getThresholdValue(params).then(({ errorCode, errorMsg, result, pagination }) => {
        if (+errorCode === 0) {
          const { smsThresholdLogs = [] } = result || {}
          this.dataList = smsThresholdLogs
          this.myPagination.total = pagination.total
        } else {
          this.$message.error(errorMsg)
        }
      }).finally(() => {
        this.loading = false
      })
    },
  },
  mounted() {
    getAccounts({ pagination: { page: 1, size: 99999 } }).then(({ errorCode, errorMsg, result }) => {
      if (+errorCode === 0) {
        const { smsAccountOutVos = [] } = result || {}
        this.accountList = smsAccountOutVos
        if (this.user.accountType === 1) {
          const account = this.accountList.find(item => item.accountId === this.user.accountId) || {}
          this.searchForm.accountId = account.userName
        }
      } else {
        this.$message.error(errorMsg)
      }
    })
    this.handleSearch()
  },
};
</script>

<style lang="less" scoped>
.app-container {
  background: #ffffff;
  width: 100%;
  height: 100%;
  .header {
    padding: 10px 20px;
    /deep/ .ant-select-selection {
      width: 160px;
    }
  }
  .app-table {
    span {
      i {
        margin-right: 5px;
      }
    }
  }
}
</style>
